# -*- coding:utf-8 -*-
#! /moobot/res/slenderagv/robot.py
# 主要是机器人的主运行逻辑.
# 核心架构为异步多线程
# python 并不能很好的利用多核的优势, 所以多线程对于pytho来说是伪命题.
import threading
import _thread
import logging
import time
import queue
import json
import re
from iot_radar import Radar
from iot_rfid_rc522 import Rfid
from iot_voltage import Voltage
from iot_motor import PwmMotor2
from iot_magnet_ms16a import Magnet
from net_tcp_listener import TcpCommander
from backroute import BackRoute


class Robot(threading.Thread):

    #巡磁
    magnet1 = None
    # rfid
    rfid1 = None
    rfid1_client = None
    mouth_last_rfid_id = ''  # 上一次读到的非零rfid卡号
    mouth_this_rfid_id = ''  # 当前rfid卡号
    mouth_new_rfid_count = 0  # 新卡计数
    rfid_list = []
    is_charging = False  # 是否在充电
    charging_rfid_list = []  # 充电位卡号列表
    mouth_ingore_flag = False  # 是否忽略里程
    nose1_dx=0
    nose2_dx=0
    r=0
    # 超声避障
    radar = None
    radar_client = None
    # 超声避障读数，创建空元祖，读取时候接收新数据,每次接收后处理时先清空然后再赋值
    ear_this_radar_id = []
    # 是否避障停车
    ear_stop = False

    # 电压采集
    voltage = None
    voltage_value = 0

    waist1 = None
    back1 = None
    feet = None
    NOSE_BIT_WIDTH = 0.01
    backroute = None
    # 服务端的ip地址
    # server_ip = '127.0.0.1'
    server_ip = '192.168.43.162'
    # 服务端socket绑定的端口号
    server_port = 20000
    tcpcommander = None

    modbus_client1=None

    # 给inside服务
    channel_data=[{"id":"","name":"ch","dr":0, "dw":0}]

    # 给team服务
    task_queue=queue.Queue(maxsize=10)
    cmd_str=""
    command_list=[]
    nose1_count=0
    nose2_count=0
    # 当前任务
    current_task = ""
    # 当前任务列表
    current_cmd_list = []
    list_id = 1
    dict_msg = {}
    # 当前任务指令字符串
    current_cmdStr = ""
    # 指令长度
    cmdNum = 0

    #当前指令
    cmd_this=""
    cmd_this_start_time=None
    cmd_this_end_time=None
    idle_start_time=None
    idle_end_time=None

    #主状态
    main_state= 0
    MAIN_STATE_INIT = 100
    MAIN_STATE_IDLE = 200
    MAIN_STATE_BUSY = 300
    MAIN_STATE_BUSY_RUNNING = 310
    MAIN_STATE_BUSY_FINISH = 320
    MAIN_STATE_BUSY_BLOCKED = 330
    MAIN_STATE_WAIT = 400
    MAIN_STATE_ERROR = 500
    MAIN_STATE_ERR_DONE = 510
    MAIN_STATE_ERR_UNDONE = 520
    MAIN_STATE_ERR_UNKNOW = 530
    task_queue=[]
    autoMode=True

    flag_system_alarm = False
    # 错误代码识别号
    # 11xx:巡磁错误系列
    ERROR_CODE_OUT_OF_MAGNET = 1101
    # 12xx:rfid错误系列
    ERROR_CODE_WITHOUT_THIS_RFID = 1201  # 没有这个rfid卡,可能卡坏了
    # 13xx:超声避障错误系列

    if_check_after_cmd = False
    # 车子位置姿态, 默认为起点位置坐标(9,0,180),方向为朝射频门方向
    x = 8
    y = 1
    w = 180

    # 指令执行完后预期到达的点位坐标
    sim_x = 0
    sim_y = 0
    sim_w = 0

    sp_dict = {}
    sp_list = []

    #Part 1 构造函数
    def __init__(self):
        super(Robot, self).__init__()
        return

    def init(self):
        try:
            self.backroute = BackRoute()


            self.feet = PwmMotor2()
            # self.feet.config("COM13", 0x25, 38400)
            self.feet.config("/dev/ttyUSB1", 0x25, 38400)
            self.feet.connect()
            self.tcpcommander = TcpCommander()
            # self.waist1 = Waist3()
            # self.waist1.init()
            # self.waist1.rtu.client = self.feet.client

            # self.back1 = backbone()
            # self.back1.init()
            # self.back1.rtu.client=self.feet.client

            self.magnet1 = Magnet()
            self.magnet1.client=self.feet.client
            # self.rfid1 = Rfid('COM10', 9600, 0.5)

			# RFID
            self.rfid1 = Rfid('/dev/ttyUSB2', 9600, 0.5)
            self.rfid1_client = self.rfid1.init()

            # 超声避障
            self.radar = Radar('/dev/ttyUSB0', 9600, 0.5)
            self.radar_client = self.radar.init()

            # 电压采集
            self.voltage = Voltage("/dev/ttyUSB1", 38400, 0x05)
            self.voltage.connect()
        except:
            print("有异常")

        # 读取rfid配置
        self.read_rfidjson()

        #启动TCPIP
        self.task_queue = self.tcpcommander.q
        # tcp对象中引用robot中的属性,用于反馈状态给上位机
        self.tcpcommander.feet = self.feet
        self.set_states()
        _thread.start_new_thread(self.tcpcommander.connect,("启动TCPIP通讯",))
        self.autoMode=self.tcpcommander.autoMode
        return

    #Part 3 进程主函数, 每个机器人都以此作为最核心的代码.
    def run(self):
        print('进入robot_main.run()')
        self.main_state = self.MAIN_STATE_INIT
        self.init()
        self.main_state = self.MAIN_STATE_IDLE
        print("IDLE")
        while True:
            self.autoMode=self.tcpcommander.autoMode
            print("模式为++++++++++++++++++++++++++++",self.autoMode)
            self.set_states()
            try:
                if self.autoMode == True:
                    if self.flag_system_alarm:
                        print('系统报警状态,需要人为干预恢复')
                        time.sleep(0.5)
                    else:
                        self.voltage_value = self.voltage.read_voltage()
                        print("读取电压值=", self.voltage_value)

                    if(self.task_queue.qsize() == 0):
                        print("目前队列为空")
                        self.feet.stop()
                        time.sleep(0.5)
                        continue
                    else:
                        self.main_state = self.MAIN_STATE_BUSY
                        print("BUSY")
                        byte_q = self.task_queue.get()
                        byte_q1 = str(byte_q).encode("utf-8")
                        self.current_task = byte_q1.decode("utf-8")
                        print("RUN", self.current_task)
                        print("-------------------------------------")
                        print("当前任务：",self.current_task)
                        ok = self.run_task()
                        if(not ok):
                            continue
                        ok=self.run_commandStr()
                        if (not ok ):
                            continue
                        time.sleep(0.5)  # 任务执行完毕后, 休息0.5秒, 防止前后冲突
                        self.main_state = self.MAIN_STATE_IDLE
                        print("IDLE")
                        print("开始下一次循环")
                else:
                    print("手动模式中----------")
            except Exception as ex:
                self.main_state=self.MAIN_STATE_ERROR
                self.error=ex
                print("ERROR", ex)

                recovered= self.deal_error(self.MAIN_STATE_ERROR, '主循环发生异常')
                if(recovered==True):
                    print("Error Recovered")
                    time.sleep(0.5)
                    print("IDLE")
                    self.main_state = self.MAIN_STATE_IDLE
                    continue
                else:
                    print("Error Unrecovered")
                    time.sleep(0.5)
                    self.main_state = self.MAIN_STATE_ERR_UNDONE
                    print("")
                    exit(1)
        # return

    def search_warejson(self,cmdStr):
        res = open("data/WarehouseRoutes.json",encoding='utf-8').read()
        wareRoute = json.loads(res)
        dict = wareRoute["routes"]
        print(dict)
        cmd = ""
        print("cmdStr",cmdStr)
        for i in dict:
            if (i["routeId"] == cmdStr):
                print(i["cmd"])
                cmd = i["cmd"]
        return cmd

    def search_movejson(self,cmdStr):
        res = open("MoveHouseRoutes.json",encoding='utf-8').read()
        wareRoute = json.loads(res)
        dict = wareRoute[cmdStr]
        return dict

    #出错处理, 返回是否
    # 如果出错处理成功, 机器可以继续运行, 则返回是
    # 否则False, 然后机器要重启启动加载.
    def deal_error(self, code, msg):
        # TODO 出错处理
        # 1.巡磁脱磁处理,根据
        # 2.查询实际读到的RFID卡,和表中配置的卡号对应不上,RFID卡可能损坏
        if code == self.ERROR_CODE_OUT_OF_MAGNET:
            # 区分是慢慢偏出巡磁还是走到磁条末端脱磁
            pass

        if code == self.ERROR_CODE_WITHOUT_THIS_RFID:
            self.flag_system_alarm = True
            return False


        return False
    # 根据task生成commandlist
    def calculate_command_list(self,task):

        self.cmd_str="246132"
        # task_cmdstr_json_dictionary
        #cmd_str=读取数据库, 获得task对应的cmd_str
        #TODO: 目前是假数据
        self.command_list=["2","4","6","1","3","2"]
        #将cmd_str分解为command数组
        print("BUSY: GET cmd_str", self.cmd_str)
        return True


    # Part 4. 执行
    # 4.1 一个指令任务
    def run_task(self):
        print("开始对队列中消息进行判断")
        if(self.current_task.__eq__("get_state")):
            print("收到请求状态指令")

        elif(bool(re.match("\d{0,}$",self.current_task))):
            self.current_cmdStr = self.current_task
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("0-") and not self.current_task.__contains__("-0")):
            cstr1 = self.current_task[2:]
            s1 = self.search_warejson(cstr1)
            ## self.current_cmdStr = "7"+ s1 + "9" + self.backroute.backroute2(s1) + "0"
            self.current_cmdStr =  "5"+s1[3:] + "9" + self.backroute.backroute2(s1) + "660"
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("-0") and not self.current_task.__contains__("0-")):
            cstr2 = self.current_task[0:4]
            s2 = self.search_warejson(cstr2)
            self.current_cmdStr = "9" + s2 + "7" + (self.backroute.backroute2(s2))[0:s2.__len__()-4] + "5"
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("-") and not self.current_task.__contains__(
                "-0") and not self.current_task.__contains__("0-")):
            s3 = self.current_task[0:4]
            current_cmdStr1 = self.search_warejson(s3)
            print(type(s3))
            s4 = self.current_task[5:]
            current_cmdStr2 = self.search_warejson(s4)
            # s5 = self.search_movejson(self.current_task)
            # s6 = s5[0:s5.__len__()-1]
            # self.current_cmdStr = "9" + current_cmdStr1 + "7" + s6 + "9" + self.backroute.backroute2(current_cmdStr2) + "0"
            self.current_cmdStr = "9" + current_cmdStr1 + "7" + self.backroute.backroute2(current_cmdStr1) + "66" + current_cmdStr2 + "9" + self.backroute.backroute2(current_cmdStr2) + "660"
            print('原始的移库路径=', self.current_cmdStr, ',长度=',len(self.current_cmdStr))
            while True:
                len1 = len(self.current_cmdStr)
                self.current_cmdStr.replace('2442', '44')
                self.current_cmdStr.replace('2445', '44')
                self.current_cmdStr.replace('5442', '44')
                self.current_cmdStr.replace('5445', '44')
                self.current_cmdStr.replace('2662', '66')
                self.current_cmdStr.replace('2665', '66')
                self.current_cmdStr.replace('5662', '66')
                self.current_cmdStr.replace('5665', '66')
                self.current_cmdStr.replace('4444', '')
                self.current_cmdStr.replace('6666', '')
                self.current_cmdStr.replace('444', '6')
                self.current_cmdStr.replace('666', '4')
                self.current_cmdStr.replace('28', '')
                self.current_cmdStr.replace('82', '')
                self.current_cmdStr.replace('58', '')
                self.current_cmdStr.replace('85', '')
                self.current_cmdStr.replace('46', '')
                self.current_cmdStr.replace('64', '')
                self.current_cmdStr.replace('79', '')
                self.current_cmdStr.replace('97', '')
                print('一次循环缩并后, self.current_cmdStr=',self.current_cmdStr,', 长度=',len(self.current_cmdStr),', 缩并前长度len1=',len1)
                if len1 == len(self.current_cmdStr):
                    print('发现缩并前后长度相同,指令已无法再缩并了,最终移库指令=',self.current_cmdStr)
                    break
            print("获取cmd", self.current_cmdStr)
        else:
            print("格式异常")
            return False
        print("判断结束")
        return True

    def run_commandStr(self):
        if (self.current_cmdStr == ""):
            print("未找到相关指令")
            return False
        print("信息判断结束")
        self.cmdNum = self.current_cmdStr.__len__()
        print("指令长度：", self.cmdNum)  # cmdstr->cmdlist
        # v = None
        # s = None
        # x = None
        # rfid = None
        self.dict_msg["id"] = self.list_id
        self.dict_msg["cmd"] = self.current_cmdStr
        # for singlecmd in self.current_cmdStr:
        cmd_index = 0  # 指令序号
        while cmd_index < len(self.current_cmdStr):
            singlecmd = self.current_cmdStr[cmd_index]
            self.safe_go(singlecmd, self.dict_msg)

            if self.if_check_after_cmd:
                # 单指令执行完毕后
                # step7.查表获取实际rfid对应的坐标
                (read_x, read_y) = self.read_rfid()
                print('cmd_index=', cmd_index, ', 执行指令singlecmd=', singlecmd, ',读取到的xy=(', read_x, ',', read_y, ')')
                if read_x == -1 and read_y == -1:
                    # 未查询到读到的卡号,配置出错或者RFID卡已损坏需要更换
                    ok_deal_error = self.deal_error(self.ERROR_CODE_WITHOUT_THIS_RFID, '查询实际读到的RFID卡,和表中配置的卡号对应不上,RFID卡可能损坏') # 200系列:RFID出错
                    print('读到的rfid卡是-1,-1, 进入处理错误函数, 处理结果ok_deal_error=', ok_deal_error)
                    if ok_deal_error:
                        pass
                    else:
                        print('处理结果=False, 发送停车指令,')
                        self.safe_go_0()
                        # TODO 程序停住,不能往下执行
                        while self.flag_system_alarm:
                            time.sleep(1)
                else:
                    # 比对坐标来确定是否是同一张卡
                    ok = self.check_read_sim_rfid(read_x, read_y, self.sim_x, self.sim_y, self.sim_w)
                    if ok:
                        # 校验发现读到的和预期的一致,指令执行到正确点位,执行下一个指令
                        self.x = read_x
                        self.y = read_y
                        print('读取的rfid卡点位坐标和预期的点位坐标相同,设置车子点位坐标为读到的坐标,(x,y,w)=(', self.x, ',', self.y, ',', self.w, '), 预期坐标=(', self.sim_x, ',', self.sim_y, ',', self.sim_w, ')')
                        if self.w != self.sim_w:
                            self.w = self.sim_w
                            print('发现w不同,self.w设置为sim_w')
                        pass
                    else:
                        # 生成更正指令,添加到当前指令完指令后
                        print('检测对比rfid卡发现不同, 当前读取位置=(',read_x,',',read_y,',',self.w,')(w为self.w), 预期位置=(',self.sim_x,',',self.sim_y,',',self.sim_w,")")
                        gostr = self.get_go_str(read_x, read_y, self.sim_x, self.sim_y, self.sim_w, singlecmd)
                        if gostr == '':
                            print('走错路无法返回到预期位置')
                            # 无法找到退回的指令,停车
                            self.safe_go_0()
                            # 报警通知上位机走错路无法返回
                            self.flag_system_alarm = True
                            return False
                        else:
                            self.x = read_x
                            self.y = read_y
                            print('计算出往回走的指令,设置车子当前点位坐标为读到的坐标,(x,y,w)=(',self.x,',',self.y,',',self.w,'), 此时预期坐标=(',self.sim_x,',',self.sim_y,',',self.sim_w,')')
                            if self.w != self.sim_w:
                                self.w = self.sim_w
                                print('发现w不同,self.w设置为sim_w')
                            print('需要添加的倒退指令gostr=',gostr,', 添加前整体指令=',self.current_cmdStr,', cmd_index=', cmd_index)
                            self.current_cmdStr = self.current_cmdStr[0:cmd_index + 1] + gostr + self.current_cmdStr[cmd_index + 1:]
                            print('整体指令添加倒退指令后=',self.current_cmdStr)
            # 指令序号加1,开始执行下一个指令
            cmd_index += 1
        self.current_cmd_list.append(self.dict_msg)
        print(self.current_cmd_list)
        self.dict_msg = {}
        self.list_id = self.list_id + 1
        return True
        # return False

    # 4.2 执行一个命令
    # def wait_until_cmd_finish(self):
    #     while self.robot_inside.current_cmd_state != 'finished':
    #         time.sleep(0.1)

    #4.2 执行指令
    # def run_cmd(self, cmd):
    #     print("run_cmd:", cmd)
    #     if(cmd==None):
    #         return True
    #     elif(cmd==""):
    #         return True
    #     else:
    #         if(self.mode==15):
    #             return self.safe_go(cmd)
    #         else:
    #             print("Unknown Mode")
    #             return self.safe_go(cmd)

    #Part 5: 主要运动指令
    # 最常用的是safe_go()  # 24687950  不许调用iot的part，只能修改value_to_write，不允许直接调用iot part

    #安全执行
    def safe_go(self,cmd, command_json={}):
        print("safe_go:",cmd)
        # if (cmd == None or cmd ==""):
        #     logging.error("Blank command")
        #     return True
        # else:
        #     #cmd = cmd.trim(" ")
        self.mouth_new_rfid_count=0
        self.mouth_last_rfid_id = ''

        # 执行指令前先模拟计算出到达的预期RFID卡号坐标
        # step6.计算指令结束后预测应该到达的rfid卡的坐标
        if self.if_check_after_cmd:
            (self.sim_x, self.sim_y, self.sim_w) = self.sim_run(cmd, self.x, self.y, self.w)
            print('当前位置(', self.x, ', ', self.y, ', ', self.w, '), 预期位置(', self.sim_x, ', ', self.sim_y, ', ', self.sim_w, ')')

        if (cmd == ""):
            return True
        elif (cmd == "1"):
            print("开始指令1")
            self.safe_go_1()
            print("指令1执行结束")
            return True
        elif (cmd == "3"):
            print("开始指令3")
            self.safe_go_3()
            print("指令3执行结束")
            return True
        elif (cmd == "2"):
            print("开始执行2指令")
            self.safe_go_2()
            print("指令2结束")
            return True
        elif (cmd == "4"):
            print("开始执行指令4")
            self.safe_go_4()
            print("指令4执行结束")
            return True
        elif (cmd == "6"):
            print("开始执行6指令")
            self.safe_go_6()
            print("指令6执行结束")
            return True
        elif (cmd == "8"):
            print("开始执行8指令")
            self.safe_go_8()
            print("指令8执行结束")
            return True
        elif (cmd == "5"):
            print("开始执行5指令")
            self.safe_go_5()
            print("指令5执行结束")
            return True
        elif (cmd == "0"):
            print("开始执行0指令")
            self.safe_go_0()
            print("指令0执行结束")
            return True
        elif (cmd == "7"):
            print("开始执行7指令")
            self.safe_go_7()
            print("指令7执行结束")
            return True
        elif (cmd == "9"):
            print("开始执行9指令")
            self.safe_go_9()
            print("指令9执行结束")
            return True
        else:
            logging.error("未知指令")
            return False

    # NORMAL_SPEED = 0.05

    # @此方法暂未使用(实际点位与预期点位用坐标对比,不用rfid卡号对比)
    def get_sim_rfid(self, sim_x, sim_y, sim_w):
        # 根据预期的坐标查表获取预期rfid卡(同一点位最多有3张卡)
        for x in self.rfid_list:
            if x['x'] == sim_x and x['y'] == sim_y and x['w'] == sim_w:
                return x['rfid1'], x['rfid2'], x['rfid3']
        return ''

    # 指令集
    #5.2
    #转腰
    def safe_go_1(self):
        self.waist1.go_next()
        return True
    def safe_go_3(self):
        self.waist1.go_last()
        return  True
    #顶升
    def safe_go_7(self):
        # self.back1.up()
        self.feet.stop()
        time.sleep(1)
        self.up()
        time.sleep(7)
        print('顶升升起等待7秒时间到')
        return  True
    def safe_go_9(self):
        # self.back1.down()
        self.feet.stop()
        time.sleep(1)
        self.down()
        time.sleep(7)
        print('顶升下降等待7秒时间到')
        return  True

    def safe_go_8(self):
        self.mouth_ingore_flag = True
        # step 1 判断脱磁条
        (nose_index, self.nose2_count) = self.nose2_read()
        print("巡磁点亮个数:", self.nose2_count)
        if (self.nose2_count == 0):
            return False

        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 读取超声避障数据并处理
        #radar_data = self.ear_read()
        #self.radar_after_read(radar_data)
        # # step 1 忽略里程
        start_time = time.time()
        while True:
            self.follow_two_step()
            end_time=time.time()
            if(end_time-start_time>1):
                self.mouth_ingore_flag = False
                break

        while True:
            self.follow_two_step()
            # if(self.nose2_count>10):
            #     break
            # if(self.nose2_count==0):
                # raise Exception("脱磁")
                # break
            if(self.mouth_new_rfid_count>=1):
               break
        #self.feet.stop()
        return
        # if(self.next_cmd=="2"):
        #     return
        # else:
        #     self.feet.stop()
        #     return

    def safe_go_4(self):
        # step 1 先开始转动
        self.feet.set_speed_pwm(-100, 100)
        # self.feet.set_speed_mps(-0.08,0.08)
        time.sleep(1)
        # # Step 2A 脱磁, 停车
        while True:
            (nose_index, self.nose1_count) = self.nose1_read()
            print("4指令，巡磁点亮个数:", self.nose1_count, ',nose_index=', nose_index)
            if (self.nose1_count == 0):
                break
        # Step 3: 继续开车
        print("已经脱离巡磁")
        while True:
            (nose_index, self.nose1_count) = self.nose1_read()
            print("已走出过巡磁,巡磁值:", nose_index)
            if (nose_index > 3 and nose_index < 11):
                print("已经进入巡磁正中")
                break
        # Step 4 停车
        self.feet.stop()
        return True

    def safe_go_6(self):
        # step 1 先开始转动
        self.feet.set_speed_pwm(100, -100)
        # self.feet.set_speed_mps(0.08,-0.08)
        time.sleep(1)
        # # Step 2A 脱磁, 停车
        while True:
            (nose_index,self.nose1_count) = self.nose1_read()
            print("巡磁点亮个数:",self.nose1_count)
            if (self.nose1_count == 0):
                break
        # Step 3: 继续开车
        print("已经脱离巡磁")
        while True:
            (nose_index,self.nose1_count) = self.nose1_read()
            print("巡磁值:",nose_index)
            if (nose_index > 4 and nose_index < 10):
                print("已经进入巡磁正中")
                break
        # Step 4 停车
        self.feet.set_speed_pwm(0, 0)
        # self.feet.set_speed_mps(0, 0)
        return True

    def safe_go_5(self):
        self.mouth_ingore_flag = True
        # self.feet.stop()
        # time.sleep(5)
        # return True
        ##############################
        # step 1 判断脱磁条
        (nose_index, self.nose1_count) = self.nose1_read()
        print("5指令巡磁点亮个数:", self.nose1_count)
        if (self.nose1_count == 0):
            return False

        # 读取rfid数据并处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()

        # 读取超声避障数据并处理
        #radar_data = self.ear_read()
        #self.radar_after_read(radar_data)

        # # step 1 忽略里程
        start_time = time.time()
        while True:
            self.follow_three_step()
            end_time=time.time()
            if(end_time-start_time>1):
                self.mouth_ingore_flag = False
                break

        while True:
            self.follow_three_step()
            # if(self.nose1_count>10):
            #     break
            # if(self.nose1_count==0):
            #     break
            if(self.mouth_new_rfid_count>=1):
                break
        # self.feet.stop()
        return True

    def safe_go_0(self):
        self.feet.stop()
        return True

    def safe_go_2(self):
        self.mouth_ingore_flag = True
        # # step 1 判断脱磁条

        (nose_index, self.nose1_count) = self.nose1_read()
        print("巡磁点亮个数:", self.nose1_count)
        if (self.nose1_count == 0):
            # TODO 脱磁执行错误处理, 100系列:巡磁出错
            self.deal_error(self.ERROR_CODE_OUT_OF_MAGNET, '脱磁')
            # return False
        # 读取rfid数据并处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 读取超声避障数据并处理
        #radar_data = self.ear_read()
        #self.radar_after_read(radar_data)

        # step 1 忽略里程
        start_time = time.time()
        while True:
            self.follow_one_step()
            end_time=time.time()
            if (end_time-start_time>1):
                print('忽略里程结束')
                self.mouth_ingore_flag = False
                break
        while True:
            self.follow_one_step()
            # if(self.nose1_count>10):
            #     break
            # if(self.nose1_count==0):
            #     self.feet.stop()
            if(self.mouth_new_rfid_count>=1):
                break
        return True

    def follow_one_step(self):
        time2 = time.time()
        # RFID读取和处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 避障读取和处理
        #radar_data = self.ear_read()
        #self.radar_after_read(radar_data)  # 将数据写入到ear_this_radar_id
        print("雷达点云数据:",self.ear_this_radar_id)
        print("RFID数据self.mouth_this_rfid_id:",self.mouth_this_rfid_id)
        print("RFID数据self.mouth_last_rfid_id:",self.mouth_last_rfid_id)
        (nose1_index, self.nose1_count) = self.nose1_read()
        self.set_states()
        if self.nose1_count == 0:
            # 脱磁停车
            nose_target_speed1 = 0
            nose_target_speed2 = 0
        else:
            # 根据巡磁,计算前后巡磁的姿态
	        self.nose1_dx = self.NOSE_BIT_WIDTH * (nose1_index - 8.5)
	        self.nose1_count=self.nose1_count
	        print("dx:", self.nose1_dx)
	        self.r = 0
	        if abs(self.nose1_dx) < 0.005:
	            self.r = 0
	        elif abs(self.nose1_dx) <= 0.02:
                # self.r = 0.03
	            self.r = 0.02
	        elif abs(self.nose1_dx) <= 0.04:
	            # self.r = 0.05
	            self.r = 0.5/2
	        elif abs(self.nose1_dx) <= 0.05:
                # self.r = 0.1
	            self.r = 0.8/2
	        else:
                # self.r = 0.15
	            self.r = 1.4/2
	        print("self.r：", self.r)
	        v = 0.3
	        if self.nose1_dx == 0:
	            nose_target_speed1 = v
	            nose_target_speed2 = v
	        elif self.nose1_dx > 0:
	            # nose_target_speed1 = v
	            # nose_target_speed2 = v * (1 - self.r)
	            # 原来的
	            nose_target_speed1 = v * (1 - self.r)
	            nose_target_speed2 = v
	        else:  # (self.nose1_dx < 0):
                # nose_target_speed1 = v* (1 - self.r)
	            # nose_target_speed2 = v
	            # 原来的
	            nose_target_speed1 = v
	            nose_target_speed2 = v * (1 - self.r)
        time3 = time.time()
        print("开始调用电机时间", time3)
        self.sp_dict["index"] = nose1_index
        self.sp_dict["count"] = self.nose1_count
        self.sp_dict["dx"] = self.nose1_dx
        self.sp_dict["left"] = nose_target_speed1
        self.sp_dict["right"] = nose_target_speed2
        self.sp_dict["self.r"] = self.r
        print("speed:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        time4 = time.time()
        print("step时间差:", (time4 - time2) * 1000, "电机调用时间差：", (time4 - time3) * 1000)
        # self.sp_dict["timecha"] = (time4-time3)*1000
        self.sp_list.append(self.sp_dict)
        self.sp_dict = {}
        return True

    def follow_three_step(self):
        time2 = time.time()
        # RFID读取和处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 避障读取和处理
        # radar_data = self.ear_read()
        # self.radar_after_read(radar_data)  # 将数据写入到ear_this_radar_id
        print("雷达点云数据:", self.ear_this_radar_id)
        print("RFID数据self.mouth_this_rfid_id:", self.mouth_this_rfid_id)
        print("RFID数据self.mouth_last_rfid_id:", self.mouth_last_rfid_id)
        (nose1_index, self.nose1_count) = self.nose1_read()
        self.set_states()
        if self.nose1_count == 0:
            # 脱磁停车
            nose_target_speed1 = 0
            nose_target_speed2 = 0
        else:
            # 根据巡磁,计算前后巡磁的姿态
            self.nose1_dx = self.NOSE_BIT_WIDTH * (nose1_index - 8.5)
            self.nose1_count = self.nose1_count
            print("dx:", self.nose1_dx)
            self.r = 0
            if abs(self.nose1_dx) < 0.005:
                self.r = 0
            elif abs(self.nose1_dx) <= 0.02:
                # self.r = 0.03
                self.r = 0.03/2
            elif abs(self.nose1_dx) <= 0.04:
                # self.r = 0.05
                self.r = 0.2
            elif abs(self.nose1_dx) <= 0.05:
                # self.r = 0.1
                self.r = 0.3
            else:
                # self.r = 0.15
                self.r = 0.5
            print("self.r：", self.r)
            v = 0.2
            if self.nose1_dx == 0:
                nose_target_speed1 = v
                nose_target_speed2 = v
            elif self.nose1_dx > 0:
                # nose_target_speed1 = v
                # nose_target_speed2 = v * (1 - self.r)
                # 原来的
                nose_target_speed1 = v * (1 - self.r)
                nose_target_speed2 = v
            else:  # (self.nose1_dx < 0):
                # nose_target_speed1 = v* (1 - self.r)
                # nose_target_speed2 = v
                # 原来的
                nose_target_speed1 = v
                nose_target_speed2 = v * (1 - self.r)
        time3 = time.time()
        print("开始调用电机时间", time3)
        self.sp_dict["index"] = nose1_index
        self.sp_dict["count"] = self.nose1_count
        self.sp_dict["dx"] = self.nose1_dx
        self.sp_dict["left"] = nose_target_speed1
        self.sp_dict["right"] = nose_target_speed2
        self.sp_dict["self.r"] = self.r
        print("speed:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        time4 = time.time()
        print("step时间差:", (time4 - time2) * 1000, "电机调用时间差：", (time4 - time3) * 1000)
        # self.sp_dict["timecha"] = (time4-time3)*1000
        self.sp_list.append(self.sp_dict)
        self.sp_dict = {}
        return True
        # v = 50
        # if self.nose1_dx == 0:
        #     nose_target_speed1 = v
        #     nose_target_speed2 = v
        # elif self.nose1_dx > 0:
        #     nose_target_speed2 = v
        #     nose_target_speed1 = v* (1 - self.r)
        # else:  # (self.nose1_dx < 0):
        #     nose_target_speed2 = v* (1 - self.r)
        #     nose_target_speed1 = v
        # t1=time.time()
        # print("开始设置速度的时间t1=",t1)
        # self.feet.set_speed_pwm(nose_target_speed1,nose_target_speed2)
        # t2 = time.time()
        # print("速度设置完毕的时间t2=", t2)
        # print("时间差△t=", t2-t1)
        # return True

    def nose1_read(self):
        self.magnet1.read_all()
        # a = self.magnet1.get_int_value(self.magnet1.realtime_magnet)
        print('读取到的巡磁=', self.magnet1.channel_list[0]['dr'])
        a = self.magnet1.get_int_value(self.magnet1.channel_list[0]['dr'])
        b = self.magnet1.get_magnet_index_count(a)
        return b
        # 读取RFID卡号

    def mouth1_read(self):
        self.rfid1.read_all(self.rfid1_client)
        #34 42 62 96 71 03
        realtime_rfid = self.rfid1.channel_list[0]['dr']
        print('读取到的rfid=', realtime_rfid)
        # 由于卡后两位可能变化,返回时再次截取rfid卡号,只保留前面4个16进制数据
        return realtime_rfid[0:11].strip()

    def rfid_after_read(self):
        if self.mouth_this_rfid_id != '' and self.mouth_this_rfid_id != self.mouth_last_rfid_id:
            if not self.mouth_ingore_flag:
            	self.mouth_new_rfid_count += 1
            self.mouth_last_rfid_id = self.mouth_this_rfid_id
        print("id=",self.mouth_this_rfid_id,":","last_id=",self.mouth_last_rfid_id,"mouth_new_rfid_count=",self.mouth_new_rfid_count)

        # 根据卡号判断是否在充电
        self.is_charging = self.check_is_charging()

    # 检测是否处于充电状态
    def check_is_charging(self):
        if self.mouth_this_rfid_id == '':
            return False
        else:
            for x in self.charging_rfid_list:
                if self.mouth_this_rfid_id == x:
                    return True
            return False
    def set_states(self):
        self.tcpcommander.main_state = self.main_state
        self.tcpcommander.voltage = self.voltage_value
        self.tcpcommander.is_charging = self.is_charging
        self.tcpcommander.x = self.x
        self.tcpcommander.y = self.y
        self.tcpcommander.w = self.w
        self.tcpcommander.last_rfid=self.mouth_last_rfid_id
        self.tcpcommander.this_rfid=self.mouth_this_rfid_id
        self.tcpcommander.q_len = self.task_queue.qsize()
    def ear_read(self):
        result = self.radar.read_all(self.radar_client)
        print('读到避障数据=', result)
        return result
    def radar_after_read(self, radar_data):
        # 处理读数, 返回实际距离值
        # 处理前先把原来的数据清空
        self.ear_this_radar_id.clear()
        # radar_data格式:'F5 80 80 80 80 80 80 08 7F 87',中间8个值是避障数据
        if radar_data != '':
            radar_values = radar_data[3:26].strip().split(' ')
            for x in radar_values:
                print(x, ', len(x)=', len(x), ', 10进制值=', int(x, 16))
                y = int(x, 16)
                # y值说明:实际距离为读数* 5, 距离为30cm-250cm间, 单位:cm (0x01:盲区0-30cm内  0x7F:250cm内无障碍物  0x80:无探头)
                # ear_this_radar_id中保存读数*5的数值, 635表示250cm内无障碍物, 640表示未接探头
                self.ear_this_radar_id.append(y * 5)

        for i in self.ear_this_radar_id:
            if i == 640:
                # 没有接避障探头,永不避障
                self.ear_stop = False
                break

            # 进入盲区,避障停车
            if i <= 30:
                self.ear_stop = True
                break

    def follow_two_step(self):
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()

        # 避障读取和处理
        #radar_data = self.ear_read()
        #self.radar_after_read(radar_data)  # 将数据写入到ear_this_radar_id
        print("雷达点云数据:",self.ear_this_radar_id)
        print("RFID数据self.mouth_this_rfid_id:",self.mouth_this_rfid_id)
        print("RFID数据self.mouth_last_rfid_id:",self.mouth_last_rfid_id)
        (nose2_index, self.nose2_count) = self.nose2_read()
        self.set_states()

        if self.nose2_count == 0:
            # 脱磁停车
            nose_target_speed1 = 0
            nose_target_speed2 = 0
        else:
            # 根据巡磁,计算前后巡磁的姿态
	        self.nose2_dx = self.NOSE_BIT_WIDTH * (nose2_index - 8.5)
	        self.nose2_count=self.nose2_count
	        print("dx:", self.nose2_dx)
	        self.r = 0
	        if abs(self.nose2_dx) < 0.005:
	            self.r = 0
	        elif abs(self.nose2_dx) <= 0.02:
	            self.r = 0.03/2
	        elif abs(self.nose2_dx) <= 0.04:
	            self.r = 0.06
	        elif abs(self.nose2_dx) <= 0.05:
	            self.r = 0.13
	        else:
	            self.r = 0.2
	        print("self.r：", self.r)
	        v = -0.2
	        if self.nose2_dx == 0:
	            nose_target_speed1 = v
	            nose_target_speed2 = v
	        elif self.nose2_dx > 0:
	            # nose_target_speed1 = v * (1 - self.r)
	            nose_target_speed1 = v
	            nose_target_speed2 = v * (1 - self.r)
	            # nose_target_speed2 = v
	        else:  # (self.nose1_dx < 0):
	            # nose_target_speed1 = v
	            nose_target_speed1 = v * (1 - self.r)
	            nose_target_speed2 = v
	            # nose_target_speed2 = v * (1 - self.r)
        print("左右轮速度:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        return True

    def nose2_read(self):
        self.magnet1.read_all()
        # a = self.magnet1.get_int_value(self.magnet1.realtime_magnet)
        print('读取到的巡磁=', self.magnet1.channel_list[1]['dr'])
        a = self.magnet1.get_int_value(self.magnet1.channel_list[1]['dr'])
        b = self.magnet1.get_magnet_index_count(a)
        return b

    # 003.巡磁出错判断算法
    def sim_run(self, cmd, x, y, w):
        print('sim_run(), cmd=',cmd,', x=',x,', y=',y,', w=',w)
        if cmd == '2' or cmd == '5':
            # 以射频门朝向起始点位置作为w=0的方向
            if w == 0:
                return x + 1, y, w
            elif w == 90:
                return x, y + 1, w
            elif w == 180:
                return x - 1, y, w
            elif w == 270:
                return x, y - 1, w
            else:
                return x, y, w
        elif cmd == '4':
            # 转弯调整车子角度
            if w == 270:
                return x, y, 0
            else:
                return x, y, w + 90
        elif cmd == '6':
            # 转弯调整车子角度
            if w == 0:
                return x, y, 270
            else:
                return x, y, w - 90
        elif cmd == '8':
            if w == 0:
                return x - 1, y, w
            elif w == 90:
                return x, y - 1, w
            elif w == 180:
                return x + 1, y, w
            elif w == 270:
                return x, y + 1, w
            else:
                return x, y ,w
        elif cmd == '22' or cmd == '55':
            if w == 0:
                return x + 2, y, w
            elif w == 90:
                return x, y + 2, w
            elif w == 180:
                return x - 2, y, w
            elif w == 270:
                return x, y - 2, w
            else:
                return x, y, w
        elif cmd == '88':
            if w == 0:
                return x - 2, y, w
            elif w == 90:
                return x, y - 2, w
            elif w == 180:
                return x + 2, y, w
            elif w == 270:
                return x, y + 2, w
            else:
                return x, y ,w
        elif cmd == '222' or cmd == '555':
            if w == 0:
                return x + 3, y, w
            elif w == 90:
                return x, y + 3, w
            elif w == 180:
                return x - 3, y, w
            elif w == 270:
                return x, y - 3, w
            else:
                return x, y, w
        elif cmd == '888':
            if w == 0:
                return x - 3, y, w
            elif w == 90:
                return x, y - 3, w
            elif w == 180:
                return x + 3, y, w
            elif w == 270:
                return x, y + 3, w
            else:
                return x, y ,w
        else:
            print('指令:', cmd, ', 不执行指令后操作')
            return x, y ,w

    def check_read_sim_rfid(self, read_x, read_y, sim_x, sim_y, sim_w):
        if read_x == sim_x and read_y == sim_y:
            return True
        else:
            return False

    # 根据rfid卡查询其坐标
    def read_rfid(self):
        print('-->read_rfid中判断rfid卡, 读到的卡=', self.mouth_this_rfid_id, ',rfid长度=', len(self.mouth_this_rfid_id), ',上一次读到的卡=', self.mouth_last_rfid_id)
        for x in self.rfid_list:
            if x['rfid1'] == self.mouth_this_rfid_id or x['rfid2'] == self.mouth_this_rfid_id or x['rfid3'] == self.mouth_this_rfid_id:
                return x['x'], x['y']
        print('所有rfid卡都不匹配,返回(-1,-1)')
        return -1, -1

    # 004.巡磁出错更正算法,得到返回指令
    def get_go_str(self, read_x, read_y, sim_x, sim_y, sim_w, cmd):
        print('即将生成倒退指令方法get_go_str(), 当前读到的位置=(',read_x,',',read_y,'), 预期位置=(',sim_x,',',sim_y,',',sim_w,')')
        gostr = ''
        # 通过有限次数(三步)内能模拟走到读取到的RFID卡位置,来确定后退的指令
        # 为找到rfid卡,使用满速行驶指令5/8,不使用2,减少再次漏卡的几率
        test_cmds = ['5', '8', '55', '88', '555', '888']
        for x in range(len(test_cmds)):
            # 在计算的预期点位基础上再次推算看哪一个指令可以走到当前错误的点位上
            (go_x, go_y , go_w) = self.sim_run(cmd, sim_x, sim_y, sim_w)
            if go_x == read_x and go_y == read_y:
                print('x=', x, ', 对应指令:', test_cmds[x], ' 可以从预期位置到达当前位置')
                gostr = self.get_goback_str(test_cmds[x])
                break
        return gostr

    # 求能从漏卡点倒退到预期点的指令
    def get_goback_str(self,cmd):
        if cmd == '5':
            return '8'
        elif cmd == '8':
            return '5'
        elif cmd == '55':
            return '88'
        elif cmd == '88':
            return '55'
        elif cmd == '555':
            return '888'
        elif cmd == '888':
            return '555'

    def read_rfidjson(self):
        print('开始读取rfid配置')
        res = open("data/Rfid.json",encoding='utf-8').read()
        self.rfid_list = json.loads(res)  # list[dict1, dict2]
        # print('rfids=', self.rfid_list, type(self.rfid_list))
        # for x in self.rfid_list:
        #     print('x=', x, type(x), ', 从中取值id=', x['id'], ', rfids=[', x['rfid1'], x['rfid2'], x['rfid3'], '], x=', x['x'], ', y=', x['y'])  # dict
        return

    def up(self):
        print('顶升升起，等待7秒')
        self.feet.lift_up()

    def down(self):
        print('顶升下降，等待7秒')
        self.feet.lift_down()

#类的单元测试函数
def test():
    robot1 = Robot()
    robot1.start()  # runnint task t1
    return

if __name__ == "__main__":
    # test()

    feet = PwmMotor2()
    # self.feet.config("COM3", 0x26, 9600)
    # feet.config("COM13", 0x25, 9600)
    feet.config("/dev/ttyUSB0", 0x25, 38400)
    feet.connect()
    feet.lift_down()

    # motor=PwmMotor2()
    # motor.config("COM2", 0x25, 9600)
    # motor.connect()

    # 测试读取rfid配置
    # Robot().read_rfidjson()


