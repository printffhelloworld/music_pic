from shoeagv.iot_modbus_rtu_xyd1210 import ModbusRtuXyd1210

class backbone():
    rtu = None
    def init(self):
        self.rtu = ModbusRtuXyd1210()
        self.rtu.config('COM3', 21)
        return

    def up(self):
        print("进入顶起")
        ch5 = self.rtu.read_X5()
        if(ch5 == 1):
            print("已处于最高点，无法再顶")
            return  True
        print("开始顶起")
        self.rtu.write_Y2(0)
        self.rtu.write_Y3(1)
        while True:
            ch5 = self.rtu.read_X5()
            if(ch5 == 1):
                break
        self.rtu.write_Y2(0)
        self.rtu.write_Y3(0)
        print("顶起结束")
        return True

    def down(self):
        print("进入下降")
        ch6 = self.rtu.read_X6()
        if (ch6 == 1):
            print("已处于最低点，无法再降")
            return True
        print("开始下降")
        self.rtu.write_Y2(1)
        self.rtu.write_Y3(0)
        while True:
            ch6 = self.rtu.read_X6()
            if (ch6 == 1):
                break
        self.rtu.write_Y2(0)
        self.rtu.write_Y3(0)
        print("顶起结束")
        return True
        return

if __name__ == '__main__':
    back = backbone()
    back.init()
    back.rtu.connect()
    back.down()