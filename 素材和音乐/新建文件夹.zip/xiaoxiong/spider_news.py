# _*_coding:utf-8_*_
# Author ：Little Chen
# IDE    : PyCharm
import time

from pyquery import PyQuery
import requests
import os
import re

# proxy = "39.105.28.28:8118"
header = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Mobile Safari/537.36"
}


# proxies = {
#     "http": "http://" + proxy,
#     "https": "https://" + proxy
# }


def make_dir():
    path = os.getcwd()
    path += "\\video"
    print("path=", path)
    if not os.path.exists(path):
        os.mkdir(path)


def download_video(url_video, name_video):
    response2 = requests.get(url_video, headers=header)
    with open("video\\" + name_video, "wb") as f:
        f.write(response2.content)
    print("已保存")


def get_video_list(url):
    response = requests.get(url, headers=header)
    print(response.encoding)
    response.encoding = 'gb2312'
    html = response.text
    # print(html)
    pq_html = PyQuery(html)
    url_a = pq_html("td.hui12 table td tr")
    count = 0
    for a in list(url_a):
        pq_a = PyQuery(a)
        url_video = pq_a.find("a").attr("href")
        name_video = pq_a.find("a").attr("title") + ".mp4"
        count += 1
        if not count % 2 == 0:
            print(f"{name_video}:{url_video}")
            if not os.path.exists(os.getcwd() + "\\video\\" + name_video):
                response2 = requests.get(url_video, headers=header)
                url_mp4 = PyQuery(response2.text)("video").find("source").attr("src")
                print(url_mp4)
                download_video(url_mp4, name_video)
                time.sleep(1)
            else:
                print("已存在")


if __name__ == '__main__':
    for num in range(60, 0, -1):
        if num == 60:
            url = "http://qxsp.qhnews.com/wsp/"
        num = str(num).zfill(2)
        url = "http://qxsp.qhnews.com/system/more/17206000000000000/0000/17206000000000000_000000{}.shtml".format(num)
        make_dir()
        get_video_list(url)
