from socket import *

# host = '192.168.1.156' #客服端需要绑定服务器ip
host = '127.0.0.1' #客服端需要绑定服务器ip
port = 13140 #通讯端口，客服端和服务器端需要统一
addr = (host, port)
bufsize = 1024 #字节大小

tcpClient = socket(AF_INET, SOCK_STREAM)  # 这里的参数和UDP不一样。#创建套接字
tcpClient.connect(addr)  # 由于tcp三次握手机制，需要先连接。#创立连接

while True:
    data = input('>>> ').encode(encoding="utf-8") #数据输入
    if not data: #判断数据是否为空
        break
    # 数据收发和UDP基本一致
    tcpClient.send(data) #发送数据
    data = tcpClient.recv(bufsize).decode(encoding="utf-8") #接受来自服务器端的数据
    print(data)

tcpClient.close()
