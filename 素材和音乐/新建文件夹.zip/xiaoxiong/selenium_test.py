# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2020/7/23
# Time   : 16:54
# IDE    : PyCharm
import time

from selenium import webdriver
from tkinter import *


def test_selenium():
    browser = webdriver.Chrome()
    browser.get("http://www.baidu.com")
    browser.find_element_by_xpath("//*[@id='kw']").send_keys("selenium")
    time.sleep(1)
    browser.find_element_by_xpath("//*[@id='su']").click()
    time.sleep(10)
    # print(browser.page_source)
    # browser.close()


def tesk_tkin():
    tk = Tk()
    tk.title("地瓜地瓜我是地雷")
    tk.geometry("400x200+800+400")
    btn = Button(tk, text="fckfckfckfck", command=co)
    btn.grid(row=i // 4, column=i % 4)
    btn.bind_all('5', eventhandler)
    tk.mainloop()


global i
i = 0


def co():
    global i
    i += 1
    print(i)
    if i == 10:
        i = 0


def eventhandler(event):
    if event.keysym == "5":
        # print('按下了5')
        co()
    elif event.keysym == 'Right':
        print('按下了方向键右键！')


if __name__ == '__main__':
    # test_selenium()
    tesk_tkin()
