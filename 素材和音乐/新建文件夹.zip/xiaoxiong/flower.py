﻿# 爬虫：1 目标网站 2.工具：安装 3.脚本：编写

# requeste:pip install requests
# bs4: pip install beautifulsoup
# 解析器：pip install html5lib、lxml

# get_xiaohua_info():爬取校花详细信息
def get_xiaohua_info():
    # 1.模拟浏览器发出请求 http:get\post
    # 2.订制头部信息：伪装浏览器提交 隐式信息（系统，浏览器，渲染引擎）
    herd = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.92 Safari/537.36'}
    respones = requests.get(url=URL, headers=herd)
    # 3.查看状态码：200：成功，404：失败
    print(respones.status_code)
    if respones.status_code == 200:
        # 4.设置编码格式
        print(respones.encoding)
        respones.encoding = 'utf-8'
        # 5.获取响应内容：网页返回的源代码
        # respones.text：字符流
        # respones.content：二进制流

        # print(respones.text)

        # 6.通过工具bs4，定制过滤器筛选内容
        # BeautifulSoup：1.二进制的内容 2.指定解析器：html5lib\lxml
        bs = BeautifulSoup(respones.content, 'html5lib')
        # 7.定义过滤规则：1.div lanmu 2.div ul 3.div ul li
        # 8.参数 1.根据标签名字选择 2.attrs：根据属性名=values选择
        div_list = bs.find_all('div', attrs={'class': 'all_lanmu'})
        file = open('校花网数据.txt', 'w', encoding='utf-8')
        txt = ''
        for div_lanmu in div_list:  # 每次循环代表着一条栏目
            div_title = div_lanmu.find('div', attrs={'class': 'title'})
            a_title = div_title.find('a')
            # tag.string:获取标签中的内容
            print(a_title.string)
            lanmu_title = a_title.string
            txt += lanmu_title + '\n\n'
            ul = div_lanmu.find('ul', attrs={'class': 'twoline'})
            if ul != None:  # 判断是否为空，不为空则爬取
                li_list = ul.find_all('li')
                # 采集目标：1.名字 2.学校 3.点赞 4.路径（图片、二级页面）
                for li in li_list:
                    name = li.find('span').string
                    school = li.find('b', attrs={'class': 'b1'}).string
                    like = li.find('b', attrs={'class': 'b2'}).string
                    img_path = li.find('img')['lazysrc']
                    two_page = li.find('a')['href']
                    print(name, school, like, img_path, two_page)
                    txt += '姓名：' + name + '\n'
                    txt += '学校：' + school + '\n'
                    txt += '点赞：' + like + '\n'
                    # 如果图片路径不存在域名则拼接
                    if URL not in img_path:
                        img_path = URL + img_path

                    txt += '图片：' + img_path + '\n'
                    txt += '详情页：' + two_page + '\n'
                    # 下载
                    get_xiaohua_pic(img_path=img_path, name=name)
        file.write(txt)
        file.close();
        print("爬取完毕-----------------------------------")
    else:
        print("你访问的内容不合法，访问失败！")


# get_xiaohua_pic():爬去校花的图片并下载
def get_xiaohua_pic(img_path, name):
    download = 'download'
    # 13.判断目录是否存在
    if not os.path.exists(download):
        # 14.创建
        os.makedirs(download)
    # 15.捕捉异常

    # 获得图片原本的名称
    # name=img_path.split('/')  #拆分字符串
    # name=name[len(name)-1]   #获取最后一段
    # print(name)

    try:
        urlretrieve(img_path, download + '/' + name + '.jpg')
        print(name, '下载中------------------')
    except:
        print('下载失败！')


# Python入口
if __name__ == '__main__':
    # 1.目标网站
    URL = "http://www.xiaohuar.com/"
    # 2.导入工具
    import requests
    from bs4 import BeautifulSoup
    import os  # 对目录的操作：创建删除移动检测是否存在
    from urllib.request import urlretrieve  # 专门下载网络资源

    print('导包成功')
    # 3.脚本执行
    get_xiaohua_info()
