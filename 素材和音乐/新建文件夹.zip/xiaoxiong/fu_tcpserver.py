from socket import *

host = ''
port = 13140 #端口
bufsize = 1024
addr = (host, port)

tcpServer = socket(AF_INET, SOCK_STREAM)
tcpServer.bind(addr)
tcpServer.listen(5)  # 这里设置监听数为5(默认值),有点类似多线程。

while True:
    print('Waiting for connection...')
    tcpClient, addr = tcpServer.accept()  # 拿到5个中一个监听的tcp对象和地址
    print('[+]...connected from:', addr)
    print('[+]...connected from:', tcpClient)

    while True:
        cmd = tcpClient.recv(bufsize).decode(encoding="utf-8")#接受来自客服端的信息
        print('   [-]cmd:', cmd)
        if not cmd:
            break
        returndata = cmd
        tcpClient.send(returndata.encode(encoding="utf-8"))#向客服端发送信息

    tcpClient.close()  #
    print(addr, 'End')
tcpServer.close()  # 两次关闭，第一次是tcp对象，第二次是tcp服务器
