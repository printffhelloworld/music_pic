# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2020/10/7
# Time   : 16:08
# IDE    : PyCharm
# 1.引入类库
from numpy import array, dot, exp, random

# 2.加载数据
X = array([[0, 0, 1], [1, 1, 1], [1, 0, 1], [0, 1, 1]])
y = array([[0, 1, 1, 0]]).T
# 3.设置随机权重
random.seed(1)
weights = random.random((3, 1)) * 2 - 1  # 控制产生的权重值在+-1之间
# 4.循环
for it in range(10000):
    # 利用矩阵点乘一次性计算4个z出来
    z = dot(X, weights)
    # 使用Sigmoid，计算最终output
    output = 1 / (1 + exp(-z))
    # 看看我们计算的和实际发生的有多大误差
    error = y - output
    # 计算斜率
    slope = output * (1 - output)
    # 计算增量
    delta = error * slope
    # 更新权重
    weights = weights + dot(X.T, delta)
    print(weights)
print(1 / (1 + exp(-dot([[1, 0, 0]], weights))))
