import os
import cv2
import sys


def get_vids(v_path):
    vs_list = []
    for i, j, k in os.walk(v_path):
        for vid in k:
            print(i)
            print(j)
            print(k)
            if vid.endswith(".mp4"):
                vs_list.append(i+"/"+vid)
    return vs_list


def con_time(vs_list):
    t_time = 0
    for vid in vs_list:
        cap = cv2.VideoCapture(vid)
        fps = cap.get(5)
        all_fs = cap.get(7)
        print("fps:",fps)
        print("all_fs:",all_fs)
        vid_t = all_fs/fps/60
        t_time += vid_t
        cap.release()
    print(t_time)


if __name__ == '__main__':
    vid_path = r"F:\JJdown\Download"
    vids_list = get_vids(vid_path)
    print(vids_list)
    con_time(vids_list)
