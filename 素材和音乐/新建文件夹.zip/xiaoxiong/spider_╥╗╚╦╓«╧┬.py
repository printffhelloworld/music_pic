# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2020/7/26
# Time   : 19:31
# IDE    : PyCharm
from pyquery import PyQuery
import requests
import os
import re
import ssl

# 表示忽略未经核实的ssl正书认证
ssl._create_default_https_context = ssl._create_unverified_context


def make_dir(dir):
    path = os.getcwd()
    path += "\\一人之下\\" + dir
    print("path=", path)
    if not os.path.exists(path):
        os.mkdir(path)


def download_ji(url_ji, dir_name):
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Mobile Safari/537.36",
        "Host": "m.lbsulu.com",
        "Cookie": "fikker-PSvU-VeKo=TmVqHiRMNIxsIuJqPijwngOL4WRuKUF7; fikker-PSvU-VeKo=TmVqHiRMNIxsIuJqPijwngOL4WRuKUF7; __tins__20614303=%7B%22sid%22%3A%201596119118863%2C%20%22vd%22%3A%201%2C%20%22expires%22%3A%201596120918863%7D; __51cke__=; __51laig__=1; UM_distinctid=173a01cf4591cc-031a66fed19465-3c634103-144000-173a01cf45a127; CNZZDATA204631=cnzz_eid%3D839632413-1596118129-%26ntime%3D1596118129"
    }
    print(url_ji)
    make_dir(dir_name)
    response2 = requests.get(url_ji, headers=headers)
    print(response2)
    html = response2.text
    pq_html = PyQuery(html)
    url_img = pq_html("div#images img").attr("src")
    pag_info = pq_html("div#images p").text()
    print(url_img, ":", pag_info)


def get_video(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Mobile Safari/537.36",
        "cookie": "fikker-AKLl-sfaT=sJerw6an7fuRI4YbQrAxGx5p1HSbixKV; fikker-AKLl-sfaT=sJerw6an7fuRI4YbQrAxGx5p1HSbixKV; fikker-CKyl-ERSZ=mPA2Wla6gbaxkxSXQlIfNX5pEhs4kvgR; fikker-CKyl-ERSZ=mPA2Wla6gbaxkxSXQlIfNX5pEhs4kvgR; __tins__20614303=%7B%22sid%22%3A%201595763128704%2C%20%22vd%22%3A%201%2C%20%22expires%22%3A%201595764928704%7D; __51cke__=; __51laig__=1; UM_distinctid=1738ae503c6ca-098c1bf3ea5cb7-5a472316-144000-1738ae503c7bc; CNZZDATA204631=cnzz_eid%3D1513438676-1595760611-%26ntime%3D1595760611; fikker-PSvU-VeKo=TmVqHiRMNIxsIuJqPijwngOL4WRuKUF7; fikker-PSvU-VeKo=TmVqHiRMNIxsIuJqPijwngOL4WRuKUF7",
        "X-Via": "1.1 pc-201908211654 (random:688387 Fikker/Webcache/3.7.5)",
        "ETag": "W/'5f1b3f94-2a7a'",
        "Vary": "Accept-Encoding"
    }
    response = requests.get(url, headers=headers, verify=False)
    print(response)
    response.encoding = 'gbk'
    html = response.text
    # print(html)
    pq_html = PyQuery(html)
    lis = pq_html("ul#mh-chapter-list-ol-0 li").items()
    print(lis)
    for li in lis:
        pq_li = PyQuery(li)
        url_ji = "http://m.lbsulu.com" + li("a").attr("href")
        dir_name = li("span").text()
        download_ji(url_ji, dir_name)

    # url_video = re.findall('srcUrl="(.*?)"', html)
    # print(url_video)

    # name_video = url_video[0].split("/")[-1]
    # print(name_video)
    # if not os.path.exists(os.getcwd() + "\\一人之下\\" + name_video):
    #     response2 = requests.get(url_video[0])
    #     file_video = open("一人之下\\" + name_video, "wb")
    #     file_video.write(response2.content)
    #     file_video.close()
    # else:
    #     print("已存在")


if __name__ == '__main__':
    url = "http://m.lbsulu.com/mh/yirenzhixia/"
    get_video(url)
