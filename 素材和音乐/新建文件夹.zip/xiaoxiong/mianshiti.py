# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2021/1/10
# Time   : 17:50
# IDE    : PyCharm
def answer_1(a, b):
    a = list(str(a))
    b = list(str(b))
    if len(a) == len(b):
        a.sort()
        b.sort()
        if a == b:
            return True
    return False


def max(*args):
    lst = list(args)
    if len(lst) == 0:
        return ("ERROR:Parameter is empty!")
    for i in lst:
        if type(i) != type(lst[0]):
            return ("ERROR:type error！")
    the_max = lst[0]
    for i in lst:
        if i > the_max:
            the_max = i
    return the_max

