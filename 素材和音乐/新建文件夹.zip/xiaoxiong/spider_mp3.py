# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2020/7/26
# Time   : 14:43
# IDE    : PyCharm
#声音网站：耳聆、freesound、http://freesfx.co.uk、soundjay.com、adobe audition_dlc
#声音搜索引擎：淘声网
# doorbell,knock,sneeze,steam whistle
