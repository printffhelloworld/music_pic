# _*_coding:utf-8_*_
# Author ：Little Chen
# IDE    : PyCharm
from pyquery import PyQuery
import requests
import os
import re


def make_dir():
    path = os.getcwd()
    path += "\\video"
    print("path=", path)
    if not os.path.exists(path):
        os.mkdir(path)


def get_video(url):
    response = requests.get(url)
    print(response)
    html = response.text
    url_video = re.findall('srcUrl="(.*?)"', html)
    print(url_video)

    name_video = url_video[0].split("/")[-1]
    print(name_video)
    if not os.path.exists(os.getcwd() + "\\video\\" + name_video):
        response2 = requests.get(url_video[0])
        file_video = open("video\\" + name_video, "wb")
        file_video.write(response2.content)
        file_video.close()
    else:
        print("已存在")


if __name__ == '__main__':
    url = "https://www.pearvideo.com/video_1687077"
    make_dir()
    get_video(url)
