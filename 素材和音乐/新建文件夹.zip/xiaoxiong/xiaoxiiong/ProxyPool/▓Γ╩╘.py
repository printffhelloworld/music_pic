from pyquery import PyQuery as pq
import requests

url = 'http://www.66ip.cn/'
res = requests.get(url)
res.encoding = 'gb2312'
html = res.text
# print(html)
doc = pq(html)
trs = doc('.containerbox table tr:gt(0)').items()
for tr in trs:
    ip = tr.find('td:nth-child(1)').text()
    port = tr.find('td:nth-child(2)').text()
    print(ip, port)
