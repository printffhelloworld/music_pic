from fake_useragent import UserAgent
import requests
from lxml import etree
import time
import os

ua = UserAgent()
headers = {'user-agent': ua.Chrome}
counter = 0

file='shouting'
if not os.path.exists(file):
    os.mkdir(file)
for i in range(1,7):
    print(f"i={i}")
    url='http://www.tuke88.com/soyinxiao/feiji/__zonghe_0_{}.html'.format(i)
    # url='http://www.tuke88.com/soyinxiao/chuifengji.shtml'
    # pro_url = 'http://127.0.0.1:5000/random'
    # proxy = requests.get(pro_url).text
    # proxies = {'https': 'http://{}'.format(proxy)}

    # page = requests.get(url, headers=headers, proxies=proxies)
    page = requests.get(url, headers=headers)
    html = etree.HTML(page.text)
    mp3_urls=html.xpath('//*[@id="audio850995"]/source//@src')
    # print(mp3_urls)
    for mp3_url in mp3_urls:
        if mp3_url.endswith('.mp3'):
            counter += 1
            print(mp3_url)
            with open(file+'\\'+mp3_url.split('/')[-1],'wb') as m:
                try:
                    m.write(requests.get(mp3_url).content)
                except Exception as e:
                    print(e)
            time.sleep(1)
    time.sleep(5)