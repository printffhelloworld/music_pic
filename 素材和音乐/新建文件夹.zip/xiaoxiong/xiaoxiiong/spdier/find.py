# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2020/9/11
# Time   : 21:23
# IDE    : PyCharm
import os
import time

dir_list = ["D:\\", "C:\\", "E:\\", "F:\\", "G:\\", ]
f = open("find_me.txt", "w")
f.write("dakla"  + "\n")
for dir in dir_list:
    f.write("开始遍历" + dir + "\n")
    time.sleep(0.1)
    for root, dirs, files in os.walk(dir):
        for name in files:
            print(name)
            if ".ppt" in name:
                my_path = os.path.join(root, name)
                try:
                    f.write(my_path + "\n")
                    time.sleep(0.1)
                except:
                    pass
f.write("运行结束" + "\n")
time.sleep(1)
f.close()
