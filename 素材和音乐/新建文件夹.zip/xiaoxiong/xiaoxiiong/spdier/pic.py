# _*_coding:utf-8_*_
import os
import shutil

# 原始文件存放目录
src_dir = r"D:\pic\src"
# 挑选出来的文件存放目录
pic_dir = r"D:\pic\pic"

# 判断文件夹是不是存在，不存在就创建
def mkdirs(dir):
    if not os.path.exists(os.path.join(dir)):
        os.makedirs(dir)

# 用来创建 D:\pic\src 目录下的50的文本
def maketexts():
    # 先判断你的电脑里是不是有存放文本的文件夹，没有的话会生成，不然没发创建文本
    mkdirs(src_dir)
    # 循环创建50次
    for i in range(1, 51):
        # 拼接文本的路径和名字，D:\pic\src\AAA_xxx.txt,xxx通过str的zfill(3)方法，转变成三位数的文本，不足三位则前面补0
        txt_name = src_dir + "\\" + "AAA_" + str(i).zfill(3) + ".txt"
        # with open(txt_name, 'w')这个方法打开文件，如果不存在可以自动创建
        with open(txt_name, 'w') as f:
            print(txt_name)

# 分类的函数
def pic_txt():
    # 先拿到50个文本的名字，存在txt_list列表里
    txt_list = os.listdir(src_dir)
    print(txt_list)
    # 循环每个txt
    for txt_name in txt_list:
        # txt的原始路径+名字
        old_txt = src_dir + "\\" + txt_name
        # 列表的index方法可以获得这个元素在列表中的索引，也就是下标
        txt_index = txt_list.index(txt_name)
        # 5是每个文件夹里存5个txt，用下标来对5进行取余可以知道这个下标是不是5的整数倍，如果是，那就要创建新文件夹了
        if txt_index % 5 == 0:
            # 新文件夹的名称，
            pic_dir_name = pic_dir + "\\" + "pic_" + str(txt_index // 5 + 1).zfill(3)
            # D:\pic\pic\pic_xxx
            mkdirs(pic_dir_name)
        # 新文本的路径+名字
        new_txt = pic_dir_name + "\\" + txt_name
        # 执行拷贝命令
        shutil.copy2(old_txt, new_txt)


if __name__ == '__main__':
    # 刚开始没有那50个测试文本，先把这个maketexts()的注释放开，第一次创建后，就可以注释掉了！！然后改代码里pic_txt()方法可以试试其他效果。
    # 记得每次执行前删下上次挑选的结果。路径D:\pic\pic
    maketexts()
    pic_txt()
