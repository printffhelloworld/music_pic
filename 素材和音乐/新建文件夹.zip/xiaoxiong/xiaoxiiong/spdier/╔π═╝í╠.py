from fake_useragent import UserAgent
import requests
from lxml import etree
import time
import os

ua = UserAgent()
headers = {'user-agent': ua.Chrome}
counter = 0

file='shouting'
if not os.path.exists(file):
    os.mkdir(file)
for i in range(1,11):
    print(f"i={i}")
    url='http://699pic.com/music/soundeffect-feiji-{}-0-0-0.html'.format(i)
    # url='http://699pic.com/music/soundeffect-chuifengji.html'
    # pro_url = 'http://127.0.0.1:5000/random'
    # proxy = requests.get(pro_url).text
    # proxies = {'https': 'http://{}'.format(proxy)}

    # page = requests.get(url, headers=headers, proxies=proxies)
    page = requests.get(url, headers=headers)
    html = etree.HTML(page.text)
    # label_=html.xpath('/html/body/div[3]/div[3]/ul/li/div[1]/div/div[1]//text()')
    # print(label_)
    mp3_urls=html.xpath('/html/body/div[3]/div[3]/ul/li/div[2]/audio/source//@src')
    # mp3_urls.remove('//img95.699pic.com/music_sound_effect/547/474/5d664d023c450.mp3')
    # mp3_urls.remove('//img95.699pic.com/music_sound_effect/031/605/bq2oepjipt35edsavaj0.mp3')
    print(mp3_urls)


    for mp3_url in mp3_urls:
        counter+=1
        with open(file+'\\'+mp3_url.split('/')[-1],'wb') as m:
            # m.write(requests.get('http:'+mp3_url,headers=headers,proxies=proxies).content)
            m.write(requests.get('http:'+mp3_url,headers=headers).content)
            print('http:'+mp3_url)
        time.sleep(1)
    time.sleep(5)
print('共计{}条语料'.format(counter))