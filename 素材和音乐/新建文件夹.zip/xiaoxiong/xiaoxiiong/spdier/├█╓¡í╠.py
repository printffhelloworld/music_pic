from fake_useragent import UserAgent
import requests
from lxml import etree
import time
import os

ua = UserAgent()
counter = 0

file='shouting'
if not os.path.exists(file):
    os.mkdir(file)
headers = {'user-agent': ua.Chrome}


for i in range(1,18):
    print(f"i={i}")
    url='https://www.51miz.com/so-sound/85854-0--0-default/p_{}/'.format(i)
    # url = 'https://www.51miz.com/so-sound/1558565.html'

    # pro_url = 'http://127.0.0.1:5000/random'
    # proxy = requests.get(pro_url).text
    # proxies = {'https': 'http://{}'.format(proxy)}

    page = requests.get(url, headers=headers)
    # print(page.text)
    html = etree.HTML(page.text)

    mp3_urls=html.xpath('/html/body/div[3]/div[3]/div[4]/div/div/div[3]/div[1]//@data-mp3')
    print(mp3_urls)
    for mp3_url in mp3_urls:
        if mp3_url.endswith('.mp3'):
            counter += 1
            mp3_url = 'http://img.51miz.com/' + mp3_url
            print(mp3_url)
            with open(file+'\\'+mp3_url.split('/')[-1],'wb') as m:
                try:
                    m.write(requests.get(mp3_url).content)
                except Exception as e:
                    print(e)

            time.sleep(1)
    time.sleep(5)
print('共计{}条语料'.format(counter))

# p=os.listdir(r'D:\python爬虫\spider_audio\train_2')
# p2=os.listdir(r'D:\python爬虫\spider_audio\car_2')
# for i in p2:
#     if i in p:
#         os.remove('D:\\python爬虫\\spider_audio\\car_2\\'+i)