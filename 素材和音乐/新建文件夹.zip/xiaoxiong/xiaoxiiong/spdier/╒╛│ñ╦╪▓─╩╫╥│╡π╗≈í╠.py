from fake_useragent import UserAgent
import requests
from lxml import etree
import time
import os

ua = UserAgent()
headers = {'user-agent': ua.Chrome}
counter = 0
for i in range(2, 9):
    print(f"i={i}")
    print(f"i={i}")
    print(f"i={i}")
    # 随机代理
    # pro_url = 'http://127.0.0.1:5000/random'
    # proxy = requests.get(pro_url).text
    # proxies = {'https': 'http://{}'.format(proxy)}

    url = 'http://sc.chinaz.com/yinxiao/TiYuYunDong_{}.html'.format(i)
    # url = 'http://aspx.sc.chinaz.com/query.aspx?keyword=惨叫'
    page = requests.get(url, headers=headers)
    html = etree.HTML(page.text)

    # mp3_url=html.xpath('//*[@id="musiclist"]/div/p[1]/@thumb')
    # print(mp3_url)
    page_urls = html.xpath('//*[@id="musiclist"]/div/p[1]/a/@href')


    print(page_urls)

    # print(content)
    file = 'shouting'
    if not os.path.exists(file):
        os.mkdir(file)

    for page_url in page_urls:

        page_1 = requests.get(page_url, headers=headers)
        html_1 = etree.HTML(page_1.text)
        mp3_url_1 = html_1.xpath('//*[@id="downmusic"]//@thumb')
        # print(mp3_url_1)
        if len(mp3_url_1) == 1:
            if mp3_url_1[0].endswith('.mp3'):
                counter += 1
                with open(file + '\\' + mp3_url_1[0].split('/')[-1], 'wb') as m:
                    print(mp3_url_1[0].split('/')[-1])
                    m.write(requests.get(mp3_url_1[0], headers=headers).content)
        time.sleep(1)
    # time.sleep(10)

print('共计{}条语料'.format(counter))



