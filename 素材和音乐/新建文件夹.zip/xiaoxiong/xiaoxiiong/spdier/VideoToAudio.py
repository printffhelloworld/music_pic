# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2020/9/18
# Time   : 9:45
# IDE    : PyCharm
import os
from ffmpy3 import FFmpeg

filepath = r"C:\Users\wwx911055\Desktop\test"  # 添加路径
# os.chdir(filepath)
# 得到文件夹下的所有文件名称
filename = os.listdir(filepath)
outputpath = r"C:\Users\wwx911055\Desktop\MP3"  # 添加路径
if not os.path.exists(outputpath):
    os.makedirs(outputpath)
# os.chdir(outputpath)
for i in filename:
    if '.mp4' in i:
        changefile = filepath + "\\" + i
        outputfile = outputpath + "\\" + i.replace('mp4', 'wav')
        ff = FFmpeg(
            inputs={changefile: None},
            outputs={outputfile: '-vn -ar 32000 -ac 1 -ab 192 -f wav'}
            # ↑采样率↑声道数
        )
        # ff.cmd()
        ff.run()
