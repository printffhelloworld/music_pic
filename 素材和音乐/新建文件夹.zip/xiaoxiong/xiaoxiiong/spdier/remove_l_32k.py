# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2020/8/10
# Time   : 20:52
# IDE    : PyCharm

import librosa
import os


def rml32k():
    src_path = r"C:\Users\asus\Desktop\0920\\"
    type_list = os.listdir(src_path)
    for type in type_list:
        print(f"type:{type}")
        count = 0
        file_list = os.listdir(src_path + type)
        for file in file_list:
            file_path = src_path + type + "\\" + file
            try:
                a, b = librosa.load(file_path, sr=None)
                print(f"rate:{b}")
            except Exception as e:
                print("读取音频失败：", e)
                os.remove(file_path)
                print("已删除")
                continue

            if b < 32000:
                count += 1
                print("删除")
                os.remove(file_path)
        print(f"{type}删除{count}条")


if __name__ == '__main__':
    rml32k()
