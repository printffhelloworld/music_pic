
from fake_useragent import UserAgent
import requests
from lxml import etree
import time
import os

ua = UserAgent()
headers = {'user-agent': ua.Chrome}
counter = 0
file = 'car_2'
if not os.path.exists(file):
    os.mkdir(file)

for i in range(1,8):
    url='https://so.16sucai.com/search.aspx?p={}&q=%E8%AD%A6%E8%BD%A6&s=yx'.format(i)
    # url='http://699pic.com/music/soundeffect-9948870.html'
    # pro_url = 'http://127.0.0.1:5000/random'
    # proxy = requests.get(pro_url).text
    # proxies = {'https': 'http://{}'.format(proxy)}

    # page = requests.get(url, headers=headers, proxies=proxies)
    page = requests.get(url, headers=headers)
    html = etree.HTML(page.text)
    son_page_urls=html.xpath('/html/body/div[3]/div/div/div[2]/ul/li/p/a//@href')
    for son_page_url in son_page_urls:
        # son_page=requests.get(son_page_url,headers=headers,proxies=proxies)
        son_page=requests.get(son_page_url,headers=headers)
        html_=etree.HTML(son_page.text)
        mp3_urls = html_.xpath('/html/body/div[3]/div[1]/div/div[3]/div/p/audio/source//@src')
        for mp3_url in mp3_urls:
            counter+=1
            with open(file+'\\'+mp3_url.split('/')[-1],'wb') as m:
                # m.write(requests.get('http:'+mp3_url,headers=headers,proxies=proxies).content)
                m.write(requests.get('http:'+mp3_url,headers=headers).content)
                print('http:'+mp3_url)
            time.sleep(1)
    time.sleep(5)
print('共计{}条语料'.format(counter))