from fake_useragent import UserAgent
import requests
from lxml import etree
import time
import os

ua = UserAgent()
counter = 0
file = 'jingche'
if not os.path.exists(file):
    os.mkdir(file)

headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
           'Cookie':'_uab_collina=159351107235695556743647; FIRSTVISITED=1593511073.501; bt_guid=afd84eac03873c33e64b8955b7c50979; referer=http%3A%2F%2Fibaotu.com%2F%3Fm%3Dstats%26callback%3DjQuery112407152615749354423_1593511239957%26lx%3D3%26pagelx%3D13%26exectime%3D0.0145%26loadtime%3D1.504%26_%3D1593511239961; login_type=QQ; auth_id=33428354%7C%E7%8E%89%E7%AE%AB%E7%84%B6%7C1594807806%7Ca675a93efcc66660fb4b84e05ae98b75; sns=%7B%22type%22%3A%22qq%22%2C%22token%22%3A%7B%22access_token%22%3A%22038D6877AADDE453665E00AC73CE8EDF%22%2C%22expires_in%22%3A%227776000%22%2C%22refresh_token%22%3A%229C24166A364DD3C72E694817E42A723F%22%2C%22openid%22%3A%22EA7ADB6994CD6C6073588397D08ABAA7%22%7D%7D; head_33428354=%2F%2Fqzapp.qlogo.cn%2Fqzapp%2F101334430%2FEA7ADB6994CD6C6073588397D08ABAA7%2F100; ISREQUEST=1; WEBPARAMS=is_pay=0; md_session_id=20200701001896370; user_refers=a%3A2%3A%7Bi%3A0%3Bs%3A3%3A%22bwd%22%3Bi%3A1%3Bs%3A13%3A%22www.sogou.com%22%3B%7D; Hm_lvt_2b0a2664b82723809b19b4de393dde93=1593511073,1593511808,1593606386; md_session_expire=1800; Hm_lvt_4df399c02bb6b34a5681f739d57787ee=1593511074,1593511808,1593606387; _sh_hy=a%3A4%3A%7Bi%3A0%3Ba%3A2%3A%7Bs%3A4%3A%22name%22%3Bs%3A9%3A%22%E5%90%B9%E5%8F%A3%E5%93%A8%22%3Bs%3A5%3A%22count%22%3Bi%3A500%3B%7Di%3A1%3Ba%3A2%3A%7Bs%3A4%3A%22name%22%3Bs%3A9%3A%22%E5%96%8A%E5%8F%AB%E5%A3%B0%22%3Bs%3A5%3A%22count%22%3Bi%3A11%3B%7Di%3A2%3Ba%3A2%3A%7Bs%3A4%3A%22name%22%3Bs%3A12%3A%22%E5%84%BF%E7%AB%A5%E7%AC%91%E5%A3%B0%22%3Bs%3A5%3A%22count%22%3Bi%3A19%3B%7Di%3A3%3Ba%3A2%3A%7Bs%3A4%3A%22name%22%3Bs%3A6%3A%22%E7%AC%91%E5%A3%B0%22%3Bs%3A5%3A%22count%22%3Bi%3A386%3B%7D%7D; Hm_lpvt_2b0a2664b82723809b19b4de393dde93=1593606694; Hm_lpvt_4df399c02bb6b34a5681f739d57787ee=1593606694',
            'Host': 'ibaotu.com',
           'Upgrade-Insecure-Requests': '1',
           'Refer': 'https://ibaotu.com/tupian/majiao.html'}
for i in range(1,2):
    # url='https://ibaotu.com/tupians/paishou/yinxiao/10-0-0-0-0-c0-{}.html'.format(i)
    url = 'https://ibaotu.com/tupian/gongjiaoche/6-0-0-0-0-0-c0_12-1.html?format_type=0'
    # url = 'https://ibaotu.com/tupian/jingche/6-0-0-0-0-0-c0_12-1.html?format_type=0'
    # pro_url = 'http://127.0.0.1:5000/random'
    # proxy = requests.get(pro_url).text
    # proxies = {'https': 'http://{}'.format(proxy)}

    page = requests.get(url, headers=headers)
    print(page.text)
    html = etree.HTML(page.text)

    mp3_urls=html.xpath('/html/body/div[5]/div/div[6]/div[2]/ul/li/a/div[2]/audio//@src')
    for mp3_url in mp3_urls:
        if mp3_url.endswith('.mp3'):
            counter += 1
            if mp3_url.startswith('//'):
                mp3_url = 'https:'+mp3_url
            with open(file+'\\'+mp3_url.split('/')[-1],'wb') as m:
                try:
                    m.write(requests.get(mp3_url).content)
                    print(mp3_url)
                except Exception as e:
                    print(e)

            time.sleep(1)
    time.sleep(5)
print('共计{}条语料'.format(counter))

# p=os.listdir(r'D:\python爬虫\spider_audio\audio_1\car_1')
# p2=os.listdir(r'D:\python爬虫\spider_audio\car_2')
# for i in p2:
#     if i in p:
#         os.remove('D:\\python爬虫\\spider_audio\\car_2\\'+i)