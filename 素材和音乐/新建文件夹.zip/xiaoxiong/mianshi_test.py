# _*_coding:utf-8_*_
# Author ：Little Chen
# Date   ：2021/1/10
# Time   : 18:29
# IDE    : PyCharm
import unittest
from study.mianshiti import answer_1


class TestDict(unittest.TestCase):

    def test_num(self):
        self.assertTrue(answer_1(121, 211))

    def test_str(self):
        self.assertTrue(answer_1("abcd", "dbca"))

    def test_nul(self):
        self.assertTrue(answer_1("", ""))

    def test_err(self):
        self.assertFalse(answer_1("123", "abc"))


if __name__ == '__main__':
    unittest.main()
