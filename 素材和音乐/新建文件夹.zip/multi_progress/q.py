from multiprocessing import Queue
q=Queue(4)#初始化一个Queue对象，最多可接受3条消息,队列,先进先出
q.put("消息1")
q.put("消息2")
q.put("消息3")
print(q.full(),q.get(),q.get())#Queue.get([block[, timeout]])：获取队列中的⼀条消息， 然后将其从队列中移除， block默认值为True(此处block是阻塞的意思，True表示为阻塞状态)
#如果block使⽤默认值，且没有设置timeout（单位秒） ， 消息队列如果为空， 此时程序将被阻塞（停在读取状态），直到从消息列队读到消息为⽌.