from multiprocessing import Process
num=1
def run1():
    global num
    while True:
        num+=5
        print("子进程1运行中,num=%d"%num)
def run2():
    global num
    while True:
        num+=10
        print("子进程2运行中,num=%d"%num)
if __name__ == '__main__':
    print("主进程启动")
    p1=Process(target=run1)
    p2=Process(target=run2)
    print("子进程将要执行")
    p1.start()
    p2.start()
    p1.join()#p.join([timeout]):主进程等待p终止，timeout是可选的超时时间
    p2.join()#p.join([timeout]):主进程等待p终止，timeout是可选的超时时间
    print("子进程结束")