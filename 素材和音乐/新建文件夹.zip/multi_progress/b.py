from multiprocessing import Process, Queue
import os, time, random
class amq(Process):
    q = None
    def __init__(self,q):
        #初始化的时候调用父类初始化函数
        # Process类本身也有__init__方法，如果没有初始化，就不能使用从这个类继承的一些方法和属性，
        # 最好的方法就是将继承类本身传递给Process.__init__方法，完成这些初始化操作
        Process.__init__(self)
        self.q = q

    def run(self):
     print('Process to write: %s' % os.getpid())
     for value in ['A', 'B', 'C']:
         print('Put %s to queue...' % value)
         self.q.put(value)
         time.sleep(random.random())