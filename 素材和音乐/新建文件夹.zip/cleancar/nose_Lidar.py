#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author:王琛
# date:2019/10/10
# mail:17751317450@163.com

class Noselidar():
    # 边沿线方程
    boundLeftA = 0
    boundLeftB = 0
    boundLeftC = 0
    boundRightA = 0
    boundRightB = 0
    boundRightC = 0
    dx_left = 0
    dx_right = 0

    def __init__(self):
        return

    # 自定义初始化
    def init(self,boundLeftA,boundLeftB,boundLeftC,boundRightA,boundRightB,boundRightC,dx_left,dx_right):
        self.boundLeftA = boundLeftA
        self.boundLeftB = boundLeftB
        self.boundLeftC = boundLeftC
        self.boundRightA = boundRightA
        self.boundRightB = boundRightB
        self.boundRightC = boundRightC
        self.dx_left = dx_left
        self.dx_right = dx_right
    # 获取dx
    def get_dx_left(self):
        return self.dx_left

    def get_dx_right(self):
        return self.dx_right
    #获取dw
    def get_dw_left(self):
        pass

    def get_dw_right(self):
        pass

def test():
    noselidar = Noselidar()
    print(noselidar.get_dx_left())
    print(noselidar.get_dx_right())

if __name__ == '__main__':
    test()
