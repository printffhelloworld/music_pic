class NptCmd():
    def get_senBytes(self):
        pass

    def get_cmd(self,cmdIde):
        cmds = {
            "前":0x00,
            "左转":0xf0,
            "左1000":0xf0,
            "右转":0x0f,
            "右1000":0x0f,
            "后":0xff,
            "停":0xff,
            "喷水开":0xff,
            "喷水关":0x00,
            "SET":0xff,
            "吸尘开":0xff,
            "吸尘关":0x00,
            "一档":0x0f,
            "二档":0xf0,
            "三档":0xff,
            "P1":0xff,
            "P2":0xff,
            "P3":0xff,
            "清扫开":0xff,
            "清扫关":0x00,
            "喇叭开":0xff,
            "喇叭关":0x00,
            "水量增":0xf0,
            "水量减":0x0f,
            "零档":0x00,
            "手动":0x00,
            "自动":0xff,
        }
        return cmds.get(cmdIde, None)
    def get_bytesnum(self,numIde):
        nums = {
            "前": 5,
            "左转": 12,
            "左1000": 12,
            "右转": 12,
            "右1000": 12,
            "后": 5,
            "停": 11,
            "喷水开": 8,
            "喷水关": 8,
            "SET": 4,
            "吸尘开": 7,
            "吸尘关": 7,
            "一档": 17,
            "二档": 17,
            "三档": 17,
            "P1": 1,
            "P2": 2,
            "P3": 3,
            "清扫开": 6,
            "清扫关": 6,
            "喇叭开":10,
            "喇叭关":10,
            "水量增": 9,
            "水量减": 9,
            "零档": 17,
            "手动": 18,
            "自动": 18,
        }
        return nums.get(numIde, None)

def test():
    nptCmd=NptCmd()
    send=nptCmd.get_cmd("一档")
    print(send)
    a = []
    a.append(send)
    print(bytes(a))
    b=nptCmd.get_bytesnum("一档")
    print(b)

if __name__ == '__main__':
    test()
