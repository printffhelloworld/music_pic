# -*- coding:utf-8 -*-
# !/res/Pycharm/cleancar/app.py
# author: 王琛
# email:17751317450@163.com
# 清洁车

from cleancar.web import runweb

robot1 = None
web1 = None

# web1 = runweb()

def init():
    global web1
    web1 = runweb()
    web1.start()

def run(a):
    web1.start()

def dispose():
    try:
        print("app disp3ose()")
        robot1.dispose()
        web1.dispose()
    except Exception as ex:
        return
    return True

if __name__=="__main__":
    init()
    dispose()
    exit(0)