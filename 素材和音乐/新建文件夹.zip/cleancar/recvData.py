import struct
from socket import *
from cleancar.blocks import Blocks
# host = '192.168.1.156' #客服端需要绑定服务器ip
host = '127.0.0.1' #客服端需要绑定服务器ip
#port = 13140 #通讯端口，客服端和服务器端需要统一
port = 10010 #通讯端口，客服端和服务器端需要统一
addr = (host, port)
bufsize = 100000 #字节大小

def recvData():
    host = '127.0.0.1'  # 本地
    port = 10010
    addr = (host, port)
    sock = socket(AF_INET, SOCK_STREAM)
    #连接
    sock.connect(addr)
    #接收
    while True:
        print("一组数据：")
        data = sock.recv(bufsize)# 接受来自服务器端的数据
        print(data)
        recvLength=len(data)
        print("recvLength=",recvLength)
        count = 0
        #print(struct.unpack("!Q",data[3:11])[0])
        #print(struct.unpack("!f",data[36:40])[0])
        for index in range(15,recvLength-36,49):
            print("index=",index)
            count += 1
            print("第",count,"个障碍物。")
            print("障碍物数量=",data[14])
            id=struct.unpack("!I",data[index+3:index-1:-1])[0]
            print("障碍物ID=",id)
            index += 4
            type=data[index]
            print("障碍物类型=",type)
            index += 1
            x=struct.unpack("!d",data[index+7:index-1:-1])[0]
            print("障碍物经度x=",)
            index += 8
            y=struct.unpack("!d",data[index+7:index-1:-1])[0]
            print("障碍物纬度y=",y)
            index += 8
            a=struct.unpack("!f",data[index+3:index-1:-1])[0]
            print("障碍物长度a=",a)
            index += 4
            b=struct.unpack("!f",data[index+3:index-1:-1])[0]
            print("障碍物宽度b=",b)
            index += 4
            c=struct.unpack("!f",data[index+3:index-1:-1])[0]
            print("障碍物高度c=",c)
            index += 4
            v=struct.unpack("!f",data[index+3:index-1:-1])[0]
            print("障碍物速度v=",v)
            index += 4
            hxj=struct.unpack("!f",data[index+3:index-1:-1])[0]
            print("障碍物航向角=",hxj)
            index += 4
            l=struct.unpack("!f",data[index+3:index-1:-1])[0]
            print("相对距离=",l)
            index += 4
            xdjd=struct.unpack("!f",data[index+3:index-1:-1])[0]
            print("相对角度=",xdjd)
            index += 4
            block=[id,type,x,y,a,b,c,v,hxj,l,xdjd]

        print("boundLeftA=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        index += 4
        print("boundLeftB=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        index += 4
        print("boundLeftC=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        index += 4
        print("boundRightA=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        index += 4
        print("boundRightB=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        index += 4
        print("boundRightC=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        index += 4
        print("leftLine=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        index += 4
        print("rightLine=",struct.unpack("!f",data[index+3:index-1:-1])[0])
        print("下一组=============================================================")
        print(struct.unpack("!f",data[39:35:-1])[0])
        #float([data[3],data[2],data[1],data[0]])
def test():
    recvData()
    blocks = Blocks()

if __name__ == '__main__':
    test()
