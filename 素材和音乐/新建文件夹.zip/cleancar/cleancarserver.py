# -*- coding: UTF-8 -*-
from socketserver import BaseRequestHandler, TCPServer
from socket import socket,AF_INET,SOCK_STREAM

class EchoHandler(BaseRequestHandler):
    def handle(self):
        print('Got connection from', self.client_address)
        msg = self.request.recv(1024)
        if not msg:
            pass
        else:
            ret_msg = msg
            self.request.send(ret_msg)
            print("收到指令",msg)
            # print("收到指令",msg.decode())
def start():
    from threading import Thread
    NWORKERS = 16
    serv = TCPServer(('', 5000), EchoHandler)
    for n in range(NWORKERS):
        t = Thread(target=serv.serve_forever)
        t.daemon = True
        t.start()
    serv.serve_forever()
if __name__ == '__main__':
    start()