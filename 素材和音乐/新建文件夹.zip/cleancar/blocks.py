#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author:王琛
# date:2019/10/10
# mail:17751317450@163.com

class Blocks():
    quantity = 0  # 障碍物数量
    block_msg = []  # [id,类型type,经度x,纬度y,长a,宽b,高c,速度v,航向角,相对距离,相对角度]
                    # [ 0,      1,    2,  3  ,  4,  5, 6,    7,     8,      9,      10]
    blocks_list = []  # [[1,1,1,1,1,1,1,1,1,10,1],[2,2,2,2,2,2,2,2,2,10,2],[3,3,3,3,3,3,3,3,3,10,3]]
    min_distance = 0  # 最近的障碍物距离

    def __init__(self):
        return

    # 获取障碍物数量
    def get_quantity(self):
        return self.quantity

    # 获取障碍物数量
    def get_blocks_list(self):
        return self.blocks_list

    # 自定义初始化
    def init(self):
        pass

    # 获取最近的障碍物距离
    #  block_msg = [] # [id,类型type,经度x,纬度y,长a,宽b,高c,速度v,航向角,相对距离,相对角度]
                      # [ 0,      1,    2,  3  ,  4,  5, 6,    7,     8,      9,      10]
    def get_min_distance(self):
        self.min_distance = 70
        for block in self.blocks_list:
            if 0 <= block[10] <= 90 or 270 <= block[10] <= 360:  # 只计算前半平面的障碍物
                # 实际距离=中心距离-两个物体的半径
                distance = block[10] - (pow(pow(0.5 * block[4], 2) + pow(0.5 * block[5], 2), 0.5) + 0.7)
                if self.min_distance >= distance:
                    self.min_distance = distance
                print("与障碍物实际距离=", distance, ";最近的障碍物距离=", self.min_distance)
        return self.min_distance


def test():
    blocks = Blocks()
    blocks.quantity = 3
    blocks.block_msg = [1, 1, 1, 1, 1, 1, 1, 1, 45, 10, 45]
    blocks.blocks_list.append(blocks.block_msg)
    blocks.block_msg = [2, 2, 2, 2, 6, 8, 2, 2, 45, 10, 45]
    blocks.blocks_list.append(blocks.block_msg)
    blocks.block_msg = [3, 3, 3, 3, 3, 3, 3, 3, 45, 10, 45]
    blocks.blocks_list.append(blocks.block_msg)
    for a in blocks.blocks_list:
        print(a)
    blocks.get_min_distance()


if __name__ == '__main__':
    test()
