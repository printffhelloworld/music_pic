import time

from flask import Flask, render_template, jsonify
from flask import request
from socket import socket,AF_INET,SOCK_STREAM
from cleancar.npt_cmd import NptCmd
web_tcp = Flask(__name__)
# 服务端的ip地址
# server_ip = '127.0.0.1'
# '192.168.1.11'#我再局域网中的ip
server_ip = '192.168.1.2'#这个ip是plc的ip
# 服务端socket绑定的端口号
server_port = 5000

def tcpConnect(client,server_ip,server_port):#自己封装的防止连接出错
    try:
        client.connect((server_ip, server_port))#连接
        print("连接成功")
    except Exception as ex:
        print("连接失败:再次连接:",ex)
        tcpConnect(client, server_ip, server_port)

client = socket(AF_INET, SOCK_STREAM)  # ipv4,TCP
tcpConnect(client, server_ip, server_port)
#实例化
npt_cmd=NptCmd()
a=[0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00]
@web_tcp.route('/')
def debug():
    return render_template("clean_open_close.html")

def init_tcp():
    return

#运行指令
def run_cmd(cmd):
    global npt_cmd, a
    if cmd=="急停":
        a=[0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,#1-8
           0x00,0x00,0xff,0x00,0x00,0x00,0x00,0x00,#9-16
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,#17-24
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00]#25-32
        # client.close()
    else:
        #非急停
        a[10]=0x00
        bytesnum=npt_cmd.get_bytesnum(cmd)
        cmd_mark=npt_cmd.get_cmd(cmd)
        a[bytesnum-1]=cmd_mark
    if cmd=="左转" or cmd == "右转":
        #15000=0x3A98
        #5000=0x1388
        #1000=0x03E8
        #2000=0x07D0
        #10000=0x2710
        a[14]=0x27
        a[15]=0x10
    elif cmd == "左1000" or cmd == "右1000":
        a[14]=0x03
        a[15]=0xE8
    else:
        a[14] = 0x00
        a[15] = 0x00
    print(cmd)
    sendStr=bytes(a)
    print("sendStr=",sendStr)
    client.send(sendStr)
    return_date = str(client.recv(32))
    # client.close()
    print("收到反馈数据=", return_date)
    return True

@web_tcp.route('/post_cmd', methods=['POST'])
def post_cmd():
    post_data = request.get_json(silent=True)
    print(post_data)
    cmd = post_data['cmd']
    print(cmd)
    #自动跑
    if cmd == "自动运行":
        run_cmd("一档")
        for i in range(0,3):
            time.sleep(3)
            run_cmd("右转")
            time.sleep(3)
            run_cmd("左转")
        time.sleep(2)
        run_cmd("零档")
    # sendStr = str(cmd).encode("utf-8")
    # print(sendStr)
    #非自动跑
    else:
        run_cmd(cmd)
    data_wrapper = {'result_code': 0}
    return jsonify(data_wrapper)

class runweb():
    def start(self):
        # web_tcp.run(host='127.0.0.1' ,port=5000)
        # web_tcp.run(host='192.168.1.11' ,port=5000)#这个ip是开发板的ip
        web_tcp.run(host='192.168.1.102' ,port=5000)#这个ip是开发板的ip

if __name__ == '__main__':
    init_tcp()
    run = runweb()
    run.start()