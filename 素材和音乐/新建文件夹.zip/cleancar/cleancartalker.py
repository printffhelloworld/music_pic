# -*- coding: UTF-8 -*-
import time
from socket import socket,AF_INET,SOCK_STREAM
server_ip = '192.168.1.2'#PLC的地址
# server_ip = '192.168.1.11'#我的
#服务端socket绑定的端口号
server_port = 5000

def tcpConnect(client,server_ip,server_port):#自己封装的防止连接出错
    try:
        client.connect((server_ip, server_port))#连接
        print("连接成功")
    except Exception as ex:
        print("连接失败:再次连接:",ex)
        tcpConnect(client, server_ip, server_port)

if __name__ == '__main__':
    client = socket(AF_INET, SOCK_STREAM)  # ipv4,TCP
    tcpConnect(client, server_ip, server_port)
    str_msg = b'\x00\x00'
    # str_msg = b'\x00'
    print("开始发送")
    # client.send(b'\x00\x00\xff')#0000ff
    print("手自动:自动.已发送")
    while True:
        # str_msg = input("请输入要发送信息：")
        if str_msg != "":
            client.send(b'\x00\x00')
            # client.send(b'\x00')
            print("开")
            print("收到返回的消息:", str(client.recv(33)))
            time.sleep(5)
            break
            client.send(b'\x00')
            print("关")
            print("收到返回的消息:", str(client.recv(33)))
            time.sleep(5)
            # client.close()
