import cv2
import numpy as np
cap=cv2.VideoCapture(0)
#url = 'rtsp://admin:password@192.168.99.25:554/11'
#cap = cv2.VideoCapture(url)


sz = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
fps = 5

# fourcc = cv2.VideoWriter_fourcc('m','p','4','v')
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
# fourcc = cv2.VideoWriter_fourcc('m','p','e','g')
# fourcc = cv2.VideoWriter_fourcc(*'mpeg')

##open and set props
vout = cv2.VideoWriter()
vout.open('output.mp4',fourcc,fps,sz,True)

while(1):    # get a frame  
    ret, frame = cap.read()    # show a frame  
    cv2.imshow("capture", frame) 
    vout.write(frame) 
    if cv2.waitKey(1) & 0xFF == ord('q'):       
        break

cap.release()
cv2.destroyAllWindows()


