#! /moobot/res/slenderagv/robot.py
# 主要是机器人的主运行逻辑.
# 核心架构为异步多线程
# python 并不能很好的利用多核的优势, 所以多线程对于pytho来说是伪命题.
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)
import threading
import _thread
import logging
import time
import queue
import json
from slenderagv.robot_inside2 import RobotInside
from net_tcp_listener import TcpCommander
from iot_modbus_rtu_xyd1210 import ModbusRtuXyd1210
import re
from wcs_backroute import BackRoute
from socket import socket, AF_INET, SOCK_STREAM
from waist3 import Waist3
from backbone import backbone
from iot_motor import PwmMotor
from iot_magnet_ms16a import Magnet
from feet import Feet
from net_amq_send import Sendtopic
# 超声
from iot_radar_485 import Radar


class Robot(threading.Thread):
    # 超声避障
    radar = None
    radar_client = None

    # 是否开启避障(只在2指令高速行驶时候才打开)
    ear_enable = False
    # 超声避障读数，创建空元祖，读取时候接收新数据,每次接收后处理时先清空然后再赋值
    ear_this_radar_id = []
    # 超声避障最近10次读数记录,内部存储10次ear_this_radar_id,用于在避障停车时防止数据波动导致避障时走时停,车子快速反复地行驶和停车
    ear_history_radar_id = []
    # 是否避障停车
    ear_stop = False
    ear_slow_down = False
    ear_slow_down_limit_speed = 0.1

    # 巡磁
    magnet1 = None
    magnet2 = None

    waist1 = None
    back1 = None
    feet = None
    xd1210_1 = None
    xd1210_2 = None

    NOSE_BIT_WIDTH = 0.01
    backroute = None
    # 服务端的ip地址
    # server_ip = '192.168.100.111'
    server_ip = '192.168.43.15'
    # 服务端socket绑定的端口号
    server_port = 20000
    tcpcommander = None

    modbus_client1 = None

    # 给inside服务
    channel_data = [{"id": "", "name": "ch", "dr": 0, "dw": 0}]

    # 给team服务
    task_queue = queue.Queue(maxsize=10)
    cmd_str = ""
    command_list = []
    nose1_count = 0
    nose2_count = 0
    nose3_count = 0
    # 当前任务
    current_task = ""
    # 任务列表
    cmd_list = []
    list_id = 1
    dict_msg = {}
    # 当前任务指令字符串
    current_cmdStr = ""
    # 当前任务指令列表
    current_cmdStr_list = []
    # 当前指令
    current_cmd = ""
    # 当前指令下一个指令
    next_cmd = ""
    last_cmd = ""
    # 指令长度
    cmdNum = 0
    single_cmd_info = {}
    cmd_list_info = []

    # 当前指令
    cmd_this = ""
    cmd_this_start_time = None
    cmd_this_end_time = None
    idle_start_time = None
    idle_end_time = None
    full_magnet_time = None

    # 主状态
    main_state = 0
    MAIN_STATE_INIT = 100
    MAIN_STATE_IDLE = 200
    MAIN_STATE_BUSY = 300
    MAIN_STATE_BUSY_RUNNING = 310
    MAIN_STATE_BUSY_FINISH = 320
    MAIN_STATE_BUSY_BLOCKED = 330
    MAIN_STATE_WAIT = 400
    MAIN_STATE_ERROR = 500
    MAIN_STATE_ERR_DONE = 510
    MAIN_STATE_ERR_UNDONE = 520
    MAIN_STATE_ERR_UNKNOW = 530

    sp_dict = {}
    sp_list = []
    xunci = None

    task_json = None

    # 发送回复
    sendinfo = None
    sendJson = {
        # "Channel": "ResultTask",
        # "Client": "AGV",
        # "TaskSN": "",
        # "TaskCode": "",
        # "AGVCode": "Dev-AGV03",
        # "From": "",
        # "To": "",
        # "Status":""
    }

    new_dict = {}
    new_list = []

    dx_t_list_all = [[0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0]]
    dx_t_i = 0

    # Part 1 构造函数
    def __init__(self):
        super(Robot, self).__init__()
        return

    def init(self):
        try:
            self.sendinfo = Sendtopic()
            self.sendinfo.init()

            self.backroute = BackRoute()
            self.tcpcommander = TcpCommander()

            self.feet = Feet()
            self.feet.init()
            self.feet.config("/dev/ttyUSB2", 0x26, 38400)
            self.feet.connect()

            # 超声避障
            self.radar = Radar()
            self.radar.config("/dev/ttyUSB3", 9, 115200)
            self.radar.connect()

            self.waist1 = Waist3()
            self.waist1.init()
            self.waist1.rtu.connect()
            # self.waist1.rtu.client = self.feet.client
            #
            self.back1 = backbone()
            self.back1.init()
            # self.back1.rtu.client=self.feet.client
            self.back1.rtu.client = self.waist1.rtu.client

            self.magnet1 = Magnet()
            self.magnet1.client = self.feet.client

            self.magnet2 = Magnet()
            self.magnet2.client = self.feet.client

            self.xd1210_1 = ModbusRtuXyd1210()
            self.xd1210_1.client = self.waist1.rtu.client
            self.xd1210_1.slave_num = 21
            self.xd1210_1.BAUD_RATE = 9600

            self.xd1210_2 = ModbusRtuXyd1210()
            self.xd1210_2.client = self.waist1.rtu.client
            self.xd1210_2.slave_num = 22
            self.xd1210_2.BAUD_RATE = 9600
        except:
            print("有异常")

        # 启动TCPIP
        # self.task_queue = self.tcpcommander.q
        # _thread.start_new_thread(self.tcpcommander.connect,("启动TCPIP通讯",))
        # time.sleep(1)
        # _thread.start_new_thread(self.addtq,("将来自tcp的任务进行添加",))
        # time.sleep(1)
        # 启动心跳
        _thread.start_new_thread(self.sendinfo.sendstate, ())
        return

    def addtq(self, a):
        while True:
            if (self.tcpcommander.q.qsize() == 0):
                continue
            else:
                transit_q = self.tcpcommander.q.get()
                self.task_queue.put(transit_q, block=True, timeout=None)

    # Part 3 进程主函数, 每个机器人都以此作为最核心的代码.
    def run(self):
        print('进入robot_main.run()')
        self.main_state = self.MAIN_STATE_INIT
        self.init()
        self.main_state = self.MAIN_STATE_IDLE
        print("IDLE")
        while True:
            # try:
            if (self.task_queue.qsize() == 0):
                self.xd1210_1.write_Y4(0)
                print("目前队列为空")
                time.sleep(0.5)
                continue
            else:
                # print(self.task_queue.qsize())
                self.main_state = self.MAIN_STATE_BUSY
                print("BUSY")
                byte_q = self.task_queue.get()
                print(type(byte_q))
                if (type(byte_q) == dict):
                    print("我是来自服务器的信息")
                    self.task_json = byte_q
                    strfrom = self.task_json["From"]
                    strto = self.task_json["To"]
                    strfromto = strfrom + "-" + strto
                    print("对json的解析获取任务地点:", strfromto)
                    self.current_cmdStr = self.search(strfromto)
                    # a = "11041-11081"
                    if (self.current_cmdStr == ""):
                        a = strfromto
                        a1 = a[0:5]
                        a2 = a[6:]
                        sour = a1
                        targ = a2
                        if (a2 <= "11061"):
                            self.current_cmdStr = self.search1(a1, a2)
                        else:
                            self.current_cmdStr = self.search2(a1, a2)
                        print("##################>>>>")
                        print(self.current_cmdStr)
                        print("##################>>>>")
                elif (type(byte_q) == str):
                    print("我是来自web的信息")
                    byte_q1 = str(byte_q).encode("utf-8")
                    self.current_task = byte_q1.decode("utf-8")
                    print("RUN", self.current_task)
                    print("-------------------------------------")
                    print("当前任务：", self.current_task)
                    ok = self.handle_task_cmd()
                    if (not ok):
                        continue
                elif (type(byte_q) == bytes):
                    print("我是来自web的信息")
                    self.current_task = byte_q.decode("utf-8")
                    print("RUN", self.current_task)
                    print("-------------------------------------")
                    print("当前任务：", self.current_task)
                    ok = self.handle_task_cmd()
                    if (not ok):
                        continue
                else:
                    print("Unknown type")
                print("开始执行")
                ok = self.run_commandStr()
                if (not ok):
                    continue
                time.sleep(0.5)  # 任务执行完毕后, 休息0.5秒, 防止前后冲突
                self.main_state = self.MAIN_STATE_IDLE
                print("IDLE")
                print("开始下一次循环")
            # except Exception as ex:
            #     self.main_state=self.MAIN_STATE_ERROR
            #     self.error=ex
            #     print("ERROR", ex)
            #     recovered= self.deal_error()
            #     if(recovered==True):
            #         print("Error Recovered")
            #         time.sleep(0.5)
            #         print("IDLE")
            #         self.main_state = self.MAIN_STATE_IDLE
            #         continue
            #     else:
            #         print("Error Unrecovered")
            #         time.sleep(0.5)
            #         self.main_state = self.MAIN_STATE_ERR_UNDONE
            #         print("")
            #         exit(1)
        return

    def search(self, routeid):
        res = open("data/ShoeRoute3.json", encoding='utf-8').read()
        shoeroute = json.loads(res)
        dict = shoeroute["routes"]
        cmd = ""
        print("routeid", routeid)
        for i in dict:
            if (i["routeId"] == routeid):
                cmd = i["cmd"]
        return cmd

    def search1(self, source, target):
        res = open("data/ShoeRoute.json", encoding='utf-8').read()
        shoeroute = json.loads(res)
        dict = shoeroute["routes"]
        cmd = ""
        strnum1 = ""
        strnum2 = ""
        intnum1 = None
        intnum2 = None
        print(source, target)
        for i in dict:
            if (i["source"] == source and i["num1"] != "0"):
                strnum1 = i["num1"]
                intnum1 = int(strnum1)

        for i in dict:
            if (i["target"] == target and i["num1"] != "0"):
                strnum2 = i["num1"]
                intnum2 = int(strnum2)

        print(strnum1, strnum2, intnum1, intnum2)
        while intnum1 <= intnum2:
            for i in dict:
                if (i["num1"] == strnum1):
                    # if (intnum1 < intnum2):
                    #                     cmd = cmd + i["cmd"].replace("250", "220")
                    #                     print(cmd)
                    #                 else:
                    cmd = cmd + i["cmd"]
                    print(cmd)

            intnum1 = intnum1 + 1
            strnum1 = str(intnum1)
        return cmd

    def search2(self, source, target):
        res = open("data/ShoeRoute.json", encoding='utf-8').read()
        shoeroute = json.loads(res)
        dict = shoeroute["routes"]
        cmd = ""
        strnum1 = ""
        strnum2 = ""
        intnum1 = None
        intnum2 = None
        print(source, target)
        for i in dict:
            if (i["source"] == source and i["num2"] != "0"):
                strnum1 = i["num2"]
                intnum1 = int(strnum1)

        for i in dict:
            if (i["target"] == target and i["num2"] != "0"):
                strnum2 = i["num2"]
                intnum2 = int(strnum2)

        print(strnum1, strnum2, intnum1, intnum2)
        while intnum1 <= intnum2:
            for i in dict:
                if (i["num2"] == strnum1):
                    # if(intnum1 < intnum2):
                    #                     cmd = cmd + i["cmd"].replace("250","220")
                    #                     print(cmd)
                    #                 else:
                    cmd = cmd + i["cmd"]
                    print(cmd)

            intnum1 = intnum1 + 1
            strnum1 = str(intnum1)
        return cmd

    def search_warejson(self, cmdStr):
        res = open("data/WarehouseRoutes.json", encoding='utf-8').read()
        wareRoute = json.loads(res)
        dict = wareRoute["routes"]
        cmd = ""
        print("cmdStr", cmdStr)
        for i in dict:
            if (i["routeId"] == cmdStr):
                cmd = i["cmd"]
        return cmd

    def search_movejson(self, cmdStr):
        res = open("MoveHouseRoutes.json", encoding='utf-8').read()
        wareRoute = json.loads(res)
        dict = wareRoute[cmdStr]
        return dict

    # 出错处理, 返回是否
    # 如果出错处理成功, 机器可以继续运行, 则返回是
    # 否则False, 然后机器要重启启动加载.
    def deal_error(self):

        return False

    # 对任务进行判断解析，转换成2468这样的cmd
    def handle_task_cmd(self):
        print("开始对队列中消息进行判断")
        if (self.current_task.__eq__("get_state")):
            print("收到请求状态指令")

        # elif(bool(re.match("\d{0,}$",self.current_task))):
        elif (not self.current_task.__contains__("#")):
            self.current_cmdStr = self.current_task
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("0-") and not self.current_task.__contains__("-0")):
            cstr1 = self.current_task[2:]
            s1 = self.search_warejson(cstr1)
            self.current_cmdStr = "7" + s1 + "9" + self.backroute.backroute2(s1) + "0"
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("-0") and not self.current_task.__contains__("0-")):
            cstr2 = self.current_task[0:4]
            s2 = self.search_warejson(cstr2)
            self.current_cmdStr = "9" + s2 + "7" + self.backroute.backroute2(s2) + "0"
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("-") and not self.current_task.__contains__(
                "-0") and not self.current_task.__contains__("0-")):
            s3 = self.current_task[0:4]
            current_cmdStr1 = self.search_warejson(s3)
            print(type(s3))
            s4 = self.current_task[5:]
            current_cmdStr2 = self.search_warejson(s4)
            s5 = self.search_movejson(self.current_task)
            s6 = s5[0:s5.__len__() - 1]
            self.current_cmdStr = "9" + current_cmdStr1 + "7" + s6 + "9" + self.backroute.backroute2(
                current_cmdStr2) + "0"
            print("获取cmd", self.current_cmdStr)

        else:
            print("格式异常")
            return False
        print("判断结束")
        return True

    def run_commandStr(self):
        # try:
        #     self.sendinfo = Sendtopic()
        # except Exception as ex:
        #     print(ex)
        if (self.current_cmdStr == ""):
            print("未找到相关指令")
            return False
        print("信息判断结束")
        self.cmdNum = self.current_cmdStr.__len__()
        print("指令长度：", self.cmdNum)  # cmdstr->cmdlist
        self.dict_msg["id"] = self.list_id
        self.dict_msg["cmd"] = self.current_cmdStr
        try:
            self.sendJson["Channel"] = "ResultTask"
            self.sendJson["Client"] = "AGV"
            self.sendJson["TaskSN"] = self.task_json["TaskSN"]
            self.sendJson["TaskCode"] = self.task_json["TaskCode"]
            self.sendJson["AGVCode"] = self.task_json["AGVCode"]
            self.sendJson["From"] = self.task_json["From"]
            self.sendJson["To"] = self.task_json["To"]
            self.sendJson["Status"] = "4"
            self.sendinfo.sendto(self.sendJson)
            self.sendJson = {}
        except Exception as  ex:
            print(ex)

        # 将获取到的2468指令字符串改为列表，便于查询下一个指令
        self.current_cmdStr_list = list(self.current_cmdStr)
        self.xd1210_1.write_Y4(1)
        for i in range(0, self.current_cmdStr_list.__len__()):
            # self.safe_go(singlecmd,self.dict_msg)
            self.current_cmd = self.current_cmdStr_list[i]
            if (i < self.current_cmdStr_list.__len__() - 1):
                self.next_cmd = self.current_cmdStr_list[i + 1]
            else:
                self.next_cmd = ""
            if (i > 0):
                self.last_cmd = self.current_cmdStr_list[i - 1]
            else:
                self.last_cmd = ""
            self.single_cmd_info["start"] = self.cmd_this_start_time
            self.single_cmd_info["end"] = self.cmd_this_end_time
            self.single_cmd_info["full_magnet"] = self.full_magnet_time
            self.safe_go(self.current_cmd)
            print(i, ":", self.current_cmdStr_list[i], ",", self.next_cmd, ":", self.current_cmd)
        self.cmd_list_info.append(self.single_cmd_info)
        self.current_cmd = ""
        self.last_cmd = ""
        self.next_cmd = ""
        self.xd1210_1.write_Y4(0)
        # 命令执行结束后，等待3秒，让车停稳后向上位机传到任务完成的信息
        time.sleep(3)
        try:
            self.sendJson["Channel"] = "ResultTask"
            self.sendJson["Client"] = "AGV"
            self.sendJson["TaskSN"] = self.task_json["TaskSN"]
            self.sendJson["TaskCode"] = self.task_json["TaskCode"]
            self.sendJson["AGVCode"] = self.task_json["AGVCode"]
            self.sendJson["From"] = self.task_json["From"]
            self.sendJson["To"] = self.task_json["To"]
            self.sendJson["Status"] = "9"
            self.sendinfo.sendto(self.sendJson)
            # del self.sendinfo
            self.sendJson = {}
        except Exception as ex:
            print(ex)

        self.cmd_list.append(self.dict_msg)
        print(self.cmd_list)
        self.dict_msg = {}
        self.current_cmd = ""
        self.next_cmd = ""
        self.last_cmd = ""
        self.current_cmdStr_list = []
        self.list_id = self.list_id + 1
        return True

    # 4.2 执行一个命令
    def wait_until_cmd_finish(self):
        while self.robot_inside.current_cmd_state != 'finished':
            time.sleep(0.1)

    # 4.2 执行指令
    def run_cmd(self, cmd):
        print("run_cmd:", cmd)
        if (cmd == None):
            return True
        elif (cmd == ""):
            return True
        else:
            if (self.mode == 15):
                return self.safe_go(cmd)
            else:
                print("Unknown Mode")
                return self.safe_go(cmd)

    # Part 5: 主要运动指令
    # 最常用的是safe_go()  # 24687950  不许调用iot的part，只能修改value_to_write，不允许直接调用iot part
    def reset_car(self):
        print("重置车子状态")
        self.ear_history_radar_id = []
        self.ear_enable = False
        self.ear_stop = False
        self.ear_slow_down = False
        # self.is_charging = False
        return

    # 安全执行
    def safe_go(self, cmd):
        print("safe_go:", cmd)
        # if (cmd == None or cmd ==""):
        #     logging.error("Blank command")
        #     return True
        # else:
        #     #cmd = cmd.trim(" ")

        # 保险起见,每次指令指令前先把避障关掉,执行2,8指令时候开启,2,8指令执行完关闭
        self.ear_enable = False

        if (cmd == ""):
            return True
        elif (cmd == "1"):
            print("开始指令1")
            self.cmd_this_start_time = time.time()
            self.safe_go_1()
            print("指令1执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "3"):
            print("开始指令3")
            self.cmd_this_start_time = time.time()
            self.safe_go_3()
            print("指令3执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "2"):
            print("开始执行2指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_2()
            print("指令2结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "4"):
            print("开始执行指令4")
            self.cmd_this_start_time = time.time()
            self.safe_go_4()
            print("指令4执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "6"):
            print("开始执行6指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_6()
            print("指令6执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "8"):
            print("开始执行8指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_8()
            print("指令8执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "5"):
            print("开始执行5指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_5()
            print("指令5执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "0"):
            print("开始执行0指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_0()
            print("指令0执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "7"):
            print("开始执行7指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_7()
            print("指令7执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "9"):
            print("开始执行9指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_9()
            print("指令9执行结束")
            self.cmd_this_end_time = time.time()
            return True
        elif (cmd == "h"):
            print("开始执行h指令")
            self.cmd_this_start_time = time.time()
            self.safe_go_h()
            print("指令h执行结束")
            self.cmd_this_end_time = time.time()
            return True
        else:
            logging.error("未知指令")
            return False
        return True

    NORMAL_SPEED = 0.05

    # 指令集
    # 5.2
    # 转腰
    def safe_go_1(self):
        self.waist1.go_last()
        return True

    def safe_go_3(self):
        self.waist1.go_next()
        return True

    # 顶升
    def safe_go_7(self):
        self.back1.up()
        return True

    def safe_go_9(self):
        self.back1.down()
        return True

    def safe_go_4(self):
        self.xd1210_1.write_Y7(1)  # 关闭反光板
        # step 1 先开始转动
        print("准备左转")
        self.feet.set_speed_mps(-0.06, 0.06)
        time.sleep(1)
        # # Step 2A 脱磁, 停车
        print("循环判断巡磁")
        while True:
            if (self.next_cmd == "2"):
                (nose_index, nose1_count) = self.nose2_read()
            else:
                (nose_index, nose1_count) = self.nose1_read()
            print("巡磁点亮个数:", nose1_count)
            if (nose1_count == 0):
                break
        # Step 3: 继续开车
        print("已经脱离巡磁")
        while True:
            if (self.next_cmd == "2"):
                (nose_index, nose1_count) = self.nose2_read()
            else:
                (nose_index, nose1_count) = self.nose1_read()
            print("巡磁值:", nose_index)
            if (nose_index > 6 and nose_index < 10):
                print("已经进入巡磁正中")
                break
        # Step 4 停车
        if (self.next_cmd == "4"):
            pass
        else:
            print("stooooop")
            self.feet.stop()
        return True

    def safe_go_6(self):
        self.xd1210_1.write_Y7(1)  # 关闭反光板
        # step 1 先开始转动
        self.feet.set_speed_mps(0.06, -0.06)
        time.sleep(1)
        # # Step 2A 脱磁, 停车
        while True:
            if (self.next_cmd == "2"):
                (nose_index, nose1_count) = self.nose2_read()
            else:
                (nose_index, nose1_count) = self.nose1_read()
            print("巡磁点亮个数:", nose1_count)
            if (nose1_count == 0):
                break
        # Step 3: 继续开车
        print("已经脱离巡磁")
        while True:
            if (self.next_cmd == "2"):
                (nose_index, nose1_count) = self.nose2_read()
            else:
                (nose_index, nose1_count) = self.nose1_read()
            print("巡磁值:", nose_index)
            if (nose_index > 6 and nose_index < 10):
                print("已经进入巡磁正中")
                break
        # Step 4 停车
        if (self.next_cmd == "6"):
            pass
        else:
            print("stooooop")
            self.feet.stop()
        return True

    def safe_go_2(self):
        v2 = 0.25
        self.xd1210_1.write_Y7(1)  # 关闭反光板

        # 开启避障功能
        self.ear_enable = True

        # # step 1 判断脱磁条
        (nose2_index, nose2_count) = self.nose2_read()
        print("巡磁点亮个数:", nose2_count)
        if (nose2_count == 0):
            return False

        # 读取超声避障数据并处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)

        # # step 1 忽略里程
        if (self.last_cmd == "2"):
            for i in range(1, 6):
                self.follow_2(v2)
                time.sleep(0.05)
        else:
            for i in range(1, 6):
                self.follow_2(v2 / 5 * i)
                time.sleep(0.05)

        while True:
            self.follow_2(v2)
            if (self.nose2_count > 6):
                print("满磁停车***********************************")
                break
            if (self.nose2_count == 0):
                # 脱磁
                self.feet.stop()
                return

        if (self.next_cmd == "2" or self.next_cmd == "5"):
            print("判断下一个指令不停车***********************************")
            pass
        else:
            # 软减速
            n = 3
            for i in range(n, 1, -1):
                self.follow_2(v2 / n * i)
            self.feet.stop()
        return

    def safe_go_0(self):
        self.feet.stop()
        return True

    def safe_go_5(self):
        if (self.last_cmd == "5"):
            self.xd1210_1.write_Y7(0)
        else:
            self.xd1210_1.write_Y7(1)

        # # step 1 判断脱磁条
        (nose_index, nose2_count) = self.nose2_read()
        print("巡磁点亮个数:", nose2_count)
        if (nose2_count == 0):
            self.magnet_warn()
            return False
        # # step 1 忽略里程

        start_time = time.time()
        while True:
            self.follow_5(0.03)
            end_time = time.time()
            if (end_time - start_time > 5):
                break

        while True:
            self.follow_5(0.05)
            if (self.nose2_count > 6):
                self.full_magnet_time = time.time()

                break
            if (self.nose2_count == 0):
                # 脱磁
                self.feet.stop()
                self.xd1210_1.write_Y7(1)
                self.magnet_warn()
                return

        # if(mouth_new_rfid_count>=1):
        #     break
        # print(self.new_list)
        self.new_list = []
        self.new_dict = {}

        if (self.next_cmd == "5" or self.next_cmd == "2"):
            pass
        else:
            self.feet.stop()
            self.xd1210_1.write_Y7(1)
        return

    def safe_go_h(self):
        print("开始执行safe_go_h,请注意**********************************************")
        if (self.last_cmd == "h"):
            self.xd1210_1.write_Y7(0)
        else:
            self.xd1210_1.write_Y7(1)

        # # step 1 判断脱磁条
        (nose_index, nose1_count) = self.nose1_read()
        print("巡磁点亮个数:", nose1_count)
        if (nose1_count == 0):
            self.magnet_warn()

            return False
        # # step 1 忽略里程

        start_time = time.time()
        while True:
            self.follow_h(-0.03)
            end_time = time.time()
            if (end_time - start_time > 6):
                break

        while True:
            self.follow_h(-0.06)
            if (self.nose1_count > 6):
                self.full_magnet_time = time.time()
                break
            if (self.nose1_count == 0):
                # 脱磁
                self.feet.stop()
                self.xd1210_1.write_Y7(1)
                self.magnet_warn()

                return

        self.new_list = []
        self.new_dict = {}

        if (self.next_cmd == "h" or self.next_cmd == "8"):
            pass
        else:
            self.feet.stop()
            self.xd1210_1.write_Y7(1)
        return

    def safe_go_8(self):
        v8 = -0.25
        # # step 1 判断脱磁条
        print("进入8指令时间")

        (nose_index, nose1_count) = self.nose1_read()
        print("巡磁点亮个数:", nose1_count)
        if (nose1_count == 0):
            return False

        # step 1 忽略里程
        if (self.last_cmd == "8"):
            for i in range(1, 6):
                self.follow_8(v8)
                time.sleep(0.05)
        else:
            for i in range(1, 6):
                self.follow_8(v8 / 5 * i)
                time.sleep(0.05)
        while True:
            time5 = time.time()
            print("开始进入循环时间", time5)
            self.follow_8(v8)
            if (self.nose1_count > 6):
                print("8满磁**************************")
                break
            if (self.nose1_count == 0):
                self.feet.stop()
                return
            time6 = time.time()
            print("循环时间差循环时间差循环时间差循环时间差循环时间差循环时间差", (time6 - time5) * 1000, "毫秒")
        print("nextcmd", self.next_cmd)
        if (self.next_cmd == "8" or self.next_cmd == "h"):
            pass
        else:
            # 软减速
            print("开始软减速*************")
            n = 3
            for i in range(n, 1, -1):
                print("*********************************************", v8 / n)
                self.follow_8(v8 / n * i)
                time.sleep(0.05)
            self.feet.stop()
        return

    def follow_8(self, v):
        """
        后退
        :return:
        """
        (nose1_index, nose1_count) = self.nose1_read()
        # 根据巡磁,计算前后巡磁的姿态
        nose1_dx = self.NOSE_BIT_WIDTH * (nose1_index - 8.5)
        self.nose1_count = nose1_count
        print("dx:", nose1_dx)
        # r=self.nose_f1(nose1_dx)
        # if abs(nose1_dx) < 0.005:
        #    r = 0
        # elif abs(nose1_dx) <= 0.01:
        #    r = 0.02
        # elif abs(nose1_dx) <= 0.02:
        #    r = 0.04
        # elif abs(nose1_dx) <= 0.04:
        #    r = 0.2
        # else:
        #    r = 0.6
        # if(abs(v)>0.1):
        #    r=r*0.1/abs(v)
        if abs(nose1_dx) < 0.005:
            r = 0
        elif abs(nose1_dx) <= 0.01:
            r = 0.02 * nose1_dx / abs(nose1_dx)
        elif abs(nose1_dx) <= 0.015:
            r = 0.04 * nose1_dx / abs(nose1_dx)
        elif abs(nose1_dx) <= 0.02:
            r = 0.06 * nose1_dx / abs(nose1_dx)
        elif abs(nose1_dx) <= 0.025:
            r = 0.08 * nose1_dx / abs(nose1_dx) / 6
        elif abs(nose1_dx) <= 0.03:
            r = 0.1 * nose1_dx / abs(nose1_dx) / 6
        elif abs(nose1_dx) <= 0.04:
            r = 0.15 * nose1_dx / abs(nose1_dx) / 5
        elif abs(nose1_dx) <= 0.05:
            r = 0.2 * nose1_dx / abs(nose1_dx) / 3
        else:
            r = 0.3 * nose1_dx / abs(nose1_dx) / 2
        print("r：", r)

        print("r：", r)
        if nose1_dx == 0:
            nose_target_speed1 = v
            nose_target_speed2 = v
        elif nose1_dx > 0:
            nose_target_speed1 = v * (1 - abs(r))
            nose_target_speed2 = v
        else:  # (nose1_dx < 0):
            nose_target_speed1 = v
            nose_target_speed2 = v * (1 - abs(r))
        # time3 = time.time()
        # print("开始调用电机时间",time3)
        self.sp_dict["index"] = nose1_index
        self.sp_dict["count"] = nose1_count
        self.sp_dict["dx"] = nose1_dx
        self.sp_dict["left"] = nose_target_speed1
        self.sp_dict["right"] = nose_target_speed2
        self.sp_dict["r"] = r
        print("speed:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        # time4 = time.time()
        # print("step时间差:", (time4-time2)*1000,"电机调用时间差：",(time4-time3)*1000)
        # self.sp_dict["timecha"] = (time4-time3)*1000
        self.sp_list.append(self.sp_dict)
        self.sp_dict = {}
        return True

    def nose1_read(self):
        self.xunci = self.magnet1.read_one()
        self.sp_dict["xunci"] = self.xunci
        a = self.magnet1.get_int_value(self.magnet1.realtime_magnet)
        b = self.magnet1.get_magnet_index_count(a)
        return b

    def follow_5(self, v):
        print("a1:", time.time())
        (nose2_index, nose2_count) = self.nose2_read()

        print("a2:", time.time())
        self.new_dict["index"] = nose2_index
        self.new_dict["count"] = nose2_count
        self.nose2_count = nose2_count
        if nose2_count == 0:
            self.feet.stop()
            # this_cmd_error=ERROR_305
            return False
        if (v == 0.05 and self.nose2_count > 6):
            return True

        # 根据巡磁,计算前后巡磁的姿态
        nose2_dx = self.NOSE_BIT_WIDTH * (nose2_index - 8.5)

        print("dx:", nose2_dx)

        print("a3:", time.time())
        r = self.nose_f1b(nose2_dx)
        print("a4:", time.time())

        self.new_dict["r"] = r

        print("r：", r)

        if r == 0:
            nose_target_speed1 = v
            nose_target_speed2 = v
        elif r > 0:
            nose_target_speed1 = v
            nose_target_speed2 = v * (1 - abs(r))
        else:  # (r < 0):
            nose_target_speed1 = v * (1 - abs(r))
            nose_target_speed2 = v

        print("左右轮速度:", nose_target_speed1, nose_target_speed2)
        self.new_dict["left"] = nose_target_speed1
        self.new_dict["right"] = nose_target_speed2
        print("a5:", time.time())
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        print("a6:", time.time())
        self.new_list.append(str(self.new_dict))
        print("a7:", time.time())

        return True

    def follow_h(self, v):
        print("a1:", time.time())
        (nose1_index, nose1_count) = self.nose1_read()
        print("a2:", time.time())
        self.new_dict["index"] = nose1_index
        self.new_dict["count"] = nose1_count
        self.nose1_count = nose1_count
        if nose1_count == 0:
            self.feet.stop()
            # this_cmd_error=ERROR_305
            return False
        if (v == 0.05 and self.nose1_count > 6):
            return True

        # 根据巡磁,计算前后巡磁的姿态
        nose1_dx = self.NOSE_BIT_WIDTH * (nose1_index - 8.5)

        print("dx:", nose1_dx)

        print("a3:", time.time())
        r = self.nose_f1b(nose1_dx)
        print("a4:", time.time())

        self.new_dict["r"] = r

        print("r：", r)

        if r == 0:
            nose_target_speed1 = v
            nose_target_speed2 = v
        elif r > 0:
            nose_target_speed1 = v * (1 - abs(r))
            nose_target_speed2 = v
        else:  # (r < 0):
            nose_target_speed1 = v
            nose_target_speed2 = v * (1 - abs(r))

        print("左右轮速度:", nose_target_speed1, nose_target_speed2)
        self.new_dict["left"] = nose_target_speed1
        self.new_dict["right"] = nose_target_speed2
        print("a5:", time.time())
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        print("a6:", time.time())
        self.new_list.append(str(self.new_dict))
        print("a7:", time.time())

        return True

    f1_type = "A"

    def nose_f1(self, dx):
        self.f1_type = "A"
        if (self.f1_type == "A"):
            return self.nose_f1a(dx)
        elif (self.f1_type == "B"):
            return self.nose_f1b(dx)
        else:
            return self.nose_f1a(dx)

    def nose_f1a(self, dx):
        r = 0
        if abs(dx) < 0.005:
            r = 0
        elif abs(dx) <= 0.01:
            r = 0.02
        elif abs(dx) <= 0.015:
            r = 0.04
        elif abs(dx) <= 0.02:
            r = 0.07
        elif abs(dx) <= 0.025:
            r = 0.11
        elif abs(dx) <= 0.03:
            r = 0.2
        elif abs(dx) <= 0.04:
            r = 0.3
        elif abs(dx) <= 0.05:
            r = 0.4
        else:
            r = 0.6
        if (dx == 0):
            return 0
        elif (dx < 0):
            return -r
        else:  # dx>0
            return r

    def nose_f1b(self, dx):

        t = time.time()
        self.dx_t_list_all[self.dx_t_i][1] = dx
        self.dx_t_list_all[self.dx_t_i][0] = t
        self.dx_t_i = self.dx_t_i + 1
        if (self.dx_t_i >= 10):
            self.dx_t_i = 0

        sum = 0
        for a in self.dx_t_list_all:
            sum = sum + a[1]
        avg = sum / self.dx_t_list_all.__sizeof__()
        if (avg > 0.08):
            avg = 0.08
        if (avg < -0.08):
            avg = -0.08
        kp = 5
        ki = 3
        r = dx * kp + avg * ki
        if (r > 0.9):
            r = 0.9
        if (r < -0.9):
            r = -0.9
        return r

    def f1a(self):

        return

    def nose2_read(self):
        self.magnet2.read_two()
        a = self.magnet2.get_int_value(self.magnet2.realtime_magnet)
        b = self.magnet2.get_magnet_index_count(a)
        return b

    def ear_read(self):
        result = self.radar.read_radar()
        print('ear_read 读到避障数据=', result)
        return result

    def radar_after_read(self, radar_data):
        # 处理读数, 返回实际距离值

        # 处理前先把原来的数据清空
        # self.ear_this_radar_id.clear()
        self.ear_this_radar_id = []
        # radar_data格式:'F5 80 80 80 80 80 80 08 7F 87',中间8个值是避障数据
        if radar_data != '':
            radar_values = radar_data[3:30].strip().split(' ')
            for x in radar_values:
                # print(x, ', len(x)=', len(x), ', 10进制值=', int(x, 16))
                try:
                    y = int(x, 16)
                    # y值说明:实际距离为读数, 距离为30cm-250cm间, 单位:cm (0x01:盲区0-30cm内  0x7F:250cm内无障碍物  0x80:无探头)
                    # ear_this_radar_id中保存读数的数值, 635表示250cm内无障碍物, 640表示未接探头
                    self.ear_this_radar_id.append(y)
                except:
                    print("超声数据异常")
            print('超声避障数值=', self.ear_this_radar_id)

            # 将最新避障数据记录到避障最近10次的历史记录中,长度到达10则先移除掉最初的一个,保持最新的10次读数
            if len(self.ear_history_radar_id) >= 10:
                self.ear_history_radar_id.pop(0)
            self.ear_history_radar_id.append(self.ear_this_radar_id)

            # 在已经避障情况下, 检测连续10次避障是否都超过避障停车距离
            if self.ear_stop:
                self.ear_stop = False
                for x in self.ear_history_radar_id:
                    for y in x:
                        if y <= 30:
                            self.ear_stop = True
                            break
            else:
                # 原本未处于避障停车状态
                if self.ear_this_radar_id[0] <= 30 or self.ear_this_radar_id[1] <= 30 or self.ear_this_radar_id[
                    2] <= 30 or self.ear_this_radar_id[3] <= 30:  # or \
                    # self.ear_this_radar_id[4] <= 30 or self.ear_this_radar_id[5] <= 30 or self.ear_this_radar_id[6] <= 30 or self.ear_this_radar_id[7] <= 30:
                    self.ear_stop = True
                    self.ear_slow_down = False
                else:
                    self.ear_stop = False
                    self.ear_slow_down = False
                    for i in self.ear_this_radar_id:
                        if i > 30 and i <= 100:
                            self.ear_slow_down = True
                            self.ear_stop = False
                            break
        else:
            # 当前未读取到避障数据,避障不停车,不减速
            self.ear_stop = False
            self.ear_slow_down = False

    def follow_2(self, v=0.5):
        # 避障读取和处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)  # 将数据写入到ear_this_radar_id

        (nose2_index, nose2_count) = self.nose2_read()
        # 根据巡磁,计算前后巡磁的姿态
        nose2_dx = self.NOSE_BIT_WIDTH * (nose2_index - 8.5)
        self.nose2_count = nose2_count
        print("dx:", nose2_dx)
        # v2=0.6
        r = 0
        if abs(nose2_dx) < 0.005:
            r = 0
        elif abs(nose2_dx) <= 0.01:
            r = 0.02 * nose2_dx / abs(nose2_dx)
        elif abs(nose2_dx) <= 0.015:
            r = 0.04 * nose2_dx / abs(nose2_dx)
        elif abs(nose2_dx) <= 0.02:
            r = 0.06 * nose2_dx / abs(nose2_dx)
        elif abs(nose2_dx) <= 0.025:
            r = 0.08 * nose2_dx / abs(nose2_dx) / 6
        elif abs(nose2_dx) <= 0.03:
            r = 0.1 * nose2_dx / abs(nose2_dx) / 6
        elif abs(nose2_dx) <= 0.04:
            r = 0.15 * nose2_dx / abs(nose2_dx) / 5
        elif abs(nose2_dx) <= 0.05:
            r = 0.2 * nose2_dx / abs(nose2_dx) / 3
        else:
            r = 0.3 * nose2_dx / abs(nose2_dx) / 2
        #
        # kp=2
        # if abs(nose2_dx) < 0.005:
        #     kp=5
        #     #r = 2 * nose2_dx
        #     r=0
        # elif abs(nose2_dx) <= 0.01:
        #     kp=5
        #     #r = 2 * nose2_dx
        #     r=0.02 * nose2_dx/abs(nose2_dx)
        # elif abs(nose2_dx) <= 0.02:
        #     kp=2
        #     #r = 2 *  nose2_dx
        #     r= 0.05 * nose2_dx/abs(nose2_dx)
        # elif abs(nose2_dx) <= 0.04:
        #     kp=5
        #     #r = 5 * nose2_dx # 0.2
        #     r= 0.08 * nose2_dx/abs(nose2_dx)
        # else:
        #     kp=10
        #     r= 0.2 * nose2_dx/abs(nose2_dx)

        # r = 10 *  nose2_dx
        # r = kp * nose2_dx
        print("r：", r)
        if self.ear_enable:
            if self.ear_slow_down:
                print('避障减速, v = 0.1')
                v = self.ear_slow_down_limit_speed
            if self.ear_stop:
                print('避障停车, v = 0')
                v = 0

        t = time.time()

        if r == 0:
            nose_target_speed1 = v
            nose_target_speed2 = v
        elif r > 0:
            nose_target_speed1 = v
            nose_target_speed2 = v * (1 - abs(r))
        else:  # (r < 0):
            nose_target_speed1 = v * (1 - abs(r))
            nose_target_speed2 = v
        print("左右轮速度:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        return True

    def magnet_warn(self):
        try:
            self.sendJson["Channel"] = "WorkWarn-AGV"
            self.sendJson["Client"] = "AGV"
            self.sendJson["TaskSN"] = self.task_json["TaskSN"]
            self.sendJson["TaskCode"] = self.task_json["TaskCode"]
            self.sendJson["AGVCode"] = self.task_json["AGVCode"]
            self.sendJson["WarnCode"] = "02"
            self.sendJson["WarnContent"] = "脱磁"
            self.sendJson["WarnType"] = "1"
            self.sendinfo.sendtowarn(self.sendJson)
            self.sendJson = {}
            self.current_cmdStr_list = ""
        except Exception as ex:
            print("报警异常", ex)

        return


# 类的单元测试函数
def test():
    robot1 = Robot()
    robot1.start()  # runnint task t1
    return


if __name__ == "__main__":
    test()
