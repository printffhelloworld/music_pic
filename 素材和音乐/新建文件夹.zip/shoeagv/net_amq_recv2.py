# -*-coding:utf-8-*-
import stomp
import _thread
import json
import queue


class SampleListener():
    __listener_name = 'SampleListener'
    __topic_name1 = '/topic/WorkTask-AGV'
    __topic_name2 = 'WorkTask-AGV'
    __topic_name3 = '/topic/ResultTask'
    __host = '192.168.0.210'
    __port = 61613
    __user = "Opoudmes"
    __password ="mes@2019"
    a_code = "Dev-AGV03"
    conn = None
    tq = queue.Queue(maxsize=10)
    s = {}

    # def __init__(self,q):
    #     self.tq = q

    def on_message(self, headers, message):
        global a_code
        message2 = json.loads(message)
        if message2["AGVCode"] == self.a_code:
            self.runtask(message2)
        else:
            pass
        if message != "":
            _thread.start_new_thread(self.recv,(message2,))
    def recv(self,a):
        self.conn = stomp.Connection10([(self.__host, self.__port)],auto_content_length=False)
        self.conn.connect()
        self.s["Channel"] = "ResultTask"
        self.s["Client"] = "AGV"
        self.s["TaskSN"] = a["TaskSN"]
        self.s["TaskCode"] = a["TaskCode"]
        self.s["AGVCode"] = a["AGVCode"]
        self.s["From"] = a["From"]
        self.s["To"] = a["To"]
        self.s["Status"] = "3"
        self.s["Message"] = ""
        a = json.dumps(self.s)
        print("a=",a)
        self.conn.send(self.__topic_name3,a)
        # self.conn.send(self.__topic_name3,a)
    def runtask(self, msg):
        print("这是我的任务，我正在执行。。。", msg)
        self.tq.put(msg,block=True, timeout=None)
        return

    ## 从主题接收消息
    def receive_from_topic(self):
        print("开始建立mq连接")

        self.conn = stomp.Connection10([(self.__host, self.__port)])
        self.conn.set_listener(self.__listener_name, SampleListener())
        self.conn.start()
        self.conn.connect(self.__user, self.__password, wait=True)
        self.conn.subscribe(self.__topic_name1)
        while True:
            pass
        self.conn.disconnect()


if __name__ == '__main__':
    # conn = stomp.Connection10([(__host, __port)])
    # SampleListener().receive_from_topic()
    ss = SampleListener()
    ss.receive_from_topic()

