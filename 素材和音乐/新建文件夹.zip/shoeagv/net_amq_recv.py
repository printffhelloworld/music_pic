# -*-coding:utf-8-*-
import stomp
import _thread
import json
import queue

__listener_name = 'SampleListener'
__topic_name1 = '/topic/WorkTask-AGV'
__topic_name2 = '/topic/WorkTask-AGV'
__topic_name3 = '/topic/WorkTask-AGV2'
__host = '192.168.100.13'#192.168.0.210
__port = 61613#61616
__user = ""#admin
__password = ""#admin
a_code = "Dev-AGV01"
tq = queue.Queue(maxsize=10)


class SampleListener(object):

    def on_message(self, headers, message):
        global a_code
        message2 = json.loads(message)
        if message2['AGVCode'] == a_code:
            runtask(message2)
        else:
            pass
        print(message2)
        if (not message == ""):
            _thread.start_new_thread(send_after_recv, ())

#当接收到消息时对发布者进行回复
def send_after_recv():
    conn.send(__topic_name3, '已收到')


def runtask(msg):
    print("这是我的任务，我正在执行。。。", msg)
    tq.put(msg, block=True, timeout=None)
    print(tq.get())

## 从主题接收消息
def receive_from_topic():
    print("开始建立mq连接")
    conn.set_listener(__listener_name, SampleListener())
    conn.start()
    conn.connect(__user, __password, wait=True)
    conn.subscribe(__topic_name1)
    conn.subscribe(__topic_name2)
    while True:
        pass
    conn.disconnect()


if __name__ == '__main__':
    conn = stomp.Connection10([(__host, __port)])
    receive_from_topic()
