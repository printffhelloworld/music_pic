from iot_motor import PwmMotor
import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
from iot_modbus import SafeModbusClient
from iot_hongge_M7088 import Honge_M7088
from iot_modbus_rtu_xyd1210 import ModbusRtuXyd1210

class Feet():
    def __init__(self):
        return

    motor1=None
    motor2=None
    client=None
    type="motor_pwm"
    BAUD_RATE = 38400
    usb_port = '/dev/ttyUSB2'
    slave_num = 0x26
    TIME_OUT = 0.06

    MAX_WHEEL_SPEED_MPS = 0.785
    MAX_MOTOR_SPEED_RPM = 3000
    MAX_MOTOR_SPEED_PWM = 1000
    last_abs_pwm1=0
    last_abs_pwm2=0
    last_dir1=0
    last_dir2=0
    safe_modbus_client=None

    pwm_list = []
    pwm_dict ={}

    def init(self):
        self.motor1=PwmMotor()
        self.motor2=PwmMotor()
        self.motor2.ch_en = 1
        self.motor2.ch_fr = 2
        # self.motor2.ch_pwm = 6
        self.motor2.ch_pwm = 704#右
        self.motor1.ch_en = 3
        self.motor1.ch_fr = 4
        # self.motor1.ch_pwm = 7
        self.motor1.ch_pwm = 705#左
        self.safe_modbus_client = SafeModbusClient()

        #泓格M7088
        self.hongge = Honge_M7088()
        self.hongge.config("/dev/ttyUSB1", 27, 38400)
        self.hongge.connect()
		
        self.modbus2 = ModbusRtuXyd1210()
        self.modbus2.connect()
        #关闭发光板
        self.modbus2.write_Y7(1)

        return

    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port = usb
        self.slave_num = slave_num
        return True

    def connect(self):
        self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',
                                   baudrate=self.BAUD_RATE, timeout=self.TIME_OUT)
        self.isconnected = self.client.connect()
        print("脚的连接结果:",self.isconnected)
        self.motor1.client = self.client
        self.motor2.client = self.client
        self.safe_modbus_client.client = self.client
        self.motor1.safe_modbus=self.safe_modbus_client
        self.motor2.safe_modbus = self.safe_modbus_client

        return
    def stop(self):
        print("执行停止指令",self.slave_num)
        for i in range(1,5) :
            rr=self.hongge.stop()
            ok= self.safe_modbus_client.safe_write_holding_register(5, 0, self.slave_num)
            if(ok):
                self.last_dir1 = 0
                self.last_dir2 = 0
                self.last_abs_pwm1 = 0
                self.last_abs_pwm2 = 0
                return True
        print("5 times not STOPPPPPPP!")
        return False


    def set_direction(self,dir1,dir2):
        """
            设置车辆行驶方向
            :param direction
            : 方向, 0表示
        """
        if(dir1==0 and dir2==0):
            rr = self.safe_modbus_client.safe_write_holding_register(5,0,self.slave_num)

            return True
        elif (dir1 == 1 and dir2==1):
            while True:
                rr = self.safe_modbus_client.safe_write_holding_register(5,1,self.slave_num)
                if(rr):
                   break
            while True:
                rr = self.safe_modbus_client.safe_write_holding_register(1,0,self.slave_num)
                if(rr):
                   break
            while True:
                rr = self.safe_modbus_client.safe_write_holding_register(3,0,self.slave_num)
                if(rr):
                   break
            print("方向确定",rr)
            return True
        else:
            ok1=self.motor1.set_direction(self.motor1.ch_en ,self.motor1.ch_fr,dir1,self.slave_num)
            ok2=self.motor2.set_direction(self.motor2.ch_en ,self.motor2.ch_fr,dir2,self.slave_num)
            return (ok1 and ok2 )


    def set_speed_pwm(self, pwm1, pwm2):
        print("pwm:",pwm1,pwm2)
        ok=True
        print("a51:", time.time())
        if(self.sgn(pwm1)==self.last_dir1 and self.sgn(pwm2)==self.last_dir2):
            print(110)
            pass
        else:
            print(113)
            ok1=self.set_direction(self.sgn(pwm1),self.sgn(pwm2))
            ok=ok and ok1
            if(ok1):
                self.last_dir1=self.sgn(pwm1)
                self.last_dir2 = self.sgn(pwm2)
        print("a52:", time.time())
        if (self.last_abs_pwm1 == abs(int(pwm1))):
            print(119)
            pass
            ok2=True
        else:
            print(124)
            i = 1
            ok2=True
            while i<=3:
                # ok2 = self.motor1.set_abs_pwm(self.motor1.ch_pwm,abs(pwm1),self.slave_num)
                ok2 = self.hongge.set_abs_pwm(self.motor1.ch_pwm, abs(pwm1), self.slave_num)
                if(ok2):
                    break
                else:
                    i = i+1
                if(i == 4 and not ok2):
                    self.stop()
                    break
            ok = ok and ok2
            if(ok2):
                self.last_abs_pwm1=abs(int(pwm1))
        print("a53:", time.time(),";ok2",ok2)
        if(self.last_abs_pwm2==abs(int(pwm2))):
            print(140)
            pass
        else:
            print(143)
            i = 1
            ok3=True
            while i <=3 :
                print("a54:", time.time(), "i:", i)
                # ok3 = self.motor2.set_abs_pwm(self.motor2.ch_pwm,abs(pwm2),self.slave_num)
                ok3 = self.hongge.set_abs_pwm(self.motor2.ch_pwm,abs(pwm2),self.slave_num)
                print("a55:",time.time(),"ok3：",ok3)
                if(ok3):
                    break
                else:
                    i = i+1
                if(i == 4 and not ok3):
                    self.stop()
                    break
            if(ok3):
                self.last_abs_pwm2 = abs(int(pwm2))
            ok=ok and ok3
        print("a56:", time.time())

        if (self.sgn(pwm1) == self.last_dir1 and self.sgn(pwm2) == self.last_dir2):
            print(110)
            pass
        else:
            print(113)
            ok1 = self.set_direction(self.sgn(pwm1), self.sgn(pwm2))
            ok = ok and ok1
            if (ok1):
                self.last_dir1 = self.sgn(pwm1)
                self.last_dir2 = self.sgn(pwm2)
        print("a57:", time.time())
        return ok

    def sgn(self,x):
        try:
            if abs(x) < 0.0000001:
                return 0
            elif x>0:
                return 1
            elif x<0:
                return -1
            else:
                return None
        except:
            return None



    def set_speed_mps(self, mps1, mps2):
        pwm1 = mps1 /self.MAX_WHEEL_SPEED_MPS *self.MAX_MOTOR_SPEED_PWM
        pwm2 = mps2 /self.MAX_WHEEL_SPEED_MPS *self.MAX_MOTOR_SPEED_PWM
        if mps1==0 and  mps1==mps2 :
            self.stop()
        else:
            self.set_speed_pwm(pwm1, pwm2)
        return


def test():
    feet=Feet()
    feet.init()
    feet.config("/dev/ttyUSB1", 0x26, 38400)
    feet.connect()

    a=0.785/20/5
    for i in range(1,4):
        feet.set_speed_mps(i*0.2, i*0.2)
        time.sleep(0.3)
    a=0.78/20/5
    feet.set_speed_mps(a,a)
    time.sleep(3)
    for i in range(8,1,-1):
        feet.set_speed_mps(i*0.1, i*0.1)
        time.sleep(0.3)
    #for i in range(1,20):
    #    feet.set_speed_mps(i*a, -i*a)
    #    time.sleep(0.3)
    #time.sleep(3)
    #for i in range(20,1,-1):
    #    feet.set_speed_mps(i * a, -i * a)
    #    time.sleep(0.3)
    #for i in range(1,20):
    #    feet.set_speed_mps(-i * a, i * a)
    #    time.sleep(0.3)
    #time.sleep(3)
    #for i in range(20,1,-1):
    #    feet.set_speed_mps(-i * a, i * a)
    #    time.sleep(0.3)
    feet.stop()



if __name__ == '__main__':
    test()