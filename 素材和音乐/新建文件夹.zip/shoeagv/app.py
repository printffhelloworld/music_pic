# -*- coding:utf-8 -*-
# !/res/moobot/slender/app.py
# author: 杨志成
# email:yangzc2009cc@163.com
# 超薄车
# import robot
# import web_lora
from robot import Robot
from flask import Flask, url_for, render_template, redirect, jsonify
from flask import request
from web import runweb
import _thread
from net_amq_recv2 import SampleListener
import time


robot1 = None
web1 = None
amqrecv = None

def init():
    global robot1
    global web1
    global amqrecv
    robot1 = Robot()

    amqrecv = SampleListener()
    robot1.task_queue = amqrecv.tq

    web1 = runweb()
    #树莓派上一共要跑两个软件:
    #1, 一个是机器人的控制程序
    _thread.start_new_thread(run,(1,))
    time.sleep(2)


    # print("38")
    _thread.start_new_thread(recv, (1,))
    robot1.run()


    # amqrecv = SampleListener(robot1)

    # amqrecv.receive_from_topic()

def run(a):
    global robot1
    web1.start(robot1)

def recv(b):
    try:
        amqrecv.receive_from_topic()
    except:
        pass

def dispose():
    try:
        print("app dispose()")
        robot1.dispose()
        web1.dispose()
    except Exception as ex:
        return
    return True


if __name__=="__main__":
    init()
    dispose()
    while True:
        pass
    # exit(0)
