#!/res/Pycharm/iot/iot_motor.py
# pip install pymodbus
# 双轮同步升速、保持高速、同步降速停车，当占空比很小时(电机转不动)需要把使能关掉
import time
from iot_modbus import SafeModbusClient
from pymodbus.client.sync import ModbusSerialClient as ModbusClient


class Honge_M7088():

    def __init__(self):
        return

    # 1.2 关键配置
    BAUD_RATE = 38400
    # 接24V电;12V会错一半
    usb_port = '/dev/ttyUSB1'
    slave_num = 27
    TIME_OUT = 0.02
    client = None
    safe_modbus = None

    ch_en = 1
    ch_fr = 2
    ch_pwm = 6
    last_pwm = 0

    open_pwm = 0

    def init(self):
        self.safe_modbus = SafeModbusClient()
        return

    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port = usb
        self.slave_num = slave_num
        return True

    def connect(self):
        if (self.client == None):
            self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',
                                       baudrate=self.BAUD_RATE, timeout=self.TIME_OUT)
        isconnected = self.client.connect()
        print("泓格pwm板连接结果=", isconnected)
        return True

    MAX_PWM = 1000
    MAX_MOTOR_SPEED_RPM = 3000  # rpm
    count = 0
    count_pwm=0
    def stop(self):
        try:
            rr = self.client.write_coils(0, (0,0), unit=27).encode()
            self.count_pwm = 0
            print("占空比关闭,第", self.count_pwm + 1, "次,成功")
            self.open_pwm=0
            return rr
        except Exception as ex:
            self.count_pwm += 1
            print("占空比第", self.count_pwm, "次关闭失败", ex)
            if self.count >= 4:
                print("占空比最终关闭失败")
                return False
            else:
                self.stop()
    def set_pwm_on(self):
        try:
            rr = self.client.write_coils(0, (1,1), unit=27).encode()
            self.count_pwm = 0
            print("占空比开启,第", self.count_pwm + 1, "次,成功")
            return rr
        except Exception as ex:
            self.count_pwm += 1
            print("占空比第", self.count_pwm, "次开启失败", ex)
            if self.count >= 4:
                print("占空比最终写入失败")
                return False
            else:
                self.set_pwm_on()
    def set_abs_pwm(self, ch_pwm, abs_pwm, slave_num):
        if self.open_pwm == 0:
            #开启占空比.不开启就改变不了占空比
            self.set_pwm_on()
        try:
            rr = self.client.write_register(ch_pwm, abs(int(abs_pwm)), unit=27).encode()
            self.count = 0
            print(ch_pwm, "电机第", self.count + 1, "次写入成功")
            return rr
        except Exception as ex:
            self.count += 1
            print("第", self.count, "次写入ch=", ch_pwm, "失败", ex)
            if self.count >= 4:
                print("最终写入失败")
                return False
            else:
                self.set_abs_pwm(ch_pwm, abs_pwm, slave_num)

    def dispose(self):
        self.client.close()
        return


def test():
    motor = Honge_M7088()
    motor.config("/dev/ttyUSB1", 27, 38400)
    motor.connect()
    #motor.set_abs_pwm(704,990,27)
    #motor.set_abs_pwm(705,990,27)
    try:
        # !!!地址比协议小1
        # !!!4开头表示读写属性 03 功能码
        # !!!40737表示的实际地址736
        # 启停
        #rr = motor.client.write_coil(0, (1,1), unit=27).encode()
        # 设置模式
        # motor.set_abs_pwm(864, 1, 27)
        # 频率
        # motor.set_abs_pwm(736,10000, 27)
        # motor.set_abs_pwm(737,0, 27)
        # 占空比
        motor.set_abs_pwm(704, 990, 27)  # 测试可以改速度,右轮
        motor.set_abs_pwm(705, 990, 27)  # 测试可以改速度,左轮
        #time.sleep(5)
        # 启停
        rr = motor.client.write_coils(0, (0,0), unit=27).encode()
        print(rr)
    except Exception as ex:
        print(ex)


if __name__ == '__main__':
    # 测试电机加速、保持满速、降速、停车过程
    test()