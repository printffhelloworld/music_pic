# -*- coding:utf-8 -*-
#! /moobot/res/slenderagv/robot.py
# 主要是机器人的主运行逻辑.
# 核心架构为异步多线程
# python 并不能很好的利用多核的优势, 所以多线程对于pytho来说是伪命题.
import os
import threading
import _thread
import logging
import time
import queue
import json
import re
from iot_radar import Radar
from iot_rfid_rc522 import Rfid
from iot_voltage import Voltage
from iot_motor import PwmMotor2
from iot_magnet_ms16a import Magnet
from net_tcp_listener import TcpCommander
from backroute import BackRoute
from net_lora_commander import LoraCommander


class Robot(threading.Thread):

    #巡磁
    magnet1 = None
    # rfid
    rfid1 = None
    rfid1_client = None
    mouth_last_rfid_id = ''  # 上一次读到的非零rfid卡号
    mouth_this_rfid_id = ''  # 当前rfid卡号
    mouth_new_rfid_count = 0  # 新卡计数
    rfid_list = []
    is_charging = False  # 是否在充电
    charging_rfid_list = []  # 充电位卡号列表
    mouth_ingore_flag = False  # 是否忽略里程
    nose1_dx=0
    nose2_dx=0
    r=0
    # 超声避障
    radar = None
    radar_client = None

    # 是否开启避障(只在2指令高速行驶时候才打开)
    ear_enable = False
    # 超声避障读数，创建空元祖，读取时候接收新数据,每次接收后处理时先清空然后再赋值
    ear_this_radar_id = []
    # 超声避障最近10次读数记录,内部存储10次ear_this_radar_id,用于在避障停车时防止数据波动导致避障时走时停,车子快速反复地行驶和停车
    ear_history_radar_id = []
    # 是否避障停车
    ear_stop = False
    ear_slow_down = False
    ear_slow_down_limit_speed = 0.2

    # 电压采集
    voltage = None
    voltage_value = 0

    waist1 = None
    back1 = None
    feet = None
    NOSE_BIT_WIDTH = 0.01
    backroute = None
    # 服务端的ip地址
    # server_ip = '127.0.0.1'
    server_ip = '192.168.43.162'
    # 服务端socket绑定的端口号
    server_port = 20000
    tcpcommander = None
    loracommander = None

    modbus_client1=None

    # 给inside服务
    channel_data=[{"id":"","name":"ch","dr":0, "dw":0}]

    # 给team服务
    task_queue=queue.Queue(maxsize=10)
    cmd_str=""
    command_list=[]
    nose1_count=0
    nose2_count=0
    # 当前任务
    current_task = ""
    # 当前任务列表
    current_cmd_list = []
    list_id = 1
    dict_msg = {}
    # 当前任务指令字符串
    current_cmdStr = ""
    # 指令长度
    cmdNum = 0

    #当前指令
    cmd_this=""
    cmd_this_start_time=None
    cmd_this_end_time=None
    idle_start_time=None
    idle_end_time=None

    #主状态
    main_state= 0
    MAIN_STATE_INIT = 100
    MAIN_STATE_IDLE = 200
    MAIN_STATE_BUSY = 300
    MAIN_STATE_BUSY_RUNNING = 310
    MAIN_STATE_BUSY_FINISH = 320
    MAIN_STATE_BUSY_BLOCKED = 330
    MAIN_STATE_WAIT = 400
    MAIN_STATE_ERROR = 500
    MAIN_STATE_ERR_DONE = 510
    MAIN_STATE_ERR_UNDONE = 520
    MAIN_STATE_ERR_UNKNOW = 530
    task_queue=[]
    autoMode=True

    flag_system_alarm = False
    # 错误代码识别号
    # 11xx:巡磁错误系列
    ERROR_CODE_OUT_OF_MAGNET = 1101
    # 12xx:rfid错误系列
    ERROR_CODE_WITHOUT_THIS_RFID = 1201  # 没有这个rfid卡,可能卡坏了
    # 13xx:超声避障错误系列

    if_check_after_cmd = False
    # 车子位置姿态, 默认为起点位置坐标(9,0,180),方向为朝射频门方向
    x = 8
    y = 1
    w = 180

    # 指令执行完后预期到达的点位坐标
    sim_x = 0
    sim_y = 0
    sim_w = 0

    sp_dict = {}
    sp_list = []

    #Part 1 构造函数
    def __init__(self):
        super(Robot, self).__init__()
        return

    def init(self):
        try:
            self.backroute = BackRoute()


            self.feet = PwmMotor2()
            # self.feet.config("COM13", 0x25, 38400)
            self.feet.config('/dev/ttyUSB1', 0x25, 38400)
            self.feet.connect()
            self.tcpcommander = TcpCommander()
            # self.waist1 = Waist3()
            # self.waist1.init()
            # self.waist1.rtu.client = self.feet.client

            # self.back1 = backbone()
            # self.back1.init()
            # self.back1.rtu.client=self.feet.client

            self.magnet1 = Magnet()
            self.magnet1.client=self.feet.client
            # self.rfid1 = Rfid('COM10', 9600, 0.5)

			# RFID
            self.rfid1 = Rfid('/dev/ttyUSB2', 9600, 0.5)
            self.rfid1_client = self.rfid1.init()

            # 超声避障
            self.radar = Radar('/dev/ttyUSB3', 9600, 0.5)
            self.radar_client = self.radar.init()

            # 电压采集
            self.voltage = Voltage('/dev/ttyUSB1', 38400, 0x05)
            self.voltage.connect()

            # 初始化loracommander对象
            self.loracommander = LoraCommander('/dev/ttyUSB0', 9600)
            self.loracommander.connect()
        except:
            print("有异常")

        # 读取rfid配置
        self.read_rfidjson()

        #启动TCPIP
        # self.task_queue = self.tcpcommander.q
        self.task_queue = self.loracommander.q
        # tcp对象中引用robot中的属性,用于反馈状态给上位机
        self.tcpcommander.feet = self.feet
        self.set_states()
        _thread.start_new_thread(self.tcpcommander.connect,("启动TCPIP通讯",))
        self.autoMode=self.tcpcommander.autoMode
        return

    #Part 3 进程主函数, 每个机器人都以此作为最核心的代码.
    def run(self):
        print('进入robot_main.run()')
        self.main_state = self.MAIN_STATE_INIT
        self.init()
        self.main_state = self.MAIN_STATE_IDLE
        print("IDLE")
        while True:
            self.autoMode=self.tcpcommander.autoMode
            self.set_states()
            try:
                if self.voltage == None:
                    print('电压还未创建对象,无法获取电压值')
                else:
                    self.voltage_value = self.voltage.read_voltage()
                    print("读取电压值=", self.voltage_value)
                if self.autoMode == True:
                    if self.flag_system_alarm:
                        print('系统报警状态,需要人为干预恢复')
                        time.sleep(0.5)
                    else:
                        print('队列长度=', self.task_queue.qsize())
                        if(self.task_queue.qsize() == 0):
                            print("目前队列为空")
                            self.feet.stop()
                            time.sleep(0.5)
                            continue
                        else:
                            self.main_state = self.MAIN_STATE_BUSY
                            print("BUSY")
                            byte_q = self.task_queue.get()
                            byte_q1 = str(byte_q).encode("utf-8")
                            self.current_task = byte_q1.decode("utf-8")
                            print("RUN", self.current_task)
                            print("-------------------------------------")
                            print("当前任务:", self.current_task)
                            ok = self.run_task()
                            if(not ok):
                                continue
                            ok=self.run_commandStr()
                            if (not ok ):
                                continue
                            time.sleep(0.5)  # 任务执行完毕后, 休息0.5秒, 防止前后冲突
                            self.main_state = self.MAIN_STATE_IDLE
                            print("IDLE 开始下一次循环")
                else:
                    print("手动模式中----------")
            except Exception as ex:
                self.main_state=self.MAIN_STATE_ERROR
                self.error=ex
                print("ERROR")

                recovered= self.deal_error(self.MAIN_STATE_ERROR, '主循环发生异常')
                if(recovered==True):
                    print("Error Recovered")
                    time.sleep(0.5)
                    print("IDLE")
                    self.main_state = self.MAIN_STATE_IDLE
                    continue
                else:
                    print("Error Unrecovered")
                    time.sleep(0.5)
                    self.main_state = self.MAIN_STATE_ERR_UNDONE
                    exit(1)
        # return

    def search_warejson(self,cmdStr):
        res = open("data/WarehouseRoutes.json",encoding='utf-8').read()
        wareRoute = json.loads(res)
        dict = wareRoute["routes"]
        # print(dict)
        cmd = ""
        print("cmdStr=",cmdStr)
        for i in dict:
            if (i["routeId"] == cmdStr):
                print(i["cmd"])
                cmd = i["cmd"]
        return cmd

    def search_movejson(self,cmdStr):
        res = open("MoveHouseRoutes.json",encoding='utf-8').read()
        wareRoute = json.loads(res)
        dict = wareRoute[cmdStr]
        return dict

    #出错处理, 返回是否
    # 如果出错处理成功, 机器可以继续运行, 则返回是
    # 否则False, 然后机器要重启启动加载.
    def deal_error(self, code, msg):
        # TODO 出错处理
        # 1.巡磁脱磁处理,根据
        # 2.查询实际读到的RFID卡,和表中配置的卡号对应不上,RFID卡可能损坏
        if code == self.ERROR_CODE_OUT_OF_MAGNET:
            # 区分是慢慢偏出巡磁还是走到磁条末端脱磁
            pass

        if code == self.ERROR_CODE_WITHOUT_THIS_RFID:
            self.flag_system_alarm = True
            return False


        return False
    # 根据task生成commandlist
    def calculate_command_list(self,task):

        self.cmd_str="246132"
        # task_cmdstr_json_dictionary
        #cmd_str=读取数据库, 获得task对应的cmd_str
        #TODO: 目前是假数据
        self.command_list=["2","4","6","1","3","2"]
        #将cmd_str分解为command数组
        print("BUSY: GET cmd_str", self.cmd_str)
        return True


    # Part 4. 执行
    # 4.1 一个指令任务
    def run_task(self):
        print("开始对队列中消息进行判断")
        if(self.current_task.__eq__("get_state")):
            print("收到请求状态指令")

        elif(bool(re.match("\d{0,}$",self.current_task))):
            self.current_cmdStr = self.current_task
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("x-") and not self.current_task.__contains__("-x")):
            cstr1 = self.current_task[2:]
            s1 = self.search_warejson(cstr1)
            ## self.current_cmdStr = "7"+ s1 + "9" + self.backroute.backroute2(s1) + "0"
            self.current_cmdStr =  "5"+s1[3:] + "9" + self.backroute.backroute2(s1) + "660"
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("-x") and not self.current_task.__contains__("x-")):
            cstr2 = self.current_task[0:4]
            s2 = self.search_warejson(cstr2)
            self.current_cmdStr = "9" + s2 + "7" + (self.backroute.backroute2(s2))[0:s2.__len__()-4] + "5"
            print("获取cmd", self.current_cmdStr)

        elif (self.current_task.__contains__("-") and not self.current_task.__contains__(
                "-x") and not self.current_task.__contains__("x-")):
            s3 = self.current_task[0:4]
            current_cmdStr1 = self.search_warejson(s3)
            s4 = self.current_task[5:]
            current_cmdStr2 = self.search_warejson(s4)
            self.current_cmdStr = "9" + current_cmdStr1 + "7" + self.backroute.backroute2(current_cmdStr1) + "66" + current_cmdStr2 + "9" + self.backroute.backroute2(current_cmdStr2) + "660"
            print('原始的移库路径=', self.current_cmdStr, ',长度=',len(self.current_cmdStr))
            while True:
                len1 = len(self.current_cmdStr)
                self.current_cmdStr = self.current_cmdStr.replace('2442', '44')
                self.current_cmdStr = self.current_cmdStr.replace('2445', '44')
                self.current_cmdStr = self.current_cmdStr.replace('5442', '44')
                self.current_cmdStr = self.current_cmdStr.replace('5445', '44')
                self.current_cmdStr = self.current_cmdStr.replace('2662', '66')
                self.current_cmdStr = self.current_cmdStr.replace('2665', '66')
                self.current_cmdStr = self.current_cmdStr.replace('5662', '66')
                self.current_cmdStr = self.current_cmdStr.replace('5665', '66')
                self.current_cmdStr = self.current_cmdStr.replace('4444', '')
                self.current_cmdStr = self.current_cmdStr.replace('6666', '')
                self.current_cmdStr = self.current_cmdStr.replace('444', '6')
                self.current_cmdStr = self.current_cmdStr.replace('666', '4')
                self.current_cmdStr = self.current_cmdStr.replace('28', '')
                self.current_cmdStr = self.current_cmdStr.replace('82', '')
                self.current_cmdStr = self.current_cmdStr.replace('58', '')
                self.current_cmdStr = self.current_cmdStr.replace('85', '')
                self.current_cmdStr = self.current_cmdStr.replace('46', '')
                self.current_cmdStr = self.current_cmdStr.replace('64', '')
                if len1 == len(self.current_cmdStr):
                    self.current_cmdStr = self.current_cmdStr.replace('24', '54')
                    self.current_cmdStr = self.current_cmdStr.replace('26', '56')
                    self.current_cmdStr = self.current_cmdStr.replace('42', '45')
                    self.current_cmdStr = self.current_cmdStr.replace('62', '65')
                    break
            print("获取cmd", self.current_cmdStr)
        else:
            print("格式异常")
            return False
        print("判断结束")
        return True

    def run_commandStr(self):
        if (self.current_cmdStr == ""):
            print("未找到相关指令")
            return False
        self.cmdNum = self.current_cmdStr.__len__()
        print("指令长度：", self.cmdNum)  # cmdstr->cmdlist
        self.dict_msg["id"] = self.list_id
        self.dict_msg["cmd"] = self.current_cmdStr
        cmd_index = 0  # 指令序号
        while cmd_index < len(self.current_cmdStr):
            singlecmd = self.current_cmdStr[cmd_index]
            self.safe_go(singlecmd, self.dict_msg)
            # 执行完指令后校验位置,如果有走错就纠偏返回到上一个点
            # self.check_rfid_after_cmd(singlecmd, cmd_index)
            # 指令序号加1,开始执行下一个指令
            cmd_index += 1
        self.current_cmd_list.append(self.dict_msg)
        logging.info("[run_commandStr] 执行完一次任务:" + self.dict_msg.__str__())
        self.dict_msg = {}
        self.list_id = self.list_id + 1
        return True

    def check_rfid_after_cmd(self, singlecmd, cmd_index):
        if self.if_check_after_cmd:
            logging.info('单个指令 ' + singlecmd + ' 执行完,开始检查是否走到错误RFID卡')
            # 单指令执行完毕后
            # step7.查表获取实际rfid对应的坐标
            if self.mouth_this_rfid_id != '':
                self.check_this_rfid = True
            else:
                # 使用上一张rfid卡来检测对比
                self.check_this_rfid = False

            # 对比卡号
            (read_x, read_y) = self.read_rfid()
            logging.info('cmd_index=' + str(cmd_index) + ', 执行指令singlecmd=' + singlecmd + ',读取到的xy=(' + str(read_x) + ',' + str(read_y) + ')')
            if read_x == -1 and read_y == -1:
                if self.mouth_this_rfid_id == '' and self.mouth_last_rfid_id == '':
                    # 没有读到实时rfid卡,并且从未读到过卡,无法进行修正位置
                    logging.info('还未读到过rfid卡,还无法进行修正位置')
                    pass
                else:
                    # 未查询到读到的卡号,可能是配置RFID卡号出错或者RFID卡已损坏需要更换
                    ok_deal_error = self.deal_error(self.ERROR_CODE_WITHOUT_THIS_RFID, '查询实际读到的RFID卡,和表中配置的卡号对应不上,RFID卡可能损坏') # 200系列:RFID出错
                    logging.info('读到的rfid卡是-1,-1, 进入处理错误函数, 处理结果='+ ok_deal_error.__str__())
                    if ok_deal_error:
                        pass
                    else:
                        # 无法成功处理异常/错误,车子停止
                        logging.info('处理结果=False, 发送停车指令')
                        self.safe_go_0()
                        # TODO 程序停住,不能往下执行,flag_system_alarm报警需要在上位机下发指令重置
                        while self.flag_system_alarm:
                            time.sleep(1)
                        else:
                            # 消警后恢复到初始情况
                            self.reset_car()
            else:
                # 比对坐标来确定是否是同一张卡
                ok = self.check_read_sim_rfid(read_x, read_y, self.sim_x, self.sim_y, self.sim_w)
                if ok:
                    # 校验发现读到的和预期的一致,指令执行到正确点位,执行下一个指令
                    self.x = read_x
                    self.y = read_y
                    logging.info('读取的rfid卡点位坐标和预期的点位坐标相同,设置车子点位坐标为读到的坐标,(x,y,w)=(' +
                        str(self.x) + ',' + str(self.y) + ',' + str(self.w) + '), 预期坐标=(' +
                        str(self.sim_x) + ',' + str(self.sim_y) + ',' + str(self.sim_w) + ')')
                    if self.w != self.sim_w:
                        self.w = self.sim_w
                        logging.info('发现w不同,self.w设置为sim_w')
                    pass
                else:
                    # 生成更正指令,添加到当前指令完指令后
                    logging.info('检测对比rfid卡发现不同, 当前读取位置=(' + str(read_x) + ',' + str(read_y) + ',' +
                        str(self.w) + ')(w为self.w), 预期位置=(' + str(self.sim_x) + ',' + str(self.sim_y) + ','+ str(self.sim_w) + ")")
                    gostr = self.get_go_str(read_x, read_y, self.sim_x, self.sim_y, self.sim_w, singlecmd)
                    if gostr == '':
                        logging.info('走错路无法返回到预期位置')
                        # 无法找到退回的指令,停车
                        self.safe_go_0()
                        # 报警通知上位机走错路无法返回
                        self.flag_system_alarm = True
                        return False
                    else:
                        self.x = read_x
                        self.y = read_y
                        logging.info('计算出往回走的指令,设置车子当前点位坐标为读到的坐标,(x,y,w)=(' +
                            str(self.x) + ',' + str(self.y) + ',' + str(self.w) + '), 此时预期坐标=(' + str(self.sim_x) +
                            ',' + str(self.sim_y) + ',' + str(self.sim_w) + ')')
                        if self.w != self.sim_w:
                            self.w = self.sim_w
                            logging.info('发现w不同,self.w设置为sim_w')
                        logging.info('需要添加的倒退指令gostr=' + gostr + ', 添加前整体指令=' + self.current_cmdStr + ', cmd_index=' +  str(cmd_index))
                        self.current_cmdStr = self.current_cmdStr[0:cmd_index + 1] + gostr + self.current_cmdStr[cmd_index + 1:]
                        logging.info('整体指令添加倒退指令后=' + self.current_cmdStr)

    def reset_car(self):
        logging.warn("重置车子状态")
        self.ear_history_radar_id = []
        self.ear_enable = False
        self.ear_stop = False
        self.ear_slow_down = False
        self.is_charging = False
        return

    #安全执行
    def safe_go(self,cmd, command_json={}):
        print("safe_go:",cmd)
        # if (cmd == None or cmd ==""):
        #     logging.error("Blank command")
        #     return True
        # else:
        #     #cmd = cmd.trim(" ")
        self.mouth_new_rfid_count=0
        self.mouth_last_rfid_id = ''
        # 保险起见,每次指令指令前先把避障关掉,执行2指令时候开启,2指令执行完关闭
        self.ear_enable = False

        # 执行指令前先模拟计算出到达的预期RFID卡号坐标
        # step6.计算指令结束后预测应该到达的rfid卡的坐标
        if self.if_check_after_cmd:
            (self.sim_x, self.sim_y, self.sim_w) = self.sim_run(cmd, self.x, self.y, self.w)
            print('当前位置(', self.x, ', ', self.y, ', ', self.w, '), 预期位置(', self.sim_x, ', ', self.sim_y, ', ', self.sim_w, ')')

        if (cmd == ""):
            return True
        elif (cmd == "1"):
            print("开始指令1")
            self.safe_go_1()
            print("指令1执行结束")
            return True
        elif (cmd == "3"):
            print("开始指令3")
            self.safe_go_3()
            print("指令3执行结束")
            return True
        elif (cmd == "2"):
            print("开始执行2指令")
            self.safe_go_2()
            print("指令2结束")
            return True
        elif (cmd == "4"):
            print("开始执行指令4")
            self.safe_go_4()
            print("指令4执行结束")
            return True
        elif (cmd == "6"):
            print("开始执行6指令")
            self.safe_go_6()
            print("指令6执行结束")
            return True
        elif (cmd == "8"):
            print("开始执行8指令")
            self.safe_go_8()
            print("指令8执行结束")
            return True
        elif (cmd == "5"):
            print("开始执行5指令")
            self.safe_go_5()
            print("指令5执行结束")
            return True
        elif (cmd == "0"):
            print("开始执行0指令")
            self.safe_go_0()
            print("指令0执行结束")
            return True
        elif (cmd == "7"):
            print("开始执行7指令")
            self.safe_go_7()
            print("指令7执行结束")
            return True
        elif (cmd == "9"):
            print("开始执行9指令")
            self.safe_go_9()
            print("指令9执行结束")
            return True
        else:
            print("未知指令")
            return False

    # NORMAL_SPEED = 0.05

    # @此方法暂未使用(实际点位与预期点位用坐标对比,不用rfid卡号对比)
    def get_sim_rfid(self, sim_x, sim_y, sim_w):
        # 根据预期的坐标查表获取预期rfid卡(同一点位最多有3张卡)
        for x in self.rfid_list:
            if x['x'] == sim_x and x['y'] == sim_y and x['w'] == sim_w:
                return x['rfid1'], x['rfid2'], x['rfid3']
        return ''

    # 指令集
    #5.2
    #转腰
    def safe_go_1(self):
        self.waist1.go_next()
        return True
    def safe_go_3(self):
        self.waist1.go_last()
        return  True
    #顶升
    def safe_go_7(self):
        # self.back1.up()
        self.feet.stop()
        time.sleep(1)
        self.up()
        time.sleep(7)
        print('顶升升起等待7秒时间到')
        return  True
    def safe_go_9(self):
        # self.back1.down()
        self.feet.stop()
        time.sleep(1)
        self.down()
        time.sleep(7)
        print('顶升下降等待7秒时间到')
        return  True

    def safe_go_8(self):
        self.mouth_ingore_flag = True
        # step 1 判断脱磁条
        (nose_index, self.nose2_count) = self.nose2_read()
        if (self.nose2_count == 0):
            return False

        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 读取超声避障数据并处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)
        # step 1 忽略里程
        start_time = time.time()
        while True:
            self.follow_two_step()
            end_time=time.time()
            if(end_time-start_time>1):
                self.mouth_ingore_flag = False
                break

        while True:
            self.follow_two_step()
            if(self.mouth_new_rfid_count>=1):
                print('safe_go_8 读到新卡=', self.mouth_this_rfid_id, ',8指令结束')
                break
        return

    def safe_go_4(self):
        self.mouth_ingore_flag = True

        # step 1 先开始转动
        self.feet.set_speed_pwm(-200, 200)
        # self.feet.set_speed_mps(-0.08,0.08)
        time.sleep(1)
        # # Step 2A 脱磁, 停车
        while True:
            # 读取rfid数据,转弯时更新rfid,但是忽略
            self.mouth_this_rfid_id = self.mouth1_read()
            self.rfid_after_read()

            (nose_index, self.nose1_count) = self.nose1_read()
            if (self.nose1_count == 0):
                break
        # Step 3: 继续开车
        print("已经脱离巡磁")
        while True:
            # 读取rfid数据,转弯时更新rfid,但是忽略
            self.mouth_this_rfid_id = self.mouth1_read()
            self.rfid_after_read()
            (nose_index, self.nose1_count) = self.nose1_read()
            if (nose_index > 3 and nose_index < 11):
                print("safe_go_4 已经进入巡磁正中")
                self.mouth_ingore_flag = False
                break
        # Step 4 停车
        self.feet.stop()
        return True

    def safe_go_6(self):
        self.mouth_ingore_flag = True

        # step 1 先开始转动
        self.feet.set_speed_pwm(200, -200)
        # self.feet.set_speed_mps(0.08,-0.08)
        time.sleep(1)
        # # Step 2A 脱磁, 停车
        while True:
            # 读取rfid数据,转弯时更新rfid,但是忽略
            self.mouth_this_rfid_id = self.mouth1_read()
            self.rfid_after_read()

            (nose_index,self.nose1_count) = self.nose1_read()
            if (self.nose1_count == 0):
                break
        # Step 3: 继续开车
        while True:
            # 读取rfid数据,转弯时更新rfid,但是忽略
            self.mouth_this_rfid_id = self.mouth1_read()
            self.rfid_after_read()

            (nose_index,self.nose1_count) = self.nose1_read()
            if (nose_index > 4 and nose_index < 10):
                print("safe_go_6 已经进入巡磁正中")
                self.mouth_ingore_flag = False
                break
        # Step 4 停车
        self.feet.set_speed_pwm(0, 0)
        # self.feet.set_speed_mps(0, 0)
        return True

    def safe_go_5(self):
        self.mouth_ingore_flag = True

        # step 1 判断脱磁条
        (nose_index, self.nose1_count) = self.nose1_read()
        if (self.nose1_count == 0):
            return False

        # 读取rfid数据并处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()

        # 读取超声避障数据并处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)

        # # step 1 忽略里程
        start_time = time.time()
        while True:
            self.follow_three_step()
            end_time=time.time()
            if(end_time-start_time>1):
                print('safe_go_5 忽略里程结束')
                self.mouth_ingore_flag = False
                break

        while True:
            self.follow_three_step()
            if(self.mouth_new_rfid_count>=1):
                break
        return True

    def safe_go_0(self):
        self.feet.stop()
        return True

    def safe_go_2(self):
        self.mouth_ingore_flag = True
        # 高速2指令开启避障功能
        self.ear_enable = True
        # # step 1 判断脱磁条

        (nose_index, self.nose1_count) = self.nose1_read()
        if (self.nose1_count == 0):
            # TODO 脱磁执行错误处理, 100系列:巡磁出错
            self.deal_error(self.ERROR_CODE_OUT_OF_MAGNET, '脱磁')
            # return False
        # 读取rfid数据并处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 读取超声避障数据并处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)

        # step 1 忽略里程
        start_time = time.time()
        while True:
            self.follow_one_step()
            end_time=time.time()
            if (end_time-start_time>1):
                print('safe_go_2 忽略里程结束')
                self.mouth_ingore_flag = False
                break
        while True:
            self.follow_one_step()
            if(self.mouth_new_rfid_count>=1):
                print('safe_go_2 读到新卡=', self.mouth_this_rfid_id, ',2指令结束')
                break
        # 2指令结束后,避障关掉
        self.ear_enable = False
        return True

    def follow_one_step(self):
        # time2 = time.time()
        # RFID读取和处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 避障读取和处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)  # 将数据写入到ear_this_radar_id

        (nose1_index, self.nose1_count) = self.nose1_read()
        self.set_states()
        if self.nose1_count == 0:
            # 脱磁停车
            nose_target_speed1 = 0
            nose_target_speed2 = 0
        else:
            # 根据巡磁,计算前后巡磁的姿态
            self.nose1_dx = self.NOSE_BIT_WIDTH * (nose1_index - 8.5)
            self.nose1_count=self.nose1_count
            self.r = 0
            if abs(self.nose1_dx) < 0.005:
                self.r = 0
            elif abs(self.nose1_dx) <= 0.02:
                # self.r = 0.03
                self.r = 0.02
            elif abs(self.nose1_dx) <= 0.04:
                # self.r = 0.05
                self.r = 0.25
            elif abs(self.nose1_dx) <= 0.05:
                # self.r = 0.1
                self.r = 0.4
            else:
                # self.r = 0.15
                self.r = 0.7
            print("follow_one_step dx=",self.nose1_dx, "self.r=", self.r)
            v = 0.3
            if self.ear_enable:
                if self.ear_slow_down:
                    print('避障减速, v = 0.2')
                    v = self.ear_slow_down_limit_speed
                if self.ear_stop:
                    print('避障停车, v = 0')
                    v = 0

            if self.nose1_dx == 0:
                nose_target_speed1 = v
                nose_target_speed2 = v
            elif self.nose1_dx > 0:
                nose_target_speed1 = v * (1 - self.r)
                nose_target_speed2 = v
            else:  # (self.nose1_dx < 0):
                nose_target_speed1 = v
                nose_target_speed2 = v * (1 - self.r)
        # time3 = time.time()
        self.sp_dict["index"] = nose1_index
        self.sp_dict["count"] = self.nose1_count
        self.sp_dict["dx"] = self.nose1_dx
        self.sp_dict["left"] = nose_target_speed1
        self.sp_dict["right"] = nose_target_speed2
        self.sp_dict["self.r"] = self.r
        # print("follow_one_step 左右轮速度:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        # time4 = time.time()
        # print("step时间差:", (time4 - time2) * 1000, "电机调用时间差：", (time4 - time3) * 1000)
        # self.sp_dict["timecha"] = (time4-time3)*1000
        self.sp_list.append(self.sp_dict)
        self.sp_dict = {}
        return True

    def follow_three_step(self):
        # time2 = time.time()
        # RFID读取和处理
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()
        # 避障读取和处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)  # 将数据写入到ear_this_radar_id

        (nose1_index, self.nose1_count) = self.nose1_read()
        self.set_states()
        if self.nose1_count == 0:
            # 脱磁停车
            nose_target_speed1 = 0
            nose_target_speed2 = 0
        else:
            # 根据巡磁,计算前后巡磁的姿态
            self.nose1_dx = self.NOSE_BIT_WIDTH * (nose1_index - 8.5)
            self.nose1_count = self.nose1_count
            self.r = 0
            if abs(self.nose1_dx) < 0.005:
                self.r = 0
            elif abs(self.nose1_dx) <= 0.02:
                # self.r = 0.03
                self.r = 0.015
            elif abs(self.nose1_dx) <= 0.04:
                # self.r = 0.05
                self.r = 0.2
            elif abs(self.nose1_dx) <= 0.05:
                # self.r = 0.1
                self.r = 0.3
            else:
                # self.r = 0.15
                self.r = 0.5
            print("follow_three_step dx=", self.nose1_dx, ",self.r=", self.r)
            v = 0.2
            if self.nose1_dx == 0:
                nose_target_speed1 = v
                nose_target_speed2 = v
            elif self.nose1_dx > 0:
                nose_target_speed1 = v * (1 - self.r)
                nose_target_speed2 = v
            else:  # (self.nose1_dx < 0):
                nose_target_speed1 = v
                nose_target_speed2 = v * (1 - self.r)
        # time3 = time.time()
        self.sp_dict["index"] = nose1_index
        self.sp_dict["count"] = self.nose1_count
        self.sp_dict["dx"] = self.nose1_dx
        self.sp_dict["left"] = nose_target_speed1
        self.sp_dict["right"] = nose_target_speed2
        self.sp_dict["self.r"] = self.r
        # print("follow_three_step 左右轮速度:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        # time4 = time.time()
        # print("step时间差:", (time4 - time2) * 1000, "电机调用时间差：", (time4 - time3) * 1000)
        # self.sp_dict["timecha"] = (time4-time3)*1000
        self.sp_list.append(self.sp_dict)
        self.sp_dict = {}
        return True

    def nose1_read(self):
        self.magnet1.read_all()
        # a = self.magnet1.get_int_value(self.magnet1.realtime_magnet)
        print('nose1_read 读取到的巡磁=', self.magnet1.channel_list[0]['dr'])
        a = self.magnet1.get_int_value(self.magnet1.channel_list[0]['dr'])
        b = self.magnet1.get_magnet_index_count(a)
        return b
        # 读取RFID卡号

    def mouth1_read(self):
        self.rfid1.read_all(self.rfid1_client)
        #34 42 62 96 71 03
        realtime_rfid = self.rfid1.channel_list[0]['dr']
        print('mouth1_read 读取到的rfid=', realtime_rfid)
        # 由于卡后两位可能变化,返回时再次截取rfid卡号,只保留前面4个16进制数据
        return realtime_rfid[0:11].strip()

    def rfid_after_read(self):
        if self.mouth_this_rfid_id != '' and self.mouth_this_rfid_id != self.mouth_last_rfid_id:
            if not self.mouth_ingore_flag:
                self.mouth_new_rfid_count += 1
                print("不处于忽略里程状态,读到新卡=", self.mouth_this_rfid_id, ",上一张卡=", self.mouth_last_rfid_id)
            print("读到新卡(新卡号替换老卡号),mouth_this_rfid_id=", self.mouth_this_rfid_id, ", mouth_last_rfid_id=", self.mouth_last_rfid_id)
            self.mouth_last_rfid_id = self.mouth_this_rfid_id
        print("rfid_after_read id=",self.mouth_this_rfid_id,", last_id=", self.mouth_last_rfid_id, ", mouth_new_rfid_count=", self.mouth_new_rfid_count)

        # 根据卡号判断是否在充电
        self.is_charging = self.check_is_charging()

    # 检测是否处于充电状态
    def check_is_charging(self):
        if self.mouth_this_rfid_id == '':
            return False
        else:
            for x in self.charging_rfid_list:
                if self.mouth_this_rfid_id == x:
                    return True
            return False
    def set_states(self):
        # tcp的状态参数
        if self.tcpcommander != None:
            self.tcpcommander.main_state = self.main_state
            self.tcpcommander.voltage = self.voltage_value
            self.tcpcommander.is_charging = self.is_charging
            self.tcpcommander.x = self.x
            self.tcpcommander.y = self.y
            self.tcpcommander.w = self.w
            self.tcpcommander.last_rfid=self.mouth_last_rfid_id
            self.tcpcommander.this_rfid=self.mouth_this_rfid_id
            self.tcpcommander.q_len = self.task_queue.qsize()
            self.tcpcommander.current_cmdStr = self.current_cmdStr
        else:
            logging.warn('tcpcommander=None,无法刷新其状态')

        # lora的状态参数
        if self.loracommander != None:
            self.loracommander.main_state = self.main_state
            self.loracommander.voltage = self.voltage_value
            self.loracommander.is_charging = self.is_charging
            self.loracommander.x = self.x
            self.loracommander.y = self.y
            self.loracommander.w = self.w
            self.loracommander.last_rfid=self.mouth_last_rfid_id
            self.loracommander.this_rfid=self.mouth_this_rfid_id
            self.loracommander.q_len = self.task_queue.qsize()
            self.loracommander.current_cmdStr = self.current_cmdStr
        else:
            logging.warn('loracommander=None,无法刷新其状态')
    def ear_read(self):
        result = self.radar.read_all(self.radar_client)
        print('ear_read 读到避障数据=', result)
        return result
    def radar_after_read(self, radar_data):
        # 处理读数, 返回实际距离值

        # 处理前先把原来的数据清空
        self.ear_this_radar_id.clear()
        # radar_data格式:'F5 80 80 80 80 80 80 08 7F 87',中间8个值是避障数据
        if radar_data != '':
            radar_values = radar_data[3:26].strip().split(' ')
            for x in radar_values:
                # print(x, ', len(x)=', len(x), ', 10进制值=', int(x, 16))
                y = int(x, 16)
                # y值说明:实际距离为读数* 5, 距离为30cm-250cm间, 单位:cm (0x01:盲区0-30cm内  0x7F:250cm内无障碍物  0x80:无探头)
                # ear_this_radar_id中保存读数*5的数值, 635表示250cm内无障碍物, 640表示未接探头
                self.ear_this_radar_id.append(y * 5)

            # 将最新避障数据记录到避障最近10次的历史记录中,长度到达10则先移除掉最初的一个,保持最新的10次读数
            if len(self.ear_history_radar_id) >= 10:
                self.ear_history_radar_id.pop(0)
            self.ear_history_radar_id.append(self.ear_this_radar_id)

            # 在已经避障情况下, 检测连续10次避障是否都超过避障停车距离
            if self.ear_stop:
                self.ear_stop = False
                for x in self.ear_history_radar_id:
                    for y in x:
                        if y <= 30:
                            self.ear_stop = True
                            break
            else:
                # 原本未处于避障停车状态
                if self.ear_this_radar_id[0] <= 30 or self.ear_this_radar_id[1] <= 30 or self.ear_this_radar_id[2] <= 30 or self.ear_this_radar_id[3] <= 30 or \
                    self.ear_this_radar_id[4] <= 30 or self.ear_this_radar_id[5] <= 30 or self.ear_this_radar_id[6] <= 30 or self.ear_this_radar_id[7] <= 30:
                    self.ear_stop = True
                else:
                    self.ear_slow_down = False
                    for i in self.ear_this_radar_id:
                        if i > 30 and i <= 50:
                            self.ear_slow_down = True
                            break
        else:
            # 当前未读取到避障数据,避障不停车,不减速
            self.ear_stop = False
            self.ear_slow_down = False

    def follow_two_step(self):
        self.mouth_this_rfid_id = self.mouth1_read()
        self.rfid_after_read()

        # 避障读取和处理
        if self.ear_enable:
            radar_data = self.ear_read()
            self.radar_after_read(radar_data)  # 将数据写入到ear_this_radar_id
        (nose2_index, self.nose2_count) = self.nose2_read()
        self.set_states()

        if self.nose2_count == 0:
            # 脱磁停车
            nose_target_speed1 = 0
            nose_target_speed2 = 0
        else:
            # 根据巡磁,计算前后巡磁的姿态
            self.nose2_dx = self.NOSE_BIT_WIDTH * (nose2_index - 8.5)
            self.nose2_count=self.nose2_count
            self.r = 0
            if abs(self.nose2_dx) < 0.005:
                self.r = 0
            elif abs(self.nose2_dx) <= 0.02:
                self.r = 0.015
            elif abs(self.nose2_dx) <= 0.04:
               self.r = 0.06
            elif abs(self.nose2_dx) <= 0.05:
                self.r = 0.13
            else:
                self.r = 0.2
            print("follow_two_step dx=", self.nose2_dx, ", self.r=", self.r)
            v = -0.2
            if self.nose2_dx == 0:
                nose_target_speed1 = v
                nose_target_speed2 = v
            elif self.nose2_dx > 0:
                # nose_target_speed1 = v * (1 - self.r)
                nose_target_speed1 = v
                nose_target_speed2 = v * (1 - self.r)
                # nose_target_speed2 = v
            else:  # (self.nose1_dx < 0):
                # nose_target_speed1 = v
                nose_target_speed1 = v * (1 - self.r)
                nose_target_speed2 = v
                # nose_target_speed2 = v * (1 - self.r)
        # print("follow_two_step 左右轮速度:", nose_target_speed1, nose_target_speed2)
        self.feet.set_speed_mps(nose_target_speed1, nose_target_speed2)
        return True

    def nose2_read(self):
        self.magnet1.read_all()
        # a = self.magnet1.get_int_value(self.magnet1.realtime_magnet)
        print('nose2_read 读取到的巡磁=', self.magnet1.channel_list[1]['dr'])
        a = self.magnet1.get_int_value(self.magnet1.channel_list[1]['dr'])
        b = self.magnet1.get_magnet_index_count(a)
        return b

    # 003.巡磁出错判断算法
    def sim_run(self, cmd, x, y, w):
        print('sim_run(), cmd=',cmd,', x=',x,', y=',y,', w=',w)
        if cmd == '2' or cmd == '5':
            # 以射频门朝向起始点位置作为w=0的方向
            if w == 0:
                return x + 1, y, w
            elif w == 90:
                return x, y + 1, w
            elif w == 180:
                return x - 1, y, w
            elif w == 270:
                return x, y - 1, w
            else:
                return x, y, w
        elif cmd == '4':
            # 转弯调整车子角度
            if w == 270:
                return x, y, 0
            else:
                return x, y, w + 90
        elif cmd == '6':
            # 转弯调整车子角度
            if w == 0:
                return x, y, 270
            else:
                return x, y, w - 90
        elif cmd == '8':
            if w == 0:
                return x - 1, y, w
            elif w == 90:
                return x, y - 1, w
            elif w == 180:
                return x + 1, y, w
            elif w == 270:
                return x, y + 1, w
            else:
                return x, y ,w
        elif cmd == '22' or cmd == '55':
            if w == 0:
                return x + 2, y, w
            elif w == 90:
                return x, y + 2, w
            elif w == 180:
                return x - 2, y, w
            elif w == 270:
                return x, y - 2, w
            else:
                return x, y, w
        elif cmd == '88':
            if w == 0:
                return x - 2, y, w
            elif w == 90:
                return x, y - 2, w
            elif w == 180:
                return x + 2, y, w
            elif w == 270:
                return x, y + 2, w
            else:
                return x, y ,w
        elif cmd == '222' or cmd == '555':
            if w == 0:
                return x + 3, y, w
            elif w == 90:
                return x, y + 3, w
            elif w == 180:
                return x - 3, y, w
            elif w == 270:
                return x, y - 3, w
            else:
                return x, y, w
        elif cmd == '888':
            if w == 0:
                return x - 3, y, w
            elif w == 90:
                return x, y - 3, w
            elif w == 180:
                return x + 3, y, w
            elif w == 270:
                return x, y + 3, w
            else:
                return x, y ,w
        else:
            print('指令:', cmd, ', 不执行指令后操作')
            return x, y ,w

    def check_read_sim_rfid(self, read_x, read_y, sim_x, sim_y, sim_w):
        if read_x == sim_x and read_y == sim_y:
            return True
        else:
            return False

    # 根据rfid卡查询其坐标
    def read_rfid(self):
        # 确定要比对的rfid卡是当前rfid卡还是上一次读到的卡
        if self.check_this_rfid:
            check_rfid = self.mouth_this_rfid_id
        else:
            check_rfid = self.mouth_last_rfid_id
        logging.info('[read_rfid] 读到的卡=' + self.mouth_this_rfid_id + ',上一次读到的卡=' + self.mouth_last_rfid_id +
                     ', check_this_rfid=' + self.check_this_rfid.__str__() + ', 要对比的卡号check_rfid=' + check_rfid)
        if check_rfid == '':
            # 没有读到过卡,无法通过比对来进行纠偏
            return -1, -1
        else:
            for x in self.rfid_list:
                if x['rfid1'] == check_rfid or x['rfid2'] == check_rfid or x['rfid3'] == check_rfid:
                    return x['x'], x['y']
            logging.info('[read_rfid] 所有rfid卡都不匹配,返回(-1,-1)')
            return -1, -1

    # 004.巡磁出错更正算法,得到返回指令
    def get_go_str(self, read_x, read_y, sim_x, sim_y, sim_w, cmd):
        print('即将生成倒退指令方法get_go_str(), 当前读到的位置=(',read_x,',',read_y,'), 预期位置=(',sim_x,',',sim_y,',',sim_w,')')
        gostr = ''
        # 通过有限次数(三步)内能模拟走到读取到的RFID卡位置,来确定后退的指令
        # 为找到rfid卡,使用满速行驶指令5/8,不使用2,减少再次漏卡的几率
        test_cmds = ['5', '8', '55', '88', '555', '888']
        for x in range(len(test_cmds)):
            # 在计算的预期点位基础上再次推算看哪一个指令可以走到当前错误的点位上
            (go_x, go_y , go_w) = self.sim_run(cmd, sim_x, sim_y, sim_w)
            if go_x == read_x and go_y == read_y:
                print('x=', x, ', 对应指令:', test_cmds[x], ' 可以从预期位置到达当前位置')
                gostr = self.get_goback_str(test_cmds[x])
                break
        return gostr

    # 求能从漏卡点倒退到预期点的指令
    def get_goback_str(self,cmd):
        if cmd == '5':
            return '8'
        elif cmd == '8':
            return '5'
        elif cmd == '55':
            return '88'
        elif cmd == '88':
            return '55'
        elif cmd == '555':
            return '888'
        elif cmd == '888':
            return '555'

    def read_rfidjson(self):
        print('开始读取rfid配置')
        res = open("data/Rfid.json",encoding='utf-8').read()
        self.rfid_list = json.loads(res)  # list[dict1, dict2]
        return

    def up(self):
        print('顶升升起，等待7秒')
        self.feet.lift_up()

    def down(self):
        print('顶升下降，等待7秒')
        self.feet.lift_down()

#类的单元测试函数
def test():
    robot1 = Robot()
    robot1.start()  # runnint task t1
    return

if __name__ == "__main__":
    # test()

    feet = PwmMotor2()
    feet.config("/dev/ttyUSB1", 0x25, 38400)
    feet.connect()
    feet.lift_down()

