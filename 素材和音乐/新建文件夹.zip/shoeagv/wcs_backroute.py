
class BackRoute():
    def backroute1(self,route):
        str = route[::-1]
        strlist = list(str)
        # print(strlist)
        num = 0
        for i in strlist:
            print(type(i))
            if(i == "4"):
                strlist[num] = "6"
            elif(i == "6"):
                strlist[num] = "4"
            else:
                pass
            num = num + 1
        finalstr = "".join(strlist)
        backstr =  finalstr
        return backstr

    def backroute2(self,route):
        if(route.endswith("220")):
            str = route[0:route.__len__()-3]
            str1 = self.backroute1(str)
            str2 = "8442" + str1
            return str2
        elif(route.endswith("420")):
            str = route[0:route.__len__() - 3]
            str1 = self.backroute1(str)
            str2 = "84" + str1
            return str2
        elif(route.endswith("620")):
            str = route[0:route.__len__() - 3]
            str1 = self.backroute1(str)
            str2 = "86" + str1
            return str2
        elif(route.endswith("40")):
            str = route[0:route.__len__() - 3]
            str1 = self.backroute1(str)
            str2 = "4" + str1
            return str2
        elif(route.endswith("60")):
            str = route[0:route.__len__() - 3]
            str1 = self.backroute1(str)
            str2 = "6" + str1
            return str2
        elif(route.endswith("680")):
            str = route[0:route.__len__() - 3]
            str1 = self.backroute1(str)
            str2 = "26" + str1
            return str2
        elif(route.endswith("480")):
            str = route[0:route.__len__() - 3]
            str1 = self.backroute1(str)
            str2 = "24" + str1
            return str2
        else:
            pass

        return

if __name__ == '__main__':
    back = BackRoute().backroute2("22426220")
    print(back)