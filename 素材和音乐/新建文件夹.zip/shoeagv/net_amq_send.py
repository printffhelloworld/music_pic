import json
import stomp
import time


class Sendtopic(object):
    __topic_name2 = '/topic/ResultDevice-AGV'
    def __init__(self):
        return
    def init(self):
        try:
            self.__listener_name = 'SampleListener'
            self.__topic_name1 = '/topic/ResultTask'
            self.__host = '192.168.0.210'
            self.__port = 61613  # 61616
            self.__user ="Opoudmes"  # "admin"
            self.__password = "mes@2019"  # "admin"
            self.conn = stomp.Connection10([(self.__host, self.__port)],auto_content_length=False)
            self.conn.connect()
        except Exception as e:
            print(e)
    def sendto(self,data):
        data1 = json.dumps(data)
        self.conn.send(self.__topic_name1, data1)

    def sendstate(self):
        sendstate = {
             "Channel": "ResultDevice-AGV",
              "Client": "AGV",
              "AGVCode": "Dev-AGV03",
              "Status": "",
              "Model": "",
              "Battery": "",
              "Load": "",
              "TaskSN": "",
              "TaskCode": "",
              "CurrentPosition": ""
        }
        data1 = json.dumps(sendstate)
        while True:
            self.conn.send(self.__topic_name2, data1)
            time.sleep(5)
        return True
    # def __del__(self):
    #     self.conn.disconnect()

if __name__ == "__main__":
    aa = Sendtopic()
    aa.init()
    for i in range(5):
        aa.sendto('nihao a ')
        time.sleep(2)
    del aa
