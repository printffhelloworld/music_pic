#!/res/Pycharm/iot/iot_motor.py
# pip install pymodbus
# 双轮同步升速、保持高速、同步降速停车，当占空比很小时(电机转不动)需要把使能关掉
import time
from iot_modbus import SafeModbusClient
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
class PwmMotor():

    def __init__(self):
        return
    # 1.2 关键配置
    type="motor_pwm"
    BAUD_RATE = 38400
    usb_port = '/dev/ttyUSB1'
    slave_num = 0x26
    TIME_OUT = 0.05
    client = None
    safe_modbus = None


    ch_en=1
    ch_fr=2
    ch_pwm=6
    last_pwm=0

    def init(self):
        self.safe_modbus = SafeModbusClient()
        return

    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port = usb
        self.slave_num = slave_num
        return True

    def connect(self):
        if(self.client == None):
            self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',
                                   baudrate=self.BAUD_RATE, timeout=self.TIME_OUT)
        isconnected = self.client.connect()
        print("连接结果=", isconnected)
        return True


    MAX_PWM = 1000
    MAX_MOTOR_SPEED_RPM = 3000  # rpm

    def set_direction(self,ch_en,ch_fr,direction,slave_num):
        if (direction == 0 ):
            if(abs(int(self.last_pwm)) == 0):
                pass
                return True
            else:
                rr1 = self.client.write_register(ch_fr, 0, unit=slave_num)  # .encode()
                rr2 = self.client.write_register(ch_en, 0, unit=slave_num)  # .encode()
                self.last_left_pwm=0
                return True
        elif (direction < 0):
            if (self.last_pwm< 0):
                pass
                return True
            else:
                for i in range (1,4):
                    rr3 = self.safe_modbus.safe_write_holding_register(ch_en, 1, slave_num)  # .encode()
                    if(rr3):
                        break
                for i in range (1,4):
                    rr4 = self.safe_modbus.safe_write_holding_register(ch_fr, 0 , slave_num)  # .encode()
                    if(rr4):
                        break
                return True
        else:
            if(self.last_pwm>0):
                pass
                return True
            else:
                rr = self.client.write_register(self.ch_en,0, unit=self.slave_num)  # .encode()
                rr5 = self.client.write_register(self.ch_fr,1, unit=self.slave_num)  # .encode()
                return True

    def set_abs_pwm(self,ch_pwm,abs_pwm,slave_num):
        return self.safe_modbus.safe_write_holding_register(ch_pwm ,abs(int(abs_pwm)),slave_num )


    def dispose(self):
        self.client.close()
        return

def test():
    motor=PwmMotor()
    motor.config("COM3", 0x26, 38400)
    motor.connect()


if __name__ == '__main__':
    # 测试电机加速、保持满速、降速、停车过程
    test()