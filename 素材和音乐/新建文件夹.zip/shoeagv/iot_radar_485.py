# -*- coding:utf-8 -*-
# !/res/Pycharm/shoeagv/iot_radar.py
# 超声避障,传感器每100ms发送一次
# 格式：0xF5 LA LB LC LD RA RB RC RD CHKADD, 中间8个值是避障读数, CHKADD为LA～RD 8个数值加和保留后8bit
import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient

class Radar:
    def __init__(self):
        return

    # 1.2 关键配置
    BAUD_RATE = 115200
    usb_port = '/dev/ttyUSB3'
    slave_num = 1
    TIME_OUT = 0.1
    client = None
    # 1.2 带配置的构造函数
    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port = usb
        self.slave_num = slave_num
        return True

    def connect(self):
        self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',
                                   baudrate=self.BAUD_RATE, timeout=self.TIME_OUT)
        isconnectre = self.client.connect()
        print("超声连接结果=", isconnectre)
        return True

    radar_data = ''

    # 读取避障
    def read_radar(self):
        result_temp=None
        try:
            result_temp = self.client.read_holding_registers(1, 8, unit=9).encode()
        except:
            print("超声异常")
        print('result_temp=', result_temp)
        result = ''
        if result_temp:
            for x in result_temp:
                if x == 0:
                    continue
                y = '{:02x}'.format(x)  # 10进制转16进制,不足2位则高位补0
                result += (y + ' ')
            return result.strip()
        else:
            print('未读取到超声避障数据')
        return result

    def radar_after_read(self,radar_data):
        # 处理读数, 返回实际距离值
        ear_this_radar_id = []
        if radar_data != '':
            radar_values = radar_data[3:30].strip().split(' ')
            for x in radar_values:
                try:
                    y = int(x, 16)
                    ear_this_radar_id.append(y)
                except:
                    print("超声数据异常")
            print('超声避障数值=', ear_this_radar_id)

def test():
    radar1 = Radar()
    radar1.config('/dev/ttyUSB3', 9)
    radar1.connect()
    while True:
        data=radar1.read_radar()
        radar1.radar_after_read(data)
        #time.sleep(1)

if __name__ == "__main__":
    test()
