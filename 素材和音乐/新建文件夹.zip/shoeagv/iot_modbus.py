import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient



class SafeModbusClient():
    def __init__(self):
        return

    client=None
    BAUD_RATE = 38400

    def init(self):
        return
    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port = usb
        self.slave_num = slave_num
        return True

    def connect(self):
        if (self.client == None):
            self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',
                                       baudrate=self.BAUD_RATE, timeout=0.01)
        isconnected = self.client.connect()
        print("连接结果=", isconnected)
        return True

    def safe_write_holding_register(self, ch,val,slave_num):

        try:
            print(ch, "开始写入:", val,"time:",time.time())
            rr = self.client.write_register(ch, val, unit=slave_num).encode()
            print(ch, "写入结束:", val,"time；",time.time())
            rr2 = rr[rr.__len__() - 2:rr.__len__()]
            writepwm2 = int.from_bytes(rr2, "big")
            if (abs(int(writepwm2)) == writepwm2):
                return True
            else:
                return False
        except Exception as ex:
            print(ex)
            time.sleep(0.02)
            return False