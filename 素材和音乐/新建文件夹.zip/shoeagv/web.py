from flask import Flask, url_for, render_template, redirect, jsonify
from flask import request
from socket import socket,AF_INET,SOCK_STREAM
import queue
from slenderagv.robot_inside import RobotInside
web_tcp = Flask(__name__)
# 服务端的ip地址
#tcp_server_ip = '192.168.100.111'
tcp_server_ip = '192.168.43.15'

# 服务端socket绑定的端口号
tcp_server_port = 5000
robot1=None

@web_tcp.route('/')
def debug():
    #启动页面
    return render_template("debug.html")

def init_tcp():
    return

@web_tcp.route('/send', methods=['POST'])
def send():
    global robot1
    post_data = request.get_json(silent=True)
    print(post_data)
    str1 = post_data['str']
    print(str1)
    sendStr = str(str1).encode("utf-8")
    print(sendStr)
    robot1.task_queue.put(sendStr, block=True, timeout=None)
    # client = socket(AF_INET, SOCK_STREAM)
    # client.connect((server_ip, server_port))
    # client.send(sendStr)
    # client.close()
    data_wrapper = {'result_code': 0}
    return jsonify(data_wrapper)

#入库1
@web_tcp.route("/in1", methods=['POST'])
def in1():
    # 获取到post的json数据
    print("进入入库1")
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraIn = "720"
    print(paraIn)
    #tcp发送数据
    sendStr = paraIn.encode()
    global client
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((tcp_server_ip, tcp_server_port))
    client.send(sendStr)
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#入库2
@web_tcp.route("/in2", methods=['POST'])
def in2():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraIn = "0-" + post_data['paraIn']
    print(paraIn)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((tcp_server_ip, tcp_server_port))
    client.send(paraIn.encode())
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#出库1
@web_tcp.route("/out1", methods=['POST'])
def out1():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = post_data['paraOut']+"-0"
    print(paraOut)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((tcp_server_ip, tcp_server_port))
    client.send(paraOut.encode())
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#出库2
@web_tcp.route("/out2", methods=['POST'])
def out2():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = "24490"
    print(paraOut)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((tcp_server_ip, tcp_server_port))
    client.send(paraOut.encode())
    client.close()

    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#移库
@web_tcp.route("/move", methods=['POST'])
def move():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraMove = post_data['paraMove']
    print(paraMove)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((tcp_server_ip, tcp_server_port))
    client.send(paraMove.encode())
    client.close()
    #返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#获取状态
@web_tcp.route("/get_state", methods=['POST'])
def get_state():
    # # 获取到post的json数据
    # print(request.get_data(as_text=True))
    # post_data = request.get_json(silent=True)
    # paraMove = post_data['paraMove']
    # print(paraMove)
    # tcp发送数据
    # client = socket(AF_INET, SOCK_STREAM)
    # client.connect((server_ip, server_port))
    # str = "get_state"
    # client.send(str.encode())
    # print(str(client.recv(8192), encoding="utf-8"))
    # client.close()
    ri = RobotInside()
    a ="".join(ri.device_list)
    print(a)
    # #返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success","states": a}
    return jsonify(data_wrapper)
    # return

class runweb():
    def start(self,robot):
        global robot1
        robot1=robot
        web_tcp.run(
            host='192.168.43.58',
            port=5000
        )


if __name__ == '__main__':
    # init_tcp()
    # run = runweb()
    # run.start()
    rw = runweb()
    rw.start()
