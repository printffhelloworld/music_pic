from socketserver import BaseRequestHandler, TCPServer
import _thread
from threading import Thread
import socket
import queue
from socketserver import BaseRequestHandler, TCPServer

class TcpCommander():
    serversocket = None
    target_clients = ("192.168.43.15",20001,)
    #target_clients = ("192.168.100.111",20001,)
    # ser = None
    # target_clients = ["127.0.0.1"]
    q = queue.Queue(maxsize=10)
    def __init__(self):
        super(TcpCommander, self).__init__()
        return

    def connect(self,b):
        self.serversocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.serversocket.bind(self.target_clients)
        self.serversocket.listen(5)
        self.start_listen()
        # serv = TCPServer(('', 20000), TcpCommander.start_listen())
        return

    def start_listen(self):
        print('The server is ready to receive')
        try:
            _thread.start_new_thread(self.listen,(1,))
        except:
            print("开启线程失败")

        return

    def send(self,msg):
        # self.serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # self.serversocket.bind(self.target_clients)
        # self.serversocket.send(msg.encode("utf-8"))
        return

    def listen(self,a):
        while 1:
            connectionSocket, addr = self.serversocket.accept()
            sentence = connectionSocket.recv(1024*4)


            if sentence != b'':
                recvstr = sentence.decode("utf-8")
                self.q.put(recvstr, block=True, timeout=None)
                print("消息队列长度：", self.q.qsize())
                print("receive : ", recvstr)

        return


if __name__ == '__main__':
    tcp = TcpCommander()
    tcp.connect(2)
    while True:
        pass