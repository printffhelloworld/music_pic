# -*- coding:utf-8 -*-
# !/res/moobot/slenderagv/robot_inside.py
# author: 杨志成
# email:yangzc2009cc@163.com
# 接收robot_main中设定的target参数并开始执行
# MOC运动控制算法.
# 只分配1个线程，业务逻辑要分开 小脑
# 时间单线程，按零部件(16个函数)
import logging
import threading
import time

import iot_rfid_rc522


#from slenderagv.moc import MotionController


class RobotInside(threading.Thread):

    device_list=["Pi","","iot_magnet_ms16a", "iot_radar", "iot_rfid_rc522"]
    channel_list=[]

    moc = None
    current_cmd_state = 'idle'



    TIME_STEP=0.05 # 每50ms一次读写翻转

    nose = None
    ear = None
    mouth = None
    ser_rfid = None
    feet = None
    client1 = None
    client2 = None

    pwm_value = 100  # TODO 默认速度, 速度如何配置, 如何设置target_speed, 转换成pwm

    def __init__(self):
        super(RobotInside, self).__init__()
        print('robot_inside,线程名', threading.currentThread().name)
#        self.moc = MotionController()
        return

    def run(self):
        print('robot_inside run(),当前线程名=', threading.currentThread().name)
        self.main()

    def before_init(self):
        return

    def init(self):
        print('robot_inside init(),线程名=', threading.currentThread().name)
        global nose, ear, mouth, ser_rfid, feet, client1, client2
        # 前后巡磁
        # nose1 = Magnet("COM5", 9600)
        # nose1.init()
        # nose2 = Magnet("COM6", 9600)
        # nose2.init()
        # self.nose = (nose1, nose2)

        # 避障
        # ear = Radar("/dev/ttyUSB0", 2)
        # ear.init()

        # RFID
        #self.mouth = Rfid("COM6", 9600)
        #self.ser_rfid = self.mouth.init()

        # 左右电机
#         feet1 = Motor('COM6', 9600)
#         self.cleint1 = feet1.init()
 #        feet2 = Motor('COM7', 9600)
 #        self.cleint2 = feet2.init()
  #       self.feet = (feet1, feet2)
        return

    def after_init(self):
        return

    def before_read(self):
        return



    # 需要读的通道, 在read_all中读出
    mouth_ser_rfid="12-23-21"

    nose1_dr="0000000000000000"
    nose2_dr="0000000000000000"

    # 需要写的通道, 在write_all中写入

    # 需要计算的数值, 在after_read中计算
    nose1_index=0
    nose2_index = 0
    # 当前速度
    current_vy = 0
    # 当前r值
    current_r = 0

    # 上位给定的数值,

    # 左轮目标速度(moc.py中会处理活的target_vy,target_r)
    feet1_target_speed = 0
    # 右轮目标速度
    feet2_target_speed = 0
    # 速度目标值
    target_vy = 0
    # r = 两轮速度差/max(abs(左轮速度),abs(右轮速度))
    target_r = 0

    def read_all(self):
        # 1) 读取rfid

        iot.read_all(self.ser_rfid)

        mouth_realtime_rfid = mouth.get_realtime_rfid()  # 返回dr
        print('robot_inside 读取到rfid-->', mouth_realtime_rfid, ',当前线程名=', threading.currentThread().name)


        # 2) 读取巡磁
        global nose1
        nose1_dr = nose[0].get_realtime_magnet()
        nose2_dr = nose[1].get_realtime_magnet()
        print('读取到巡磁-->', nose1_dr[0], nose2_dr[0])

        # 3) 读取超声避障
        # ear_realtime_radar = ear.get_raltime_radar()
        # print('读取到避障-->', ear_realtime_radar)

        # 4) 读取车头包围值

        # 5) 读取电压数值

        # 6) 读取上次的写入数据


        return

    def after_read(self):
        # 对读取的数值做处理

        # TODO: 杨志成: 根据2张rfid卡读取情况,确定最终rfid卡号

        #根据rfid卡号, 计算new_rfid_count

        # 根据巡磁,计算前后巡磁的姿态

        nose1_index=8.5
        nose2_index=8.5






        return

    def nose_calculate_index(self,dr):
        return 8.5

    def nose_calculate_dx(self, index):
        CENTER_INDEX=8.5
        GRID_WIDTH=0.01
        return (index-8.5)*0.01

    def before_logic(self):
        return

    def main_logic(self):
        speeds = self.moc_logic()
        # todo 下发两轮速度

        target


        return
    def moc_logic():

        return


    def after_logic(self):
        return
    def before_write(self):
        return
    def write_all(self):
        return
    def after_write(self):
        return


    def before_sleep(self):
        return

    def step(self):
        print('进入step方法,线程名=', threading.currentThread().name)
        step_start_time = time.time()

        self.before_read()
        read_start_time = time.time()
        # 身体部件开始获取传感器数据
        self.read_all()
        read_end_time = time.time()
        self.after_read()

        self.before_logic()
        self.main_logic()
        self.after_logic()

        self.before_write()
        write_start_time = time.time()
        self.write_all()
        write_end_time = time.time()
        self.after_write()

        self.before_sleep()
        step_end_time = time.time()
        time_to_sleep = self.TIME_STEP + step_start_time - step_end_time
        #self.sleep_to_align_time(TIME_STEP/5)
        #print(step_start_time , "-" , step_end_time, "-",  time_to_sleep)
        if(time_to_sleep>=0):
            time.sleep(time_to_sleep)
        else:
            logging.error("Robot Inside 没能在约定时间内完成一个循环")
        return

    def loop(self):
        #self.sleep_to_align_time(TIME_STEP)
        while True:
            try:
                # 循环执行步骤
                self.step()
                # time.sleep(2)
            except Exception:
                # 出现异常
                ok = self.deal_with_Exception()
                if (not ok):
                    self.before_error_exit()
                    exit(1)
                else:
                    continue

    def deal_with_Exception(self):

        return True

    def before_error_exit(self):
        print('robot_inside before_error_exit')
        return

    def dispose(self):
        return

    b='''
    以下为垃圾代码 2019-06-20, 五天后可删
    
    CH_MOTOR1_SPEED=16
    CH_MOTOR2_SPEED = 16


    #Part 2: MOC 的插补算法

    target_speed=3

    #相对vy
    def feet_move_v(self, vy, vw):

    def motor_move_v(self):

        MAX_VL = 0.3  # m/s
        MAX_VR = 0.3  # m/s
        MAX_VY = 0.3  # m/s
        MAX_VW = 0.1  # rad/s

        def mov_reverse(vy, vw):
            vl = (vy + vw) / 2
            vr = (vy - vw) / 2
            return (vl, vr)

        def interpolate([read_v1, read_v2]

            , [target_v1, target_v2], [limit_v1_acc, limit_v2_acc]):

        # TODO: Robin
        return self.move(v1, v2)

    def move_v(vy, vw):
        # vy = -1.00, +1.00
        # vw = -1, +1

        (target_v1, target_v2) = moc_reverse(vy, vw)
        ref_v1, ref_v2 )= interpolate([read_v1, read_v2], [target_v1, target_v2], [limit_v1_acc, limit_v2_acc])

        motor1.move_v(vl)
        motor2.move_v(v2)
        return

    def move_vt(vy, vw, t):
        return

    def move_s(sy, vy, vw):
        return

    def along_v(vy):
        return

    def along_vt(vy, t):
        return

    def along_s(sy):
        return

    def along_sv(sy, sv):
        return

    def reach_forward():
        return reach_v(+1.0)

    def reach_backward():
        return reach_v(-1.0)

    def reach_v(vy):
        return

    def run_task(str):
        if (str == "2"):
            run_task_2();
        # TODO
        return

    def run_task_2():
        return reach_forward()

    def run_task_8():
        return reach_backward()
    '''

    def main(self):
        print('进入robot_inside main()方法,线程名=', threading.currentThread().name)
        self.before_init()
        # 身体部件初始化连接，开始
        self.init()
        self.after_init()
        # 进入步骤死循环
        self.loop()

        # while True:
        #     try:
        #         self.loop()  # 大的死循环
        #     except Exception:
        #         # 出现异常
        #         ok = self.deal_with_Exception()
        #         if (not ok):
        #             self.before_error_exit()
        #             exit(1)
        #         else:
        #             continue

        # self.dispose()
        exit(0)

    def run_cmd_0(self):
        self.stop()

    def run_cmd_2(self):
        self.forward()

    def run_cmd_4(self):
        return True

    def run_cmd_5(self):
        return True

    def run_cmd_6(self):
        return True

    def run_cmd_7(self):
        return True

    def run_cmd_8(self):
        return True

    def run_cmd_9(self):
        return True

    def forward(self):
        # 传参顺序: client, en_addr, en_value, dir_addr, dir_value, pwm_addr, pwm_value
        self.feet[0].write_wheel_cmd(self.client1, 1, 1, 2, 0, 6, self.pwm_value)
        self.feet[1].write_wheel_cmd(self.client2, 3, 1, 4, 1, 7, self.pwm_value)



        return True


if __name__ == "__main__":
    RobotInside().main()

    r = RobotInside()
    r.start()
    r.join()
    print('main中打印', threading.currentThread().name, threading.current_thread().name)

