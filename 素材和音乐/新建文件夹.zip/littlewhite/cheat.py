from littlewhite.mp3_player import Mp3Player
from littlewhite.vts_recognize import VtsRecognize
from littlewhite.stt_writer import SttWriter
from littlewhite.sts_cheat_robot import CheatRobot
from littlewhite.ttv_recognize import TtvRecognize
class Cheat():
    mp3Player = None
    vtsRecognize = None
    sttWriter = None
    cheatRobot = None
    ttvRecognize = None

    def __init__(self):
        return

    def init(self):
        self.mp3Player = Mp3Player()
        self.vtsRecognize = VtsRecognize()
        self.vtsRecognize.connect()
        self.sttWriter = SttWriter()
        self.cheatRobot = CheatRobot()
        self.ttvRecognize = TtvRecognize()
        self.ttvRecognize.connect()

    def mainlogic(self):
        my_voice_string=self.vtsRecognize.get_text()
        if my_voice_string=="":
            #未获取到语音信息
            print("你说什么?我没听到声音呀。")

        else:
            #获取到语音信息
            print("我:",my_voice_string)
            answer_string=self.cheatRobot.get_answer(my_voice_string)
            self.sttWriter.write(answer_string)
            self.ttvRecognize.get_voice()
            self.mp3Player.playmp3()

def test():
    cheat = Cheat()
    cheat.init()
    while True:
        cheat.mainlogic()

if __name__ == '__main__':
    test()