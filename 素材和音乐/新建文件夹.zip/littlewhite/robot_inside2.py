# -*- coding:utf-8 -*-
# !/res/moobot/slenderagv/robot_inside.py
# author: 杨志成
# email:yangzc2009cc@163.com
# 接收robot_main中设定的target参数并开始执行
# MOC运动控制算法.
# 只分配1个线程，业务逻辑要分开 小脑
# 时间单线程，按零部件(16个函数)

import logging
import threading
import time
# pip install pymodbus
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
import iot.iot_motor3 as motor
import iot.iot_magnet_ms16a_1 as magnet_ms16a
import iot.iot_rfid_rc522
from iot import iot_magnet_preprocess
from iot.iot_magnet_ms16a import Magnet
from iot.iot_rfid_rc522 import Rfid


class RobotInside(threading.Thread):
    # Part 1 构造函数
    def __init__(self):
        super(RobotInside, self).__init__()
        return

    # Part 2 参数
    # 2.0 主参数
    TIME_STEP = 0.1  # 每100ms一次读写翻转
    current_cmd_state = 'idle'
    error_queue = []

    # 元数据, 仅用于快速访问用
    device_list = ["Pi", "", "iot_magnet_ms16a", "iot_radar", "iot_rfid_rc522"]  # 设备列表
    channel_list = []  # 频道列表

    # 2.1 车辆速度
    car_target_vy = 0  # m/s
    car_target_vw_dps = 0  # deg/s
    car_target_sy = 0

    # 车子长宽高尺寸
    CAR_SIZE = [1.0,0.8,0.6]

    # 当前值
    car_vy = 0
    car_vw_dps = 0
    car_sy = 0
    # car_r=0

    # 车速
    HIGH_SPEED = 0.75  # 正常行车速度
    NORMAL_SPEED = 0.5  # 正常行车速度
    SLOW_SPEED = 0.25  # 低速
    VERY_SLOW_SPEED = 0.05  # 超低速

    HIGH_ROTATE_SPEED_IN_DPS = 30
    NORMAL_ROTATE_SPEED_IN_DPS = 15
    SLOW_ROTATE_SPEED_IN_DPS = 5  # 低速
    VERY_SLOW_ROTATE_SPEED_IN_DPS = 1  # 超低速

    # Part2.2 通讯部分
    usb_port = "COM2"  # USB端口
    BAUD_RATE = 38400  # 波特率
    TIME_OUT = 0.005  # 超时时间
    modbus_count=1
    modbus_error_count=0
    modbus_continue_error_count=0
    modbus_error_rate = modbus_error_count/modbus_count
    magnet = None
    feet_motor=None

    rfid_serial_port = "COM3" # rfid串口号
    rfid_baudrate = 38400 # rfid读卡器波特率
    rfid_time_out = 0.5  # rfid连接超时时间
    # 如果大于10%, 则认为不稳定
    # 如果大于30%, 则需要降低timeout, 并降低车速.
    # 如果大于50%, 则认为通讯完全异常, 车应停车, 报故障

    # Part 2.3 超声
    ear1_r_data = 4096  # 测量到的障碍的距离: 0~4096
    ear2_r_data = 4096
    ear3_r_data = 4096
    ear4_r_data = 4096

    EAR_DATA_TO_DISATNACE = 2.00/4096
    ear1_distance = ear1_r_data*EAR_DATA_TO_DISATNACE  # 测量到的障碍的距离: 0~4096
    ear2_distance = ear2_r_data*EAR_DATA_TO_DISATNACE
    ear3_distance = ear3_r_data*EAR_DATA_TO_DISATNACE
    ear4_distance = ear4_r_data*EAR_DATA_TO_DISATNACE

    EAR_GRADE_NORMAL = 0  # 不用避障
    EAR_GRADE_WARN = 1 # 0.5米报警,限速0.2m/s
    EAR_GRADE_ERROR = 2  # 0.2米停车,限速0m/s

    EAR_GRADE_WARN_DISTANCE = 0.5
    EAR_GRADE_ERROR_DISTANCE = 0.2
    ear1_grade = 0  # 障碍距离等级 0-无障碍 1-远距离减速 20%速度 2-近距离停车
    ear2_grade = 0
    ear3_grade = 0
    ear4_grade = 0

    EAR_GRADE_NORMAL_MAX_SPEED = 1.0
    EAR_GRADE_WARN_MAX_SPEED = 0.2
    EAR_GRADE_ERROR_MAX_SPEED = 0

    ear_speed_limit_min = -NORMAL_SPEED
    ear_speed_limit_max = NORMAL_SPEED

    # 2.4 红外和触边未必激发
    skin1_r_data = 0 #前向触边的数据,1 为激发, 0为安全
    skin2_r_data = 0 #后向触边的状态, 1 为激发, 0为安全

    skin_speed_limit_min = -NORMAL_SPEED
    skin_speed_limit_max = NORMAL_SPEED

    # 2.5 RFID
    mouth_this_card_id = "12-23-21"
    mouth_last_card_id= "12-23-21"
    mouth_last_card_start_time = None
    mouth_last_card_end_time = None
    mouth_this_card_start_time = None
    mouth_is_new_card=0
    mouth_new_card_count=0
    mouth_target_new_card_count=10000

    # 2.6 巡磁
    nose1_r_data = "0000000000000000"  # 巡磁读数1
    nose2_r_data = "0000000000000000"  # 巡磁读数2

    NOSE_SIZE = [0.16, 0.02, 0.04]  # 鼻子形状
    NOSE_LOCATION = [[0, 0.43, 0.03], [0, -0.43, 0.03]]  # 鼻子位置
    NOSE_DISTANCE = 0.86  # 两个鼻子距离

    nose1_index = 8.5  # 巡磁读数1平均值
    nose2_index = 8.5  # 巡磁读数2平均值
    nose1_count = 0 # 前巡磁巡磁点数量
    nose2_count = 0 # 后巡磁巡磁点数量

    NOSE_WIDTH = 0.16  # 巡磁传感器宽度,单位米
    NOSE_BIT_COUNT = 16  # 巡磁传感器数量
    NOSE_BIT_WIDTH = NOSE_WIDTH / NOSE_BIT_COUNT  # 巡磁传感器的每个位的宽度
    nose1_dx = 0  # 巡磁物理偏移量, + 表示偏向右轮(+x)方向,单位m
    nose2_dx = 0  # 巡磁物理偏移量, + 表示偏向右轮(+x)方向,单位m

    nose_in_use = 2  # 当前使用的鼻子(1:使用前巡磁 2:使用后巡磁)
    magnet_lost = 0  # 是否脱离巡磁(0:未脱磁 1:已脱磁)

    nose_dx = 0
    nose_dw = 0

    nose_target_dx = 0.01
    nose_target_dw_dps = 1

    nose_target_speed1=0
    nose_target_speed2=0

    # 2.7 脚,电机
    FEET_MAX_PWM = 1000
    FEET_MIN_PWM = 10

    FEET_MOTOR_RATIO= 3 # FEET_MOTOR_MAX_RPM/FEET_MAX_PWM
    FEET_MOTOR_MAX_RPM = 3000
    FEET_MOTOR_MIN_RPM = 30

    FEET_GEAR_RATIO = 30

    FEET_WHEEL_MAX_RPM = 100 # FEET_MOTOR_MAX_RPM/FEET_GEAR_RATIO
    FEET_WHEEL_DIAMETER = 0.15
    FEET_WHEEL_CIRCLE_LENGTH = 0.471#FEET_WHEEL_DIAMETER * 3.1416
    FEET_WHEEL_MAX_SPEED = 0.785 #FEET_WHEEL_CIRCLE_LENGTH * FEET_WHEEL_MAX_RPM# m/s

    feet1_target_en = 0  # 左轮使能
    feet2_target_en = 0  # 右轮使能
    feet1_target_speed = 0.50 # 当前的目标速度, 单位是m/s 0.2
    feet2_target_speed = 0.50
    feet1_speed = 0  # 当前左轮速度
    feet2_speed = 0  # 当前右轮速度
    feet1_w_speed_pwm = 0  # 当前要写入的左轮速度, 单位是PWM对应的占空比
    feet2_w_speed_pwm = 0

    FEET_LIMIT_ACC = 0.78*2
    FEET_LIMIT_ACC_IN_PWM = 500  # 每次电机可以增加的加速度
    # 2.8 其他自由度
    # 2.8.1 后背升降
    backbone_r_x1 = 0
    backbone_r_x2 = 0
    backbone_w_up = 0
    backbone_w_down = 0
    backbone_target_x = 0  # 顶升目标位置(1:上升状态 2:下降状态)
    backbone_x = 0  # 当前顶升位置
    start_wait_time = 0  # 开始等待时间

    # 2.8.2 手伸缩
    arm_r_x1 = 0
    arm_r_x2 = 0
    arm_w_out = 0
    arm_w_back = 0
    arm_target_x = 1

    #2.8.3 腰旋转
    waist_r_x1 = 0
    waist_r_x2 = 0
    waist_r_x3 = 0
    waist_w_left = 0
    waist_w_right = 0
    waist_target_x = 1

    this_cmd = ''  # 当前要执行的指令, robot_main中执行单个指令时给此变量赋值
    last_cmd = ''  # 上一次指令
    next_cmd = ''  # 下一个指令
    cmd_index = 0  # 指令执行序号
    cmd_state = 0  # 单个指令完成状态 (0:正在执行,未完成 1:指令执行已完成,可以执行下一个指令)
    target_time = 0  # 5/7/9指令等待时间
    target_new_road_count = 0  # 是否走到新路(4/6指令转弯时候使用)


    # Part 3 初始化
    def run(self):
        print('robot_inside run(),当前线程名=', threading.currentThread().name)
        self.main()

    def init(self):
        print('robot_inside init(),线程名=', threading.currentThread().name)
        self.modbus1_client = ModbusClient(method="rtu", port=self.usb_port, \
                                           stopbits=1, bytesize=8, parity='N', baudrate=self.BAUD_RATE,
                                           timeout=self.TIME_OUT)
        self.modbus1_client.connect()
        # 巡磁、超声避障、电机公用一个modbus1_client,根据不同的从站地址读取各自数据
        # self.mouth_client = self.modbus1_client
        # self.nose_client = self.modbus1_client  # magnet.client代替nose_client
        # 超声避障
        self.ear_client = self.modbus1_client
        # 电机
        self.feet_client = self.modbus1_client
        self.feet_motor = motor.PwmMotor()  # UGLY尽量减少在循环中进行对象的初始化
        self.feet_motor.client = self.modbus1_client
        # 巡磁
        self.magnet = magnet_ms16a.Magnet()
        self.magnet.client = self.modbus1_client
        # RFID
        self.mouth = Rfid(self.rfid_serial_port, self.rfid_baudrate, self.rfid_time_out)
        self.mouth_client = self.mouth.init()
        return


    def read_all(self):
        # 1) 读取rfid
        self.mouth.read_all(self.mouth_client)
        # 2) 读取巡磁
        self.magnet.read_all()
        # 3) 读取超声避障
        # self.ear_read_all()
        # 4) 读取车头包围值
        # 5) 读取电压数值
        # 6) 读取上次的写入数据
        return

    # 软停车(改方法从robot_main中移植而来)
    def feet_soft_stop(self):
        self.car_target_vy = 0
        self.car_target_vw_dps = 0
        while True:
            # 当速度低于一定速度时停车
            if (self.car_target_vy < 1):
                break
            time.sleep(0.01)
        self.feet1_target_en = 0
        self.feet2_target_en = 0
        time.sleep(0.1)
        return True

    def main_logic(self):
        # 车辆安全性问题
        # if self.this_cmd == '':
        #     # 设置停车
        #     self.feet_soft_stop()
        #     return
        # elif self.magnet_lost == 1:  # TODO 后期还需要与一个条件区分4/6指令转弯脱磁还是直线行驶脱磁,并且需要在after_read()后计算magnet_lost的值
        #     # 脱磁停车
        #     self.feet_soft_stop()
        #     return
        # elif (self.nose_in_use == 1 and self.nose1_count > 10) or (self.nose_in_use == 2 and self.nose2_count > 10):
        #     # 满磁停车
        #     self.feet_soft_stop()
        #     return
        # else:
        #     pass

        # 单指令逻辑
        # if self.this_cmd == '7':
        #     self.feet_soft_stop()
        #     self.backbone_target_x = 1
        #     self.start_wait_time = time.time()
        #     return
        # elif self.this_cmd == '9':
        #     self.feet_soft_stop()
        #     self.backbone_target_x = 2
        #     return
        # elif self.this_cmd == '5':
        #     self.feet_soft_stop()
        #     # 等待5秒
        #     self.target_time = 5
        # elif self.this_cmd == '0':
        #     self.feet_soft_stop()
        # else:
        #     print('指令不是5/7/9/0指令,执行下方带巡磁逻辑的动作')


        # 以下为read_all内容, 后期需要放入到read_all、after_read、before_main_logic方法中
        # self.magnet.read_all()  # 已放入read_all中
        magnet_front = self.magnet.channel_list[0]['dr']
        magnet_back = self.magnet.channel_list[1]['dr']

        nose1_int_value = iot_magnet_preprocess.get_int_value(magnet_front)
        nose2_int_value = iot_magnet_preprocess.get_int_value(magnet_back)
        # 从整数值计算返回[index,count]
        nose1_index_count = iot_magnet_preprocess.get_magnet_index_count(nose1_int_value)
        nose2_index_count = iot_magnet_preprocess.get_magnet_index_count(nose2_int_value)
        # 获取平均值序号index
        self.nose1_index = nose1_index_count[0]
        self.nose2_index = nose2_index_count[0]
        # 获取巡磁感应点数量
        self.nose1_count = nose1_index_count[1]
        self.nose2_count = nose2_index_count[1]

        # 根据rfid卡号, 计算new_rfid_count

        # 根据巡磁,计算前后巡磁的姿态
        self.nose_1_dx = self.NOSE_BIT_WIDTH * (self.nose1_index - 8.5)
        self.nose_2_dx = self.NOSE_BIT_WIDTH * (self.nose2_index - 8.5)
        self.nose_dx = (self.nose_1_dx + self.nose_2_dx) / 2
        self.nose_dw = self.nose_dx / self.NOSE_DISTANCE
        # 确定使用的前后巡磁传感器的哪一个
        if self.this_cmd == '8':
            # 使用后巡磁
            self.nose_in_use = 2
        else:
            # 除非是8指令,其余情况都使用前巡磁
            self.nose_in_use = 1

        # 判断是否脱磁
        if (self.nose_in_use == 1 and self.nose1_count == 0) or (self.nose_in_use == 2 and self.nose2_count == 0):
            self.magnet_lost = 1


        if (self.ear1_r_data <= self.EAR_GRADE_ERROR_DISTANCE):
            ear1_grade = self.EAR_GRADE_ERROR

        if (self.skin1_r_data == 1 or self.skin2_r_data==1):
            hard_stop = True

        if (self.magnet_lost == 1):  # TODO 脱磁处理,需要判断不处于转弯脱磁过程中
            self.feet_motor.motor_one_set_speed(0)
            self.feet_motor.motor_two_set_speed(0)
            self.feet1_target_speed = 0
            self.feet2_target_speed = 0
            # 添加使能断开
            self.feet1_target_en = 0
            raise Exception("脱磁")
        if (self.nose1_count > 10):  # 满磁退出
            self.feet_motor.motor_one_set_speed(0)
            self.feet_motor.motor_two_set_speed(0)
            self.feet1_target_speed = 0
            self.feet2_target_speed = 0
        print("target speed：", self.feet1_target_speed, " ", self.feet2_target_speed)
        # 计算与巡磁中心位置偏差
        self.nose1_dx = self.NOSE_BIT_WIDTH * (self.nose1_index - 8.5)
        self.nose2_dx = self.NOSE_BIT_WIDTH * (self.nose2_index - 8.5)
        # self.nose_in_use = 1

        # 计算车偏差角度
        self.nose_dx = (self.nose1_dx + self.nose2_dx) / 2
        self.nose_dw = self.nose_dx / self.NOSE_DISTANCE

        print('[nose_after_read] 前巡磁二进制=', self.nose1_r_data, ', 对应十进制数=', nose1_int_value,
              ', 感应点数量=', self.nose1_count, ', 平均值index=', self.nose1_index)
        print('[nose_after_read] 后巡磁二进制=', self.nose2_r_data, ', 对应十进制数=', nose2_int_value,
              ', 感应点数量=', self.nose2_count, ', 平均值index=', self.nose2_index)
        print('[nose_after_read] 前巡磁与中心位置偏差nose1_dx=', self.nose1_dx, ', 后巡磁与巡磁中心位置偏差nose2_dx=',
              self.nose2_dx, ', 偏差角度nose_dw=', self.nose_dw)

        print("dx:",self.nose1_dx)
        # car_target_vw_dps代替target_r
        if abs(self.nose1_dx) < 0.01:
            self.car_target_vw_dps = 0
        elif abs(self.nose1_dx) <= 0.03:
            self.car_target_vw_dps = 0.3
        elif abs(self.nose1_dx) <= 0.05:
            self.car_target_vw_dps = 0.5
        else:
            self.car_target_vw_dps = 0.7

        print("r：", self.car_target_vw_dps)
        if self.nose1_dx == 0:
            self.nose_target_speed1 = self.feet1_target_speed
            self.nose_target_speed2 = self.feet2_target_speed

        elif self.nose1_dx > 0:
            self.nose_target_speed1 = self.feet1_target_speed
            self.nose_target_speed2 = self.feet2_target_speed * (1 - self.car_target_vw_dps)
        else:  # (self.nose1_dx < 0):
            self.nose_target_speed1 = self.feet1_target_speed * (1 - self.car_target_vw_dps)
            self.nose_target_speed2 = self.feet2_target_speed

            # 转速追踪 target speed
        if self.feet1_speed < self.nose_target_speed1:
            self.feet1_speed += self.FEET_LIMIT_ACC * self.TIME_STEP
            if  self.feet1_speed > self.nose_target_speed1:
                self.feet1_speed = self.nose_target_speed1
        if self.feet1_speed > self.nose_target_speed1 :
            self.feet1_speed -= self.FEET_LIMIT_ACC
            if (self.feet1_speed < self.nose_target_speed1):
                self.feet1_speed = self.nose_target_speed1
        if self.feet2_speed < self.nose_target_speed2:
            self.feet2_speed += self.FEET_LIMIT_ACC
            if (self.feet2_speed > self.nose_target_speed2):
                self.feet2_speed = self.nose_target_speed2
        if self.feet2_speed > self.nose_target_speed2:
            self.feet2_speed -= self.FEET_LIMIT_ACC
            if self.feet2_speed < self.nose_target_speed2 :
                self.feet2_speed = self.nose_target_speed2

        print(time.time(), "motor开始写")
        self.feet1_speed_rpm = self.feet1_speed/self.FEET_WHEEL_MAX_SPEED*self.FEET_MOTOR_MAX_RPM
        self.feet2_speed_rpm = self.feet2_speed / self.FEET_WHEEL_MAX_SPEED * self.FEET_MOTOR_MAX_RPM
        self.feet1_w_speed_pwm = self.feet_motor.rpm_to_pwm(self.feet1_speed_rpm)
        self.feet2_w_speed_pwm =self.feet_motor.rpm_to_pwm(self.feet2_speed_rpm)
        print("speed：", self.feet1_w_speed_pwm, " ", self.feet2_w_speed_pwm)

        return

    def nose_calculate_dx(self, index):  # 计算dx
        CENTER_INDEX = 8.5
        GRID_WIDTH = 0.01
        return (index - 8.5) * 0.01


    # Part 6 写入
    def write_all(self):
        if self.cmd_state == 1:
            if self.backbone_target_x == 1:
                # 如果当前已经处于顶升上升状态,则不再重复发送顶升上升指令
                if self.backbone_target_x != self.backbone_x:
                    # 顶升上升,发送上升指令(顶升有PWM4端子控制,寄存器地址为9,数值设置为1000(即占空比100%))
                    print('===> 发送顶升上升指令')
                    self.feet_motor.lift_up()
                    time.sleep(0.005)
                    self.feet_motor.lift_up()
                    time.sleep(0.005)
                    self.feet_motor.lift_up()
                    time.sleep(0.005)
                    self.backbone_x = self.backbone_target_x
                # 判断等待时间
                t1 = time.time() - self.start_wait_time
                if t1> self.target_time:
                    print('[inside2] 7指令到达target_time, target_time=', self.target_time, ', t1=', t1)
                    # 达到指定时间,指令执行完毕
                    self.target_time = 0
                    self.backbone_target_x = 0
                    self.cmd_state = 0
                else:
                    print('[inside2] 7指令未到达target_time, t1=', t1)
                return
            elif self.backbone_target_x == 2:
                # 如果当前已经处于顶升下降状态,则不再重复发送顶升下降指令
                if self.backbone_target_x != self.backbone_x:
                    # 顶升下降,发送下降指令(顶升有PWM4端子控制,寄存器地址为9,数值设置为0(即占空比0%))
                    print('===> 发送顶升下降指令')
                    self.feet_motor.lift_down()
                    time.sleep(0.005)
                    self.feet_motor.lift_down()
                    time.sleep(0.005)
                    self.feet_motor.lift_down()
                    time.sleep(0.005)
                    self.backbone_x = self.backbone_target_x
                # 判断等待时间
                t2 = time.time() - self.start_wait_time
                if t2 > self.target_time:
                    print('[inside2] 9指令到达target_time, target_time=', self.target_time, ', t2=', t2)
                    # 达到指定时间,指令执行完毕
                    self.target_time = 0
                    self.backbone_target_x = 0
                    self.cmd_state = 0
                else:
                    print('[inside2] 9指令执行还未到达target_time,t2=', t2)
                return
            else:
                pass


        # 电机运动的指令(用于2468时候)
        # self.feet_motor.motor_one_set_speed(self.feet1_w_speed_pwm)
        # self.feet_motor.motor_two_set_speed(self.feet2_w_speed_pwm)
        # print(time.time(), "motor结束写")
        # return


    # Part 8 主逻辑
    def step(self):  # 主循环的一个步骤
        # print('[robot_inside2] 进入step方法,线程名=', threading.currentThread().name)
        step_start_time = time.time()
        # read_start_time = time.time()
        # 身体部件开始获取传感器数据
        self.read_all()
        # read_end_time = time.time()
        # self.main_logic()
        # write_start_time = time.time()
        self.write_all()
        # write_end_time = time.time()
        step_end_time = time.time()
        time_to_sleep = self.TIME_STEP + step_start_time - step_end_time
        if (time_to_sleep >= 0):
            logging.info("Robot Inside 执行完一次step，休眠", time_to_sleep, '后再次执行step')
            time.sleep(time_to_sleep)
        else:
            logging.error("Robot Inside 没能在约定时间内完成一个循环")
        return

    # 主循环
    def loop(self):
        # self.sleep_to_align_time(TIME_STEP)
        while True:  # 循环执行步骤
            try:
                self.step()
            except Exception as ex:  # 出现异常
                self.error_queue = ex  # 记录异常
                ok = self.deal_with_Exception()  # 处理异常
                if (not ok):
                    self.before_error_exit()  # 异常处理失败
                    self.dispose()
                    exit(1)  # 异常退出
                # 重新启动
                else:
                    continue

    # 异常处理ok
    def deal_with_Exception(self):
        print('find error', self.error_queue)
        return True

    # 异常处理退出
    def before_error_exit(self):
        print('robot_inside before_error_exit')
        return

    # 释放资源
    def dispose(self):
        return

    # 主函数
    def main(self):
        print('进入robot_inside main()方法,线程名=', threading.currentThread().name)
        self.init()
        self.loop()
        self.dispose()
        exit(0)

# Part 9 测试用例
if __name__ == "__main__":
    r = RobotInside().run()