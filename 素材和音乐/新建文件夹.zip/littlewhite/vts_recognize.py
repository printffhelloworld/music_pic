# -*- coding: utf-8 -*-
#### For baidu voice
#别人的ID,KEY,KEY,先留着以备不时之需
# APP_ID = '15311704'
# API_KEY = 'yTzBl40WBlhFOo1GnKk0YQTN'
# SECRET_KEY = 'xpWedO1u0ZLATHijhetFo7dE5ibMsI6Q'
from aip import AipSpeech
import speech_recognition as sr

class VtsRecognize():
    APP_ID = '17107910'
    API_KEY = 'TuO6iTQ5QYZDoQriXX2aPWEj'
    SECRET_KEY = 'r8NcN19W5VzM02cLvyUHcy0fqGhGlBC7'
    client = None
    r = None
    mic = None
    def __init__(self):
        return

    # 带配置的构造函数
    def config(self, APP_ID, API_KEY,SECRET_KEY):
        self.APP_ID = APP_ID
        self.API_KEY = API_KEY
        self.SECRET_KEY = SECRET_KEY
        return True

    #返回我所找的扬声器索引
    def get_device_index(self,device_list):
        device_index=-1
        for my_index in device_list:
            device_index+=1
            print(device_index,":",my_index)
            if my_index=='麦克风 (Realtek High Definition Au':#将此串改成想要的就行了
                print("你要的设备号为:",device_index)
                return device_index
        print("未找到指定设备,请检查安装设备!")

    def connect(self):
        self.client=AipSpeech(self.APP_ID, self.API_KEY, self.SECRET_KEY)
        self.r = sr.Recognizer()
        # self.mic = sr.Microphone()
        mic_list=sr.Microphone().list_microphone_names()
        print(mic_list)
        my_index=self.get_device_index(mic_list)
        self.mic = sr.Microphone(device_index=my_index)

    #将声音转为string
    def voice2string(self,wav_bytes):
        result = self.client.asr(wav_bytes, 'wav', 16000, {'dev_pid': 1536, })
        try:
            text = result['result'][0]
        except Exception as e:
            print(e)
            text = ""
        return text

    #### For real time voice recording
    def get_text(self):
        print("\n聆听中...:")
        with self.mic as source:

            self.r.adjust_for_ambient_noise(source)
            audio = self.r.listen(source)
            audio_data = audio.get_wav_data(convert_rate=16000)
            print("\n解析中...")
            text = self.voice2string(audio_data)
            print(f"\n{text}")#如需看解析结果，请放开此注释
            return text
def test():
    vtsRecognize=VtsRecognize()
    vtsRecognize.connect()
    vtsRecognize.get_text()

if __name__ == '__main__':
    test()