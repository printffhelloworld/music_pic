# -*- coding: cp936 -*-
from playsound import playsound
class Mp3Player():
    def playmp3(self,audio_name='audio.mp3'):
        playsound(audio_name)
        return True

def test():
    mp3Player=Mp3Player()
    mp3Player.playmp3()

if __name__ == '__main__':
    print("��ʼ")
    test()
    print("����")

# -*- coding: cp936 -*-
#sudo apt-get install mpg123
# import subprocess
# class Mp3Player():
#     mp3_mod_cheat = False
#     TimeOut =  30
#     def playmp3(self,audio_name='audio.mp3'):
#         if self.mp3_mod_cheat == True:
#             self.TimeOut=15
#         else:
#             self.TimeOut=30
#         try:
#             p=subprocess.Popen(['mpg123', '-q', audio_name])
#             p.wait(timeout=self.TimeOut)
#         except Exception as e:
#             print("Exception,e=",e)
#             p.kill()
#             self.playmp3(audio_name=audio_name)
#         return True
#
# def test():
#     mp3Player=Mp3Player()
#     mp3Player.playmp3()
#
# if __name__ == '__main__':
#     print("��ʼ")
#     test()
#     print("����")