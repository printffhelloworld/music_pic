# -*- coding: utf-8 -*-
#author:王琛
#mail:17751317450@163.com
#语音识别模块
#百度语音网址链接:  https://console.bce.baidu.com/ai/?_=1566891327244&fromai=1#/ai/speech/app/detail~appId=1190606
# AppID = 17107910
# API Key = TuO6iTQ5QYZDoQriXX2aPWEj
# Secret Key = r8NcN19W5VzM02cLvyUHcy0fqGhGlBC7

# from aip import AipSpeech
from aip import AipSpeech
class TtvRecognize():
    APP_ID = '17107910'
    API_KEY = 'TuO6iTQ5QYZDoQriXX2aPWEj'
    SECRET_KEY = 'r8NcN19W5VzM02cLvyUHcy0fqGhGlBC7'
    # 新建一个AipSpeech
    client = None
    def __init__(self):
        return

    # 带配置的构造函数
    def config(self, APP_ID, API_KEY,SECRET_KEY):
        self.APP_ID = APP_ID
        self.API_KEY = API_KEY
        self.SECRET_KEY = SECRET_KEY
        return True

    def connect(self):
        self.client=AipSpeech(self.APP_ID, self.API_KEY, self.SECRET_KEY)

    def get_voice(self):
        f = open("demo.txt", 'r')
        command = f.read()
        if len(command) != 0:
            word = command
        f.close()
        result = self.client.synthesis(word, 'zh', 1, {
            'vol': 5, 'per': 0,
        })
        # 合成正确返回audio.mp3，错误则返回dict
        if not isinstance(result, dict):
            with open('audio.mp3', 'wb') as f2:
                f2.write(result)
            f2.close()
            print('文字转语音完成!')
            return True

def test():
    ttvRecongize=TtvRecognize()
    ttvRecongize.connect()
    ttvRecongize.get_voice()

if __name__ == '__main__':
    test()