# -*- coding:utf-8 -*-
import app as appp
if __name__=="__main__":
    appp.startAPP()