# -*- coding:utf-8 -*-
# !/res/moobot/shoeagv/auto_charge.py
# author: 杨志成,王琛
# email:yangzc2009cc@163.com
# 自动充电

# 采集到的当前电量值
import time
import threading
class AutoCharge(threading.Thread):
    voltage = 24.0
    voltage_full = 27.0  # 满电量(100%电量)
    voltage_high = 25.5  # 高电量(60%电量)
    voltage_low = 23.0  # 低电量(20%电量)
    voltage_very_low = 22.0  # 超低电量(15%电量)

    AGV_STATE_IDLE = 'idle'
    AGV_STATE_BUSY = 'busy'
    agv_state = ''
    is_charging = False
    task_queue = []
    def run(self):
        if self.agv_state == self.AGV_STATE_IDLE:
            if self.is_charging:
                # 在充电
                if self.voltage > self.voltage_very_low and self.voltage < self.voltage_high:
                    # 继续充电,不管是否有任务
                    pass
                elif self.voltage > self.voltage_high:
                    if len(self.task_queue) > 0:
                        # 充电超过60%,发现有任务,从充电点返回至起点开始执行任务
                        self.go_to_origin()
                        time.sleep(1)
                elif self.voltage == self.voltage_full:
                    self.go_to_origin()
            else:  # 不在充电
                if self.voltage < self.voltage_very_low:
                    # 低于15%
                    # TODO 去充电
                    self.go_to_charge()
                elif self.voltage < self.voltage_low:
                    # 低于20%,等待1分钟,没有任务则去充电
                    count = 0
                    while True:
                        # TODO 是否有任务,没有任务则等待,若到1分钟还没有任务,则去充电
                        ok = self.check_task()
                        if ok:
                            self.execute_next_task()
                            count = 0
                        else:
                            time.sleep(1)
                            count += 1
                            if count >= 60:
                                count = 0
                                self.go_to_charge()
                                break
                else:
                    # 60%电量以上,执行下一个任务
                    self.execute_next_task()

    def go_to_charge(self):

        print('去充电')

    def check_task(self):

        print('检测是否有任务')

    def execute_next_task(self):

        print('执行下个任务')

    def return_to_execute_task(self):

        print('从充电点返回去执行任务')

    def go_to_origin(self):

        print('先回原点')
