
import logging
import threading
import time
# pip install pymodbus
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
import iot.iot_motor3 as motor
import iot.iot_magnet_ms16a_1 as magnet_ms16a
import iot.iot_rfid_rc522
from iot import iot_magnet_preprocess
from iot.iot_magnet_ms16a import Magnet
from iot.iot_rfid_rc522 import Rfid


    # 2.6 巡磁
    nose1_r_data = "0000000000000000"  # 巡磁读数1
    NOSE_SIZE = [0.16, 0.02, 0.04]  # 鼻子形状
    NOSE_LOCATION = [[0, 0.43, 0.03], [0, -0.43, 0.03]]  # 鼻子位置
    NOSE_DISTANCE = 0.86  # 两个鼻子距离
    nose1_index = 8.5  # 巡磁读数1平均值
    nose1_count = 0 # 前巡磁巡磁点数量
    NOSE_WIDTH = 0.16  # 巡磁传感器宽度,单位米
    NOSE_BIT_COUNT = 16  # 巡磁传感器数量
    NOSE_BIT_WIDTH = NOSE_WIDTH / NOSE_BIT_COUNT  # 巡磁传感器的每个位的宽度
    nose1_dx = 0  # 巡磁物理偏移量, + 表示偏向右轮(+x)方向,单位m

    def init(self):
        self.modbus1_client = ModbusClient(method="rtu", port=self.usb_port, \
                                           stopbits=1, bytesize=8, parity='N', baudrate=self.BAUD_RATE,
                                           timeout=self.TIME_OUT)
        self.modbus1_client.connect()
        self.nose_client = self.modbus1_client  # magnet.client代替nose_client

        self.magnet.read_all()

        magnet_front = self.magnet.channel_list[0]['dr']
        nose1_int_value = iot_magnet_preprocess.get_int_value(magnet_front)

        # 从整数值计算返回[index,count]
        nose1_index_count = iot_magnet_preprocess.get_magnet_index_count(nose1_int_value)
       # 获取平均值序号index
        self.nose1_index = nose1_index_count[0]

        # 获取巡磁感应点数量
        self.nose1_count = nose1_index_count[1]

        # 根据巡磁,计算前后巡磁的姿态
        self.nose_1_dx = self.NOSE_BIT_WIDTH * (self.nose1_index - 8.5)
        # 判断是否脱磁
        if (self.nose1_count == 0) :
            self.feet_motor.motor_one_set_speed(0)
            self.feet_motor.motor_two_set_speed(0)
            return True
        if (self.nose1_count > 10):  # 满磁退出
            return True



        print("target speed：", self.feet1_target_speed, " ", self.feet2_target_speed)
        # 计算与巡磁中心位置偏差
        self.nose1_dx = self.NOSE_BIT_WIDTH * (self.nose1_index - 8.5)

        # 计算车偏差角度
        self.nose_dx = (self.nose1_dx + self.nose2_dx) / 2
        self.nose_dw = self.nose_dx / self.NOSE_DISTANCE

        print('[nose_after_read] 前巡磁二进制=', self.nose1_r_data, ', 对应十进制数=', nose1_int_value,
              ', 感应点数量=', self.nose1_count, ', 平均值index=', self.nose1_index)



        print("dx:",self.nose1_dx)
        # car_target_vw_dps代替target_r
        if abs(self.nose1_dx) < 0.01:
            self.car_target_vw_dps = 0
        elif abs(self.nose1_dx) <= 0.03:
            self.car_target_vw_dps = 0.3
        elif abs(self.nose1_dx) <= 0.05:
            self.car_target_vw_dps = 0.5
        else:
            self.car_target_vw_dps = 0.7

        print("r：", self.car_target_vw_dps)
        if self.nose1_dx == 0:
            self.nose_target_speed1 = self.feet1_target_speed
            self.nose_target_speed2 = self.feet2_target_speed

        elif self.nose1_dx > 0:
            self.nose_target_speed1 = self.feet1_target_speed
            self.nose_target_speed2 = self.feet2_target_speed * (1 - self.car_target_vw_dps)
        else:  # (self.nose1_dx < 0):
            self.nose_target_speed1 = self.feet1_target_speed * (1 - self.car_target_vw_dps)
            self.nose_target_speed2 = self.feet2_target_speed

        print(time.time(), "motor开始写")
        self.feet1_speed_rpm = self.feet1_speed/self.FEET_WHEEL_MAX_SPEED*self.FEET_MOTOR_MAX_RPM
        self.feet2_speed_rpm = self.feet2_speed / self.FEET_WHEEL_MAX_SPEED * self.FEET_MOTOR_MAX_RPM
        self.feet1_w_speed_pwm = self.feet_motor.rpm_to_pwm(self.feet1_speed_rpm)
        self.feet2_w_speed_pwm =self.feet_motor.rpm_to_pwm(self.feet2_speed_rpm)
