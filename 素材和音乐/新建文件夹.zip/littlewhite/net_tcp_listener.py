from socketserver import BaseRequestHandler, TCPServer
import _thread
from threading import Thread
import socket
import queue
from socketserver import BaseRequestHandler, TCPServer
import iot_motor as motor
import time
class TcpCommander():
    serversocket = None
    autoMode = True
    emergencyStop = False
    feet = None
    # target_clients = ("192.168.100.104",20000,)
    target_clients = ("127.0.0.1",20000,)
    main_state = 0
    voltage = 0
    is_charging = False
    last_rfid=""
    this_rfid=""
    run_byself=False
    mod_cheat = False
    cheat_state = "未聊天"
    q_len=0
    x = 0
    y = 0
    w = 0
    # ser = None

    q = queue.Queue(maxsize=10)
    def __init__(self):
        super(TcpCommander, self).__init__()
        return

    def connect(self,b):
        self.serversocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.serversocket.bind(self.target_clients)
        self.serversocket.listen(5)
        self.start_listen()
        # serv = TCPServer(('', 20000), TcpCommander.start_listen())
        return

    def start_listen(self):
        print('The server is ready to receive')
        try:
            _thread.start_new_thread(self.listen,(1,))
        except:
            print("开启线程失败")

        return

    def send(self,msg):
        # self.serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # self.serversocket.bind(self.target_clients)
        # self.serversocket.send(msg.encode("utf-8"))
        return

    def listen(self,a):
        while 1:
            connectionSocket, addr = self.serversocket.accept()
            sentence = connectionSocket.recv(1024*4)
            if sentence != b'':
                recvstr = sentence.decode("utf-8")
                if recvstr == "ykqq":
                    print("向前")
                    self.autoMode=False
                    self.q.empty()
                    self.feet.forword()
                elif recvstr =="ykqh":
                    print("向后")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.backword()
                elif recvstr =="ykqz":
                    print("向左")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.left()
                elif recvstr =="ykqy":
                    print("向右")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.right()
                elif recvstr =="ykqt":
                    print("停")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.stop()
                elif recvstr == "emergency_stop":
                    print("立刻停止")
                    self.emergencyStop = True
                    self.run_byself = False
                    self.mod_cheat = False
                elif recvstr == "run_by_self":
                    print("自动运行(讲解模式)")
                    self.autoMode = True
                    self.emergencyStop = False
                    self.mod_cheat = False
                    self.run_byself=True
                elif recvstr == "not_run_by_self":
                    print("静止不动(等待命令)")
                    self.autoMode = True
                    self.emergencyStop = True
                    self.mod_cheat = False
                    self.run_byself = False
                elif recvstr == "mod_cheat":
                    print("聊天模式")
                    self.mod_cheat = True
                    self.emergencyStop=True
                elif recvstr == "qingqiuzhuangtaishuju":
                    # 下两行返回状态
                    print("请求状态数据")
                    state_packeg={"cheat_state":str(self.cheat_state)}
                    ret_msg = (str(state_packeg).encode("utf-8"))
                    print("返回的状态数据",ret_msg)
                    connectionSocket.send(ret_msg)
                else:
                    self.autoMode = True
                    self.emergencyStop = False
                    self.run_byself = False
                    self.mod_cheat = False
                    time.sleep(0.5)
                    self.q.put(recvstr, block=True, timeout=None)
                    print("消息队列长度：", self.q.qsize())
                    print("receive : ", recvstr)
        return


if __name__ == '__main__':
    tcp = TcpCommander()
    tcp.connect(2)
    while True:
        pass