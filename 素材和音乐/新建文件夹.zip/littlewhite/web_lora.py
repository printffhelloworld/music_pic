#! /res/moobot/slenderagv/web_lora.py
#coding=utf-8
# 本程序用Flask打开网站, 进行上位机Lora程序的测试.
# 如果在本机使用, 则需要配置两个Lora端口, 一个用于app.py的配置
# 一个用于web_lora的配置
# 注意, web_lora包括一个lora的talker_A, 和一个lora的listener_B
# 同时 net_lora_commander 包括一个lora的listener_B, 和一个lora的talker_A
import serial
from flask import Flask, url_for, render_template, redirect, jsonify
from flask import request
import queue
ser = None
web_lora = Flask(__name__)

def init_lora():
    #TODO: 初始化Lora
    serialPort = "COM4"  # 串口
    baudRate = 9600  # 波特率
    global ser
    try:
        ser = serial.Serial(serialPort, baudRate, timeout=0.5)
    except:
        print("未发现lora设备")
        return
    if ser.is_open:
        print("端口连接成功")
    else:
        print("端口连接失败")
    return

# @web_lora.route('/')
# def api_root():
#     return redirect(url_for('control')) #重定向
# @web_lora.route('/control')
# def control():
#     return render_template("debug.html")
@web_lora.route('/')
def debug():
    return render_template("controler.html")
@web_lora.route('/channel.html')
def channel():
    return render_template("channel.html")
@web_lora.route('/zone2nine.html')
def zone2nine():
    return render_template("zone2nine.html")
@web_lora.route('/ruku.html')
def ruku():
    return render_template("ruku.html")
@web_lora.route('/controler.html')
def controler():
    return render_template("controler.html")

@web_lora.route('/send', methods=['POST'])
def send():
    post_data = request.get_json(silent=True)
    print(post_data)
    str1 = post_data['str']
    print(str1)
    sendStr = str(str1).encode()
    print(sendStr)
    global ser
    ser.write(sendStr)
    data_wrapper = {'result_code': 0}
    return jsonify(data_wrapper)

#入库1
@web_lora.route("/in1", methods=['POST'])
def in1():
    # 获取到post的json数据
    print("进入入库1")
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraIn = "720"
    print(paraIn)
    #lora发送数据
    sendStr = paraIn.encode()
    global ser
    ser.write(sendStr)

    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#入库2
@web_lora.route("/in2", methods=['POST'])
def in2():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraIn = "0-" + post_data['paraIn']
    print(paraIn)
    # lora发送数据
    global ser
    ser.write(paraIn.encode())

    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#出库1
@web_lora.route("/out1", methods=['POST'])
def out1():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = post_data['paraOut']
    print(paraOut)
    # lora发送数据
    global ser
    ser.write(paraOut.encode())

    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#出库2
@web_lora.route("/out2", methods=['POST'])
def out2():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = "24490"
    print(paraOut)
    # lora发送数据
    global ser
    ser.write(paraOut.encode())

    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#移库
@web_lora.route("/move", methods=['POST'])
def move():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraMove = post_data['paraMove']
    print(paraMove)
    # lora发送数据
    global ser
    ser.write(paraMove.encode())

    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#去
@web_lora.route("/go", methods=['POST'])
def go():
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#回
@web_lora.route("/back", methods=['POST'])
def back():
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

# #返回当前状态
# @app.route("/getState", methods=['POST'])
# def getState():
#     # 返回数据,如果成功result_code 为 0 result_msg 为success
#     state="state=**"
#     data = {'state': state}
#     data_wrapper = {'result_code': 0, 'result_msg': "success", 'data': data}
#     return jsonify(data_wrapper)
#
# def recv(serial):
#     while True:
#         # lora定义接收30字节长度
#         data = serial.read(30)
#         if data == '':
#             continue
#         else:
#             break
#             sleep(2000)
#     return data
class runweb():
    def start(self):
        # web_tcp.run(host='127.0.0.1' ,port=5000)
        web_lora.run(host='192.168.0.105' ,port=5000)

if __name__ == '__main__':
    init_lora()
    web_lora.run()
