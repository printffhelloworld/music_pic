import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
from shoeagv.iot_modbus_rtu_xyd1210 import ModbusRtuXyd1210
# 拥有三个限位点的腰

class Waist3():
    # PART 0: 初始化
    def __init__(self):
        return

    rtu = ModbusRtuXyd1210()
    def init(self):
        self.rtu.config('COM3', 21)
        return

    Channel_list=["p1","p2","p3", "motor_br", "motor_speed", "motor_en"]
    p1=0 # 1号位置光电开关, 1到位0不到位
    p2=0# 2号位置光电开关, 1到位0不到位
    p3=0# 3号位置光电开关, 1到位0不到位
    motor_br=0 # 电机制动 1 闸制动 0 闸松开
    motor_speed=0 # 电机速度, + 正转, - 反转, 0 停转
    motor_en=0 # 电机使能 1电机运行 0 电机停止不运行

    P1_W = 0 # 光电开关Waist.P1位置, 角度,
    P2_W = 90# 光电开关Waist.P2位置, 角度,
    P3_W = 180# 光电开关Waist.P3位置, 角度,


    est_w=0 # 估计当前的角度值
    est_point=0 # 估计当前的点位
    last_point=0 # 上次测量到点位
    last_point_enter_time =None # 上次进入测量点位的时间
    last_point_leave_time =None # 上次离开测量点位的时间

    P_L=1 #低位限位点位, 超过部分电机不得继续旋转
    P_H=3 #高位限位点位, 超过部分电机不得继续旋转

    # PART 1: IOT 传感器读取
    def read_all(self):
        self.p1=self.get_p1()
        self.p2 = self.get_p2()
        self.p3 = self.get_p3()
        if(self.p1+self.p2+self.p3>1):
            pass
        if(self.p1==1):
            pass
            last_point=1
            last_point_enter_time= time.localtime()


    def get_p1(self):
        # TODO: 王琛
        return # Iot.Modbus.read("xxx")
    def get_p2(self):
        return
    def get_p3(self):
        return

    # PART 2: 传感器写入
    # 本部分为空
    def get_brake(self):
        # TODO: 王琛
        return 0

    def set_brake(self, val):
        # TODO: 王琛
        return
    def brake_on(self):
        return self.set_brake(1)
    def brake_off(self):
        return self.set_brake(0)


    # PART 3: 电机运动速度控制
    '''
    所有的对电机的操作都必须要通过这个指令进行
    主要原因, 就是
    电机在向正方向走之前, 必须确定不要超过正向限位
    在向反方向走之前, 不要超过反向限位. 
    '''
    def move_v(self, speed):
        # TODO: 王琛, 电机控制
        if(self.get_brake()==1):
            self.brake_off()
        if(self.get_p1()==1 and speed<0):
            self.stop()
        if(self.get_p3()==1 and speed>0):
            self.stop()
        return

    NORMAL_SPEED= 10
    def move_vp(self):
        return  self.move_v(self.NORMAL_SPEED)
    def move_vn(self):
        return self.move_v(-self.NORMAL_SPEED)
    def stop(self):
        return self.move_v(0)

    # PART 4: 电机运动(相对)位移控制

    # 不推荐使用
    def move_s(self, distance, speed=NORMAL_SPEED):
        # for i in range(1,distance/speed*RATE):
        #     self.move_v(speed)
        self.stop()
        return

    # PART 5: 电机运动(绝对)位置控制

    def go_next(self):
        #1以及1-2之间的位置转到2（以b'\x01\xed'为停止条件）
        #2以及2-3之间的位置转到3
        #3的位置提交错误
        print("进入next")
        ch11 = self.rtu.read_X1()
        if(ch11 == 1):
            print("目前在3的位置，无法逆时针动作")
            return  True
        ch22 = self.rtu.read_X2()
        ch33 = self.rtu.read_X3()
        print("开始转")
        self.rtu.write_Y0(0)
        self.rtu.write_Y1(1)
        print("开始循环读取")
        time.sleep(2)
        while True:
            ch1 = self.rtu.read_X1()
            ch2 = self.rtu.read_X2()
            ch3 = self.rtu.read_X3()
            print(ch1,ch2,ch3)
            if ch33==3 and ch1==1:
                # 系统出错了
                # TODO：
                self.rtu.write_Y0(0)
                self.rtu.write_Y1(0)
                return False
            if ch33 == 1  and ch2 == 1 \
                    or ch22 == 1 and ch1 == 1 \
                    or ch33!=1 and ch22!=1 and (ch2 ==1 or ch1 ==1 ):
                break
        self.rtu.write_Y0(0)
        self.rtu.write_Y1(0)
        print("next执行结束")
        print(ch1, ch2, ch3)
        return True

    def go_last(self):
        #3以及3和2中间的位置，可以转到2的位置
        #2以及2和1之间的位置，可以转到1的位置
        #1的位置报错
        print("进入last中")
        ch33 = self.rtu.read_X3()
        if (ch33 == 1):
            print("目前在1的位置，无法顺时针动作")
            return True
        ch22 = self.rtu.read_X2()
        ch11 = self.rtu.read_X1()
        print("开始转")
        self.rtu.write_Y0(1)
        self.rtu.write_Y1(0)
        time.sleep(2)
        while True:
            ch1 = self.rtu.read_X1()
            ch2 = self.rtu.read_X2()
            ch3 = self.rtu.read_X3()
            print(ch11, ch22, ch33)
            if ch11==1 and ch3==1:
                # 系统出错了
                # TODO：
                self.rtu.write_Y0(0)
                self.rtu.write_Y1(0)
                return False
            if ch11 == 1  and ch2 == 1 \
                    or ch22 == 1 and ch3 == 1 \
                    or ch11!=1 and ch22!=1 and (ch2 ==1 or ch3 ==1 ):
                break
        self.rtu.write_Y0(0)
        self.rtu.write_Y1(0)
        print("last结束")
        print(ch1, ch2, ch3)
        return  True

    def go_1(self):
        while True:
            self.move_vp()
            if(self.get_p1()==1):
                self.stop()
                break
        return
    last_position=1
    # last_position_enter_time =
    # last_position_leave_time =
    # def go_2(self):
    #     if(last_position==1):
    #
    #
    #     return

    def go_3(self):
        while True:
            self.move_vn()
            if(self.get_p3()==1):
                self.stop()
                break
        return

if __name__ == '__main__':
    waist = Waist3()
    waist.init()
    waist.rtu.connect()
    boo = waist.go_next()
    # boo = waist.go_last()
    print(boo)