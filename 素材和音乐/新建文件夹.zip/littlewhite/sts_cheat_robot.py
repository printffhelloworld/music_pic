# -*- coding: utf-8 -*-
#图灵机器人
import requests
import json
# import time
# 创建post函数
class CheatRobot():
    # 图灵api
    api=r'http://openapi.tuling123.com/openapi/api/v2'
    apiKey="32fa87f19ba44801bb065cc493d915d8"
    userId='117b668568d733a8'

    def __init__(self):
        return

    # 带配置的构造函数
    def config(self, apiKey, userId):
        self.apiKey=apiKey
        self.userId=userId
        return True

    def get_answer(self,question):
        # 创建post提交的数据
        data = {
            "perception": {
                "inputText": {
                    "text": question
                }
            },
            "userInfo": {
                "apiKey": self.apiKey,
                "userId": self.userId,
            }
        }
        # 转化为json格式
        jsondata = json.dumps(data)
        # 发起post请求
        response = requests.post(self.api, data=jsondata)
        # 将返回的json数据解码
        robot_res = json.loads((response.content).decode("utf-8"))#byte转str
        # 提取对话数据
        # print("robot_res=",robot_res)
        answer=robot_res["results"][0]['values']['text']
        print("小白:",answer)
        return answer

def test():
    cheatRobot=CheatRobot()
    cheatRobot.config("32fa87f19ba44801bb065cc493d915d8","117b668568d733a8")
    while True:
        # 输入对话内容
        question = input("我:")
        text=cheatRobot.get_answer(question)

if __name__ == '__main__':
    test()
