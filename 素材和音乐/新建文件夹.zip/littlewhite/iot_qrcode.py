#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#pip3 install pyzbar
#author:王琛
#date:2019/8/21
#mail:17751317450@163.com
import cv2
import pyzbar.pyzbar as pyzbar
#屏幕左上角(0,0),右下角(640,480),屏幕中心点(320,240)
from pyzbar.locations import Point


class Qrcode():
    camera=None
    quantity=0
    text=[]
    polygon=[]
    center_list = []
    dx=0
    #屏幕中心(X0,Y0)
    X0=320
    Y0=240
    def __init__(self):
        return

    #获取读到的二维码数量
    def get_quantity(self):
        return self.quantity

    #获取二维码的内容:
    def get_text(self):
        return self.text

    #获取二维码的四角坐标
    def get_polygon(self):
        return self.polygon

    #打开视频
    def init(self):
        self.camera = cv2.VideoCapture(0)

    #识别二维码
    def detect(self):
        # 读取当前帧
        ret, frame = self.camera.read()
        # 转为灰度图像
        # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)#转成灰色
        im = self.analysis(frame)  # 不转灰色
        # im = decodeDisplay(gray)#转成灰色
        cv2.waitKey(5)
        cv2.imshow("camera", im)

    def stop(self):
        self.camera.release()
        cv2.destroyAllWindows()

    #解析二维码
    def analysis(self,image):
        barcodes = pyzbar.decode(image)
        self.quantity=len(barcodes)
        self.text = []
        self.polygon = []
        for barcode in barcodes:
            self.text.append(barcode.data)
            self.polygon.append(barcode.polygon)
            # 提取条形码的边界框的位置
            # 画出图像中条形码的边界框
            (x, y, w, h) = barcode.rect

            # 四个角的坐标
            (x0, y0) = barcode.polygon[0]
            (x1, y1) = barcode.polygon[1]
            (x2, y2) = barcode.polygon[2]
            (x3, y3) = barcode.polygon[3]
            # 在图上圈出四个角
            cv2.circle(image, (x0, y0), 2, (0, 255, 0), 8)
            text0 = "({},{})".format(x0, y0)
            cv2.putText(image, text0, (x0, y0 - 10), cv2.FONT_HERSHEY_SIMPLEX,
                        .5, (0, 0, 125), 2)
            cv2.circle(image, (x1, y1), 2, (0, 255, 0), 8)
            text1 = "({},{})".format(x1, y1)
            cv2.putText(image, text1, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX,
                        .5, (0, 0, 125), 2)
            cv2.circle(image, (x2, y2), 2, (0, 255, 0), 8)
            text2 = "({},{})".format(x2, y2)
            cv2.putText(image, text2, (x2, y2 - 10), cv2.FONT_HERSHEY_SIMPLEX,
                        .5, (0, 0, 125), 2)
            cv2.circle(image, (x3, y3), 2, (0, 255, 0), 8)
            text3 = "({},{})".format(x3, y3)
            cv2.putText(image, text3, (x3, y3 - 10), cv2.FONT_HERSHEY_SIMPLEX,
                        .5, (0, 0, 125), 2)

            # 二维码中心坐标
            cx = int(x + w / 2)
            cy = int(y + h / 2)
            cv2.circle(image, (cx, cy), 2, (0, 255, 0), 8)  # 做出中心坐标
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 2)  # 做出矩形
        return image

    #获取二维码的中心点
    def get_qrcenter(self):
        self.center_list=[]
        for polygon in self.polygon:
            print(self.polygon)
            x = (polygon[0].x + polygon[1].x + polygon[2].x +polygon[3].x) / 4
            y = (polygon[0].y + polygon[1].y + polygon[2].y +polygon[3].y) / 4
            center_point = Point(x,y)
            list=[center_point]
            self.center_list.append(list)
        return self.center_list

    #获取dx
    def get_dx(self):
        return self.dx

    #判断逻辑dx
    def qrlogic(self):
        n=self.quantity
        if n==0:
            # 脱磁
            print("脱磁")
        elif n==1:
            # 计算dx
            self.get_qrcenter()
            x1=self.center_list[0][0].x
            y1=self.center_list[0][0].y
            print("中心坐标:(x1,y2)=(",x1,",",y1,")")
            self.dx=x1-self.X0

        elif n==2:
            #计算两点间的连线,计算dx
            self.get_qrcenter()
            x1=self.center_list[0][0].x
            y1=self.center_list[0][0].y
            x2 = self.center_list[1][0].x
            y2=self.center_list[1][0].y
            if(x2!=x1):
                k=(y2-y1)/(x2-x1)
            else:
                k=0
            print("中心坐标:(x1,y1)=(",x1,",",y1,")",";(x2,y2)=(",x2,",",y2,")","k=",k)
            d1=x1-self.X0
            d2=x2-self.X0
            if(abs(d1)<=abs(d2)):
                self.dx=d1
            else:
                self.dx=d2

        elif n==3:
            #计算3点
            self.get_qrcenter()
            x1 = self.center_list[0][0].x
            y1 = self.center_list[0][0].y
            x2 = self.center_list[1][0].x
            y2 = self.center_list[1][0].y
            x3 = self.center_list[2][0].x
            y3 = self.center_list[2][0].y
            if (x2 != x1):
                k = (y2 - y1) / (x2 - x1)
            else:
                k = 0
            print("中心坐标:(x1,y1)=(", x1, ",", y1, ")", ";(x2,y2)=(", x2, ",", y2, ")",
                  ";(x3,y3)=(", x3, ",", y3, ")", "k=", k)
            d1 = x1 - self.X0
            d2 = x2 - self.X0
            d3 = x3 - self.X0
            if (abs(d1) <= abs(d2)):
                self.dx = d1
            else:
                self.dx = d2
            if (abs(self.dx) > abs(d3)):
                self.dx = d3

        elif n==4:
            #计算任意3点拟合连线的最小dx
            self.get_qrcenter()
            x1 = self.center_list[0][0].x
            y1 = self.center_list[0][0].y
            x2 = self.center_list[1][0].x
            y2 = self.center_list[1][0].y
            x3 = self.center_list[2][0].x
            y3 = self.center_list[2][0].y
            x4 = self.center_list[3][0].x
            y4 = self.center_list[3][0].y
            if (x2 != x1):
                k = (y2 - y1) / (x2 - x1)
            else:
                k = 0
            print("中心坐标:(x1,y1)=(", x1, ",", y1, ")", ";(x2,y2)=(", x2, ",", y2, ")",
                  ";(x3,y3)=(", x3, ",", y3, ")", ";(x4,y4)=(", x4, ",", y4, ")", "k=", k)
            d1 = x1 - self.X0
            d2 = x2 - self.X0
            d3 = x3 - self.X0
            d4 = x4 - self.X0
            if (abs(d1) <= abs(d2)):
                self.dx = d1
            else:
                self.dx = d2
            if (abs(self.dx) > abs(d3)):
                self.dx = d3
            if (abs(self.dx) > abs(d4)):
                self.dx = d4

        elif n>=5:
            print("满磁")

def test():
    qrcode=Qrcode()
    qrcode.init()
    while True:
        qrcode.detect()
        if qrcode.get_quantity()>=1:
            qrcode.qrlogic()
            print("count=",qrcode.quantity)
            print("dx=",qrcode.dx)
    qrcode.stop()
if __name__ == '__main__':
    test()
