# -*- coding:utf-8 -*-
#!/res/Pycharm/iot/iot_motor.py
# pip install pymodbus
# 双轮同步升速、保持高速、同步降速停车，当占空比很小时(电机转不动)需要把使能关掉
#@author：王琛 20190813
import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
from littlewhite.iot_hongge_M7088 import Honge_M7088
#从站地址0x25,波特率38400
# pwm1是右轮(6) # pwm2是左轮(7)
#继电器全亮是往前

class PwmMotor2():

    def __init__(self):
        return
    # 1.2 关键配置
    type="motor_pwm"
    BAUD_RATE = 38400
    usb_port = 'COM3'
    # usb_port = '/dev/ttyUSB1'
    slave_num = 0x25
    TIME_OUT = 0.1
    client = None
    en_on=0
    hongge=None
    last_left_pwm=0
    last_right_pwm=0


    # 1.2 带配置的构造函数
    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port = usb
        self.slave_num = slave_num
        # self.BAUD_RATE = baudrate
        return True

    def connect(self):
        if(self.client==None):
            self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',
                                   baudrate=self.BAUD_RATE, timeout=self.TIME_OUT)
        isconnected = self.client.connect()
        print("连接结果=", isconnected)

        # 泓格M7088,直接执行iot_motor的时候放开1和4句
        # self.hongge = Honge_M7088()
        ##self.hongge.config("/dev/ttyUSB1", 27, 38400)#!!与电机一路时不要放开
        ##self.hongge.config("COM3", 27, 38400)#!!与电机一路时不要放开
        # self.hongge.client = self.client

        return True

    MAX_MOTOR_SPEED_RPM = 3300  # rpm
    MAX_WHEEL_SPEED_RPM = 3300/40  # rpm
    MAX_WHEEL_SPEED_MPS = 0.43175
    MAX_PWM = 1000
    def pwm_to_rpm(self,pwm):
        x = pwm / self.MAX_PWM
        ratio =1# (0.5 * x + 2.5) / 3*1.1
        rpm = ratio*x  * self.MAX_MOTOR_SPEED_RPM
        return int(rpm)
    def rpm_to_pwm(self,rpm):
        y = rpm / self.MAX_MOTOR_SPEED_RPM
        # x = y / 2.75
        ratio = 1#(0.5 * x + 2.529) / 3*1.1
        pwm = y / ratio * self.MAX_PWM
        return int(pwm)
    def mps_to_rpm(self, mps):
        return mps/self.MAX_WHEEL_SPEED_MPS*self.MAX_MOTOR_SPEED_RPM
    def rpm_to_mps(self, rpm):
        #TODO:
        return

    def motor_one_set_pwm(self,pwm):#左轮
        print('last_left_pwm=', self.last_left_pwm)
        if (pwm == 0 ):
            if(abs(int(self.last_left_pwm)) ==0):
                pass
            else:
                self.ensure_do(4,0)
                self.hongge.set_abs_pwm(705,pwm,27)
                self.last_left_pwm=0
                self.en_on = 0
        elif (pwm < 0):
            if (self.last_left_pwm< 0):
                print('左轮last_left_pwm=', self.last_left_pwm, ', 不执行动作')
                pass
            else:
                self.ensure_do(3,0)
                self.ensure_do(4,1)
            if(int(pwm)==int(self.last_left_pwm)):
                pass
            else:
                self.hongge.set_abs_pwm(705, pwm, 27)
                self.last_left_pwm = pwm
                self.en_on=0
        else: #pwm>0
            if (self.last_left_pwm>0):
                pass
            else:
                self.ensure_do(3,1)
                self.ensure_do(4,1)
            if(int(pwm)==int(self.last_left_pwm)):
                pass
            else:
                self.hongge.set_abs_pwm(705, pwm, 27)
                self.last_left_pwm = pwm
        return
    def motor_two_set_pwm(self,pwm):#右轮
        print('last_right_pwm=', self.last_right_pwm)
        if (pwm == 0 ):
            if(abs(int(self.last_right_pwm)) ==0):
                pass
            else:
                self.ensure_do(1,0)
                self.hongge.set_abs_pwm(704, pwm, 27)
                self.last_right_pwm=0
                self.en_on = 0
        elif (pwm < 0):
            if (self.last_right_pwm< 0):
                print("右轮last_right_pwm=",self.last_right_pwm,",不执行动作")
                pass
            else:
                self.ensure_do(2,0)
                self.ensure_do(1,1)
            if(int(pwm)==int(self.last_right_pwm)):
                pass
            else:
                self.hongge.set_abs_pwm(704, pwm, 27)
                self.last_right_pwm = pwm
                self.en_on = 0
        else: #pwm>0
            if(self.last_right_pwm>0):
                pass
            else:
                self.ensure_do(2,1)
                self.ensure_do(1,1)
            if(int(pwm)==int(self.last_right_pwm)):
                pass
            else:
                time.sleep(0.01)
                self.hongge.set_abs_pwm(704, pwm, 27)
                self.last_right_pwm = pwm
        return

    def motor_go(self,pwm1,pwm2):
        print('last_left_pwm=', self.last_left_pwm)
        print('last_right_pwm=', self.last_right_pwm)
        if (int(pwm1) == int(self.last_left_pwm)):
            print("左轮速度与上次相同,不执行动作")
            pass
        else:
            self.hongge.set_abs_pwm(705, pwm1, 27)
            self.last_left_pwm = pwm1

        if (int(pwm2) == int(self.last_right_pwm)):
            print("右轮速度与上次相同,不执行动作")
            pass
        else:
            self.hongge.set_abs_pwm(704, pwm2, 27)
            self.last_right_pwm = pwm2
        if self.en_on==0:
            self.ensure_do(5,1)

    def stop(self):
        print('last_left_pwm=', self.last_left_pwm)
        print('last_right_pwm=', self.last_right_pwm)
        self.ensure_do(5,0)
        self.hongge.stop()
        self.last_left_pwm = 0
        self.last_right_pwm = 0
        return

    def set_speed_pwm(self, pwm1, pwm2):
        print('-->发送pwm1=', pwm1, ',pwm2=', pwm2)
        if pwm1>0 and pwm1*pwm2>0 :
            self.motor_go(pwm1,pwm2)
        elif pwm1==0 and pwm1==pwm2:
            self.stop()
        else:
            self.motor_one_set_pwm(pwm1) # 左轮 3.4号继电器控制
            self.motor_two_set_pwm(pwm2) # 右轮 1.2号继电器控制
        return

    def set_speed_rpm(self, rpm1, rpm2):
        self.motor_one_set_pwm(self.rpm_to_pwm(rpm1))
        self.motor_two_set_pwm(self.rpm_to_pwm(rpm2))
        return

    def set_speed_mps(self, mps1, mps2):
        #pwm1 = mps1/self.MAX_WHEEL_SPEED_MPS*self.MAX_MOTOR_SPEED_RPM * 1 # *2是倍速
        #pwm2 = mps2/self.MAX_WHEEL_SPEED_MPS*self.MAX_MOTOR_SPEED_RPM
        pwm1 = (mps1*self.MAX_PWM)/self.MAX_WHEEL_SPEED_MPS
        pwm2 = (mps2*self.MAX_PWM)/self.MAX_WHEEL_SPEED_MPS
        print("米每秒+++++++++++++>pwm=", pwm1, "pwm2", pwm2)
        # pwm1=000 #测试用
        # pwm2=000 #测试用
        self.set_speed_pwm(pwm1, pwm2)
        return
    def dispose(self):
        self.client.close()
        return

    #遥控器控制时调用以下方法
    def forword(self):
        self.hongge.set_abs_pwm(705, 500, 27)
        self.hongge.set_abs_pwm(704, 500, 27)
        self.ensure_do(5,1)
    def backword(self):
        self.ensure_do(5,1)
        self.ensure_do(2,0)
        self.ensure_do(3,0)
        self.hongge.set_abs_pwm(705, 500, 27)
        self.hongge.set_abs_pwm(704, 500, 27)
    def left(self):
        self.ensure_do(5,1)
        self.ensure_do(3,0)
        self.hongge.set_abs_pwm(705, 250, 27)
        self.hongge.set_abs_pwm(704, 250, 27)
    def right(self):
        self.ensure_do(5,1)
        self.ensure_do(2,0)
        self.hongge.set_abs_pwm(705, 250, 27)
        self.hongge.set_abs_pwm(704, 250, 27)

    count=0
    def ensure_do(self,chanel_num,param):
        self.count+=1
        try:
            rr=self.client.write_register(chanel_num,param,unit=self.slave_num).encode()
            print("ensure_do_rr=",rr)
            print("chanel_num=", chanel_num, ",param=", param, ",第", self.count, "次写入成功")
            self.count = 0
            if chanel_num==5 and param==1:
                self.en_on=1
            elif chanel_num==5 and param==0:
                self.en_on=0
            self.count = 0
        except Exception as ex:
            print("异常:",ex)
            if self.count<=3:
                print("chanel_num=", chanel_num, ",param=", param, ",第", self.count, "次写入失败")
                print("再次写入")
                self.ensure_do(chanel_num,param)
            else:
                self.count=0
                print("最终写入失败,急停")
                self.stop()
        return
def test():
    motor=PwmMotor2()
    motor.config("COM3", 0x25, 38400)
    motor.connect()
    while True:
        for i in range(1,21):
            motor.set_speed_pwm(i*50,i*50)
            time.sleep(0.1)
        for i in range(20,-1,-1):
            motor.set_speed_pwm(i*50,i*50)
            time.sleep(0.1)
        for i in range(1,21):
            motor.set_speed_pwm(-i*50,-i*50)
            time.sleep(0.1)
        for i in range(20,-1,-1):
            motor.set_speed_pwm(-i*50,-i*50)
            time.sleep(0.1)
    # while True:
    #     motor.set_speed_pwm(0,0)
    # motor.stop()

if __name__ == '__main__':
    # 测试电机加速、保持满速、降速、停车过程
    test()