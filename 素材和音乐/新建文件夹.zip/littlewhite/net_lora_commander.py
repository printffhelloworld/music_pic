# robot main init, robot
# 接收端
import  serial
import _thread
import queue

class LoraCommander():
    ser = None
    q = queue.Queue(maxsize=10)
    def __init__(self):
        super(LoraCommander, self).__init__()
        return
    def connect(self, start_name):
    #def connect(self):
        serialPort = "/dev/ttyUSB3"  # 串口
        baudRate = 9600  # 波特率
        try:
            self.ser = serial.Serial(serialPort, baudRate, timeout=0.5)
        except:
            print("未发现lora设备")
            return
        if self.ser.is_open:
            print("端口连接成功")
            self.start_listen()
            # while 1:
            #     pass
            # while True:
            #     str_msg = input("请输入要发送信息：")
            #     if str_msg != "":
            #         self.send(str_msg)
        else:
            print("端口连接失败")
        return

    def start_listen(self):
        try:
            _thread.start_new_thread(self.listen,(1,))
        except:
            print("开启线程失败")

        return

    # def send(self,msg):
    #     self.ser.write(msg.encode("utf-8"))
    #     return

    def listen(self,a):
        print("==========================lora开始监听==========================")
        while True:
            print("==========================lora循环监听中==========================")
            data = self.ser.read(30)
            print(data)
            receiveStr = bytes.decode(data)
            if data != b'':
                self.q.put(receiveStr, block=True, timeout=None)
                print("消息队列长度：", self.q.qsize())
                print("receive : ", receiveStr)
            if (self.q.full()):
                while (not self.q.empty()):
                    print("从消息队列中取消息：" + self.q.get())
        print("==========================lora监听结束==========================")
        return True

def test():
    loracommand = LoraCommander()
    loracommand.connect()
    return  True

if __name__ == '__main__':
    # global q
    # q = queue.Queue(maxsize=10)
    # while True:
    #     str_msg = input("请输入要发送信息：")
    #     if str_msg != "":
    #         loracommand.send(str_msg)
    test()
    while True:
        pass