# -*- coding:utf-8 -*-
# !/res/Pycharm/shoeagv/iot_radar.py
# 超声避障,传感器每100ms发送一次
# 格式：0xF5 LA LB LC LD RA RB RC RD CHKADD, 中间8个值是避障读数, CHKADD为LA～RD 8个数值加和保留后8bit
import time
import serial


class Radar:
    serialport = ''
    baudrate = 0
    timeout = 0.005

    def __init__(self, serialport, baudrate, timeout):
        self.serialport = serialport
        self.baudrate = baudrate
        self.timeout = timeout
        print('__init__')

    def init(self):
        ser = serial.Serial(self.serialport, self.baudrate)
        return ser

    radar_data = ''
    def read_all(self, ser):
        if ser.is_open:
            self.radar_data = self.read_radar(ser)
            print('-->读取到的超声避障数据data=', self.radar_data)
        else:
            print('超声避障串口连接失败')
        return self.radar_data

    # 读取避障
    def read_radar(self, ser):
        result_temp = ''
        result_temp = result_temp.encode('utf-8')

        n = ser.inWaiting()  # 获取接收到的数据长度
        print('-->iot_radar.read_data方法中,获取到接收字节码数量 n=', n)

        result = ''
        if n:
            # 读取数据并将数据存入data
            result_temp += ser.read(n)
            if n == 10:
                for x in result_temp:
                    y = '{:02x}'.format(x)  # 10进制转16进制,不足2位则高位补0
                    result += (y + ' ')
                return result.strip()
            else :
                if n > 10:
                # 数据有重复部分, 需要截取
                    print('读取超声避障字节数量不正常,n=', n, ', 不处理, 返回空字符串')
                    for x in result_temp:
                        y = '{:02x}'.format(x)  # 10进制转16进制,不足2位则高位补0
                        result += (y + ' ')
                    print('读取的数据=', result.strip())
                    index_start = result.index('f5')
                    # 向后截取8组数据
                    if len(result) >= (index_start + 26):
                        result = result[index_start + 3:index_start + 26]
                        print('超过10,,截取数据=', result, ', len=', len(result))# len=23?
                    return result.strip()
        else:
            # n=0, 没有读取到数据
            print('n=0, 未读取到超声避障数据')
        return result

def radar_after_read(radar_data):
    # 处理读数, 返回实际距离值
    ear_this_radar_id = []
    # radar_data格式:'F5 80 80 80 80 80 80 08 7F 87',中间8个值是避障数据
    if radar_data != '':
        radar_values = radar_data[3:26].strip().split(' ')
        for x in radar_values:
            # print(x, ', len(x)=', len(x), ', 10进制值=', int(x, 16))
            y = int(x, 16)
            # y值说明:实际距离为读数* 5, 距离为30cm-250cm间, 单位:cm (0x01:盲区0-30cm内  0x7F:250cm内无障碍物  0x80:无探头)
            ear_this_radar_id.append(y * 5)
        print('超声避障数值=', ear_this_radar_id)


def test():
    r = Radar('/dev/ttyUSB0', 9600, 0.1)
    ser = r.init()
    while True:
        radar_data = r.read_all(ser)
        radar_after_read(radar_data)
        time.sleep(0.1) # 雷达传感器100ms上传一次读数

if __name__ == "__main__":
    test()
