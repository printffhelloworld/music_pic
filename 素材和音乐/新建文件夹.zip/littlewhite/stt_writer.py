# -*- coding: utf-8 -*-

class SttWriter():
    def write(self,string):
        f = open("demo.txt", "wb")
        f.write(string.encode("gbk"))
        # print("已写入。")
        f.close()
        return True

def test():
    sttWriter=SttWriter()
    sttWriter.write("垃圾分类大妈:你是个什么垃圾?")

if __name__ == '__main__':
    test()