# -*- coding:utf-8 -*-
# import RPi.GPIO as GPIO
# GPIO.setmode(GPIO.BOARD)
# GPIO.setup(37,GPIO.IN)
# while True:
#     voltage=GPIO.input(37)
#     print(voltage)
#!/usr/local/homebrew/bin/python3
import serial
import sys
import time
import struct
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
#import logging

#logging.basicConfig()
#log = logging.getLogger()
#log.setLevel(logging.DEBUG)

# if len(sys.argv)<2:
#     print(sys.argv[0]+" /dev/xxxx");
#     exit();

client= ModbusClient(method = "rtu", port="COM3",stopbits = 1, bytesize = 8, parity = 'N',baudrate= 9600)#port=sys.argv[1]
iscom=client.connect()
print(iscom)
i = 0;
while True:
    #rr = client.read_holding_registers(0x01,1,unit=0x01).encode();
    #print(rr)
    rr = client.read_holding_registers(0x05,1,unit=0x01).encode();
    #print(rr)
    out = struct.unpack(">bh",rr)
    print("out=",out)
    print(out[1]/4096*10);
    #rr = client.write_register(0x02, 0x10, unit=0x01).encode()
    #print(rr)
    time.sleep(0.5);
    #i = i^1;
print(rr);
