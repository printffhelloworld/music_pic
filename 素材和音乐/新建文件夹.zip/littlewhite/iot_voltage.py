#!/res/Pycharm/shoeagv/iot_voltage.py
# pip install pymodbus
# 电压采集
from pymodbus.client.sync import ModbusSerialClient as ModbusClient


class Voltage:

    # 1.2 关键配置
    baudrate = 38400
    usb_port = '/dev/ttyUSB1'
    slave_id = 0x05
    TIME_OUT = 0.1
    client = None

    def __init__(self, usb_port, baudrate, slave_id):
        self.usb_port = usb_port
        self.baudrate = baudrate
        self.slave_id = slave_id
        return

    def connect(self):
        if(self.client==None):
            self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',
                                       baudrate=self.baudrate, timeout=self.TIME_OUT)
        isconnected = self.client.connect()
        print("读取电压:Modbus连接结果=", isconnected)
        return True

    def read_voltage(self):
        rr = self.client.read_holding_registers(0x05, 2, unit=self.slave_id).encode()
        y = ''
        for x in rr:
            #print(x)
            y += '{:02x}'.format(x)
        # 电压读数4 7 100 0 0
        # 0407640000    0764(hex)=1892(dec)   04077e0000
        data_str = y[2:6]
        result = int(data_str, 16) * 10 / 4095 * 5 * 1.0675  # 原始读数计算结果为23.4188,实际为25.0,电压模块显示25.6,比例系数25/23.4188=1.0675
        #print('data_str=', data_str, ', 原始读数=', int(data_str, 16), ', 最终结果=', result)
        return result

def test():

    # 读取电压值
    voltage=Voltage("/dev/ttyUSB1", 38400, 0x05)
    voltage.connect()
    result = voltage.read_voltage()
    print('读取电压值=', result)


if __name__ == '__main__':
    test()