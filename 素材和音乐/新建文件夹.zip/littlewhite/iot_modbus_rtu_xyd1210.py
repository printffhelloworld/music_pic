#!/res/Pycharm/iot/iot_modbus_rtu_xyd1210.py
## pip install pyserial
## pip install pymodbus
# @author: 王琛
# ver 0.2 .2019.0623
import serial
import sys
import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
class ModbusRtuXyd1210():
    # 1 构造函数
    #1.1 空构造函数
    def __init__(self):

        return

    # 1.2 关键配置
    BAUD_RATE=19200
    usb_port='COM8'
    slave_num=21
    TIME_OUT = 0.04
    # 1.2 带配置的构造函数
    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port=usb
        self.slave_num=slave_num

        return True

    # 1.3 载入配置
    channel_list = [{'id': '1', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num': 21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 0,
                     'minval': '0', 'maxval': '1', "dr":1, "dw":1},
                    {'id': '2', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num': 21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 1,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '3', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num': 21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 2,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '4', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num': 21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 3,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '5', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num': 21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 4,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '6', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num': 21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 5,
                     'minval': '0', 'maxval': '1', "dr":1, "dw":1},
                    {'id': '7', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 6,
                     'minval': '0', 'maxval': '1', "dr":1, "dw":1},
                    {'id': '8', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 7,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '9', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 8,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '10', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':21, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 9,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '11', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 0,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '12', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 1,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '13', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 2,
                     'minval': '0', 'maxval': '1', "dr":1, "dw":1},
                    {'id': '14', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 3,
                     'minval': '0', 'maxval': '1', "dr":1, "dw":1},
                    {'id': '15', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 4,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '16', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 5,
                     'minval': '0', 'maxval': '1', "dr":1, "dw":1},
                    {'id': '17', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 6,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '18', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 7,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '19', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 8,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '20', 'equip': '机器人', '位置': '-', 'title': '-',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM8',
                     'slave_num':22, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Coils', 'R': '1', 'W': '1', 'address': 9,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1}
                    ]

    # def config_by_channel(self, channel_list):
    #     self.usb = channel_list[0]['USB']
    #     self.SLAVE_NUM = channel_list[1]['slave_num']
    #     return

    # 2 init
    def init(self):
        return True
    # 2.1 connect
    client=None
    def connect(self):
        self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N', baudrate=self.BAUD_RATE,timeout=self.TIME_OUT)
        isconnectre=self.client.connect()
        print("连接结果=",isconnectre)
        return True
    #2.2 检查
    def test_connect(self):
        return True
    #2.3 connect异常处理
    def reconnect(self):
        return True
    #2.4 清理单个资源
    def dispose_connect(self):
        return True
    #2.5 全局清理资源
    def dispose(self):
        # 清理所有的被占用的 资源
        return
    # 3. 主工作内容
    # 3.1 定义通道, 成员变量(m_, 私有)
    channel_num=12


    #slave_num是unit

    #3.2 快速访问
    # public
    X1 = channel_list[0]
    def read_X1 (self):
        x = self.client.read_discrete_inputs(0, 1, unit=21).encode()
        if(x == b'\x01\x00'):
            return 1
        else:
            return 0
    def read_X2 (self):
        x = self.client.read_discrete_inputs(1, 1, unit=21).encode()
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0
    def read_X3 (self):
        x = self.client.read_discrete_inputs(2, 1, unit=21).encode()
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0
    #上面没注释的是杨智富写的
    #下面有注释的是王琛写的
    #背在最下面
    def read_X4 (self):
        x = self.client.read_discrete_inputs(4, 1, unit=21).encode()
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0
    # 背在最下面靠上一点
    def read_X5 (self):
        x = self.client.read_discrete_inputs(5, 1, unit=21).encode()
        # return x
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0

    # 背在最上面靠下一点
    def read_X6 (self):
        x = self.client.read_discrete_inputs(6, 1, unit=21).encode()
        # return x
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0
    # 背在最上面
    def read_X7 (self):
        x = self.client.read_discrete_inputs(7, 1, unit=21).encode()
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0
    #手臂伸出去
    def read_X8 (self):
        x = self.client.read_discrete_inputs(7, 1, unit=22).encode()
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0
    #手臂缩回来
    def read_X9 (self):
        x = self.client.read_discrete_inputs(6, 1, unit=22).encode()
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0
    #处于遥控器状态
    def read_X10 (self):
        x = self.client.read_discrete_inputs(1, 1, unit=21).encode()
        if (x == b'\x01\x00'):
            return 1
        else:
            return 0









    X2 = channel_list[1]
    X3 = channel_list[2]
    X4 = channel_list[3]
    # .....

    #3.3 读取全部
    def read_all(self):
        for ch in self.channel_list:
            self.read_one(ch)
        # TODO: filter, 对于R=0的不读
        # TODO: 对于连续多个地址需要读的, 可以批量读, 然后在打包(因为CPU比总线快得多)
        return True
    def read_one(self,ch):
        print(ch['slave_num'],":",ch['address'])
        rr = self.client.read_coils(ch['address'], 1, unit=21).encode()
        #ch['dr'] = rr
        print("读rr=", rr)
        return True


    #3.4 写入全部
    def write_all(self,param):
        for ch in self.channel_list:
            self.write_one(ch,param)
        return True
    # 2019-0622 测试有效
    def write_one(self,ch,param):
        rr = self.client.write_coil(ch['address'], param, unit=ch['slave_num'])#.encode()
        print("写rr=", rr)
        return True
    # 4 辅助功能
    # 4.1 前后处理
    def before_read(self):
        return True
    def after_read(self):
        return True
    def before_write(self):
        return True
    def after_write(self):
        return True

    def write_Y0(self,param):
        rr = self.client.write_coil(0, param, unit=21)#.encode()
        # print("写rr=", rr)
        return True

    def write_Y1(self,param):
        rr = self.client.write_coil(1, param, unit=21)#.encode()
        # print("写rr=", rr)
        return True
    #Y2=1 顶升升
    def write_Y2(self,param):
        rr = self.client.write_coil(2, param, unit=21)#.encode()
        print("写rr=", rr)
        return True

    # Y3=1 顶升降
    def write_Y3(self,param):
        rr = self.client.write_coil(3, param, unit=21)#.encode()
        print("写rr=", rr)
        return True
    # Y4=1 手臂伸
    def write_Y4(self,param):
        rr = self.client.write_coil(5, param, unit=22)#.encode()
        print("写rr=", rr)
        return True
    # Y5=1 手臂缩
    def write_Y5(self,param):
        rr = self.client.write_coil(6, param, unit=22)#.encode()
        print("写rr=", rr)
        return True


def test():
    debug=1
    rtu=ModbusRtuXyd1210()
    rtu.config('COM8',21)
    rtu.connect()

    # rtu.write_Y0(1)
    # rtu.write_Y1(0)
    #
    #
    # while True:
    #     ch1 = rtu.read_X1()
    #     ch2 = rtu.read_X2()
    #     ch3 = rtu.read_X3()
    #     print(ch1,ch2,ch3)
    #     if(ch1 == b'\x01\xed'):
    #         rtu.write_Y0(0)
    #         rtu.write_Y1(0)
    #         break

    # rtu.write_Y2(1)
    # rtu.write_Y3(0)
    # time.sleep(5)
    # rtu.write_Y2(0)
    # rtu.write_Y3(0)

    a = rtu.read_X5()
    b = rtu.read_X6()
    print(a,b)

    # time.sleep(5)

# print(result,":")
    return True

if (__name__=="__main__"):
        test()