# -*- coding:utf-8 -*-
# !/res/Pycharm/shoeagv/iot_rfid_rc522.py
# pip install pyserial
# RFID读写方法
import time
import serial


class Rfid:
    # __CONFIG__={
    # "name":"RFID-RC522",
    # "code": 522,
    # "supplier":"http://"
    # price:3.5
    # width:0.05,
    # length:0.08,
    # holes=4,
    # holes_config=[[0.015, 0.015, 0.005],[0.065, 0.015, 0.005],[0.01, 0.07, 0.005],[0.07, 0.07, 0.005]]
    # pins=8,
    # pins_name=[["SDA"],["SCK"][][][][][][]]
    # pins_config=[[],[][][][][][][]]
    # channnels=2,
    # channels_config=[[],[]]
    # }

    channel_list = [{'id': '1', 'equip': '机器人', '位置': '-', 'title': 'RFID卡号',
                     'code': '-', 'num': '1', 'connect': 'serialport', 'remark': '-',
                     'device_id': '1', 'protocol': 'serialport', 'USB': 'COM3',
                     'slave_num':'-', 'channel_code': 'J1', 'ch_address': '-',
                     'type': '-', 'R': '1', 'W': '1', 'address': 1,
                     'minval': '0', 'maxval': '65535', "dr": "1", "dw": "1"}]

    count = 0
    machine_guid="123-123-1412"
    guid = "moobot.iot.rfid.rc522:"+machine_guid + ":0000"

    # realtime_data:存储原始读数
    # realtime_raw_data = ''
    # realtime_rfid：存储rfid卡号xx xx xx xx xx xx
    # realtime_rfid = ''
    # dr = []

    serialport = ''
    baudrate = 0
    timeout = 0.005

    def __init__(self, serialport, baudrate, timeout):
        self.serialport = serialport
        self.baudrate = baudrate
        self.timeout = timeout
        print("rfid 初始化,设置端口号=", self.serialport, ', 波特率=', self.baudrate, ', 超时时间=', self.timeout)

    def init(self):
        ser = serial.Serial(self.serialport, self.baudrate)
        # ser = serial.Serial(self.serialport, self.baudrate, timeout=self.timeout)
        return ser

    def read_all(self, ser):
        if ser.is_open:
            # t1 = time.time()
            # print('rfid 读取前, time1=', t1)
            # self.realtime_rfid = self.read_rfid(ser)
            self.channel_list[0]['dr'] = self.read_rfid(ser)
            # t2 = time.time()
            # print('-->读取到的rfid, time2=', t2, ', 时间差=', (t2 - t1))
        else:
            print('rfid串口连接失败')
            # TODO 处理 杨志成

    def dispose(self):
        # TODO 断开串口连接
        return

    def selftest(self):
        # TODO 自检
        return False

    def write_all(self):
        return False

    # 读取RFID卡号
    def read_rfid(self, ser):
        result_temp = ''
        result_temp = result_temp.encode('utf-8')

        n = ser.inWaiting()  # 获取接收到的数据长度
        # print('-->read_data方法中,获取到接收字节码数量 n=', n)

        result = ''
        # 偶尔可能会读取到2遍的数据(28个字节),过滤这种情况
        if n:
            # 读取数据并将数据存入data
            result_temp += ser.read(n)
            if n == 14:
                z = ''
                for x in result_temp:
                    y = '{:02x}'.format(x)  # 10进制转16进制,不足2位则高位补0   20 00 00 08 04 00 00 00 34 42 62 96 71 03
                    z += (y + ' ')  # str  z=20 00 00 08 04 00 00 00 34 42 62 96 71 03
                print(z, 'type(z)=', type(z), 'len(z)=', len(z))

                # 记录读取的RFID原始数据
                # self.realtime_raw_data = z

                # 截取RFID卡号
                result = z[24:].strip()
                print('result=', result, ', len(result)=', len(result))  #  97 ce b5 3f 20 03, len=17
            else:
                if n >= 28:
                    z = ''
                    for x in result_temp:
                        y = '{:02x}'.format(x)  # 10进制转16进制,不足2位则高位补0   20 00 00 08 04 00 00 00 34 42 62 96 71 03
                        z += (y + ' ')  # str  z=20 00 00 08 04 00 00 00 34 42 62 96 71 03
                    print('警告:n=', n, ', 接收到rfid=', z)
                    last_str_index = z.index("03")
                    if last_str_index >= 15:
                        result = z[last_str_index - 15: last_str_index + 2].strip()
                        # print('向前获取rfid=',result)
                    else:
                        result = z[last_str_index + 27: last_str_index + 44].strip()
                        # print('向后获取rfid=', result)

                    # self.realtime_rfid = result
        else:
            # n=0, 没有读取到数据
            print('n=0, 未读取到RFID数据')
            # self.realtime_rfid = ''
        return result

    def write_data(self, block_num, block_data):
        #TODO
        return False

    # def get_realtime_rfid(self):
        # print('[get_realtime_rfid] -->', self.realtime_raw_data, '--->', self.realtime_rfid)
        # return self.realtime_rfid


def test():
    r = Rfid('/dev/ttyUSB2', 9600, 0.5)
    ser = r.init()
    while True:
        r.read_all(ser)
        time.sleep(0.05) # 读取rfid必须要休眠时间, 否则读不到数据,超过50ms时,可能出现多次数据堆积的问题


if __name__ == '__main__':
    test()

    # data = '20 00 00 08 04 00 00 00 34 42 62 96 71 03 20 00 00 08 04 00 00 00 34 42 62 96 71 03'
    # last_str_index = data.index("03")
    # print('last_str_index=', last_str_index)
    # if last_str_index >= 15:
    #     rfid1 = data[last_str_index - 15: last_str_index + 2]
    #     print('rfid1=',rfid1)
    # else:
    #     rfid2 = data[last_str_index + 27: last_str_index + 44]
    #     print('rfid2=', rfid2)
