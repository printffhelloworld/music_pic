# -*- coding:utf-8 -*-
#!/res/Pycharm/iot/iot_motor_motec_dc.py
# @author: 王琛
# ver 0.0.1 .2019.0622
import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
class MotecDcMotor():
    # 1 构造函数
    # 1.1 空构造函数
    def __init__(self):
        return
    # 1.2 关键配置
    BAUD_RATE = 115200
    # usb_port = 'COM8'
    usb_port = "COM3"
    slave_num =11
    #TIME_OUT=0.005
    TIME_OUT=0.2
    client = None
    EN_MODE_ON_LEFT=False
    EN_MODE_ON_RIGHT=False
    last_left_mps=0
    last_right_mps=0
    channel_list = [{'id': '1', 'equip': '机器人', '位置': '-', 'title': '左电机',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM3',
                     'slave_num': 11, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Holding_Register', 'R': '1', 'W': '1', 'address': 1,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1},
                    {'id': '2', 'equip': '机器人', '位置': '-', 'title': '右电机',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM3',
                     'slave_num': 12, 'channel_code': 'J1', 'ch_address': '-',
                     'type': 'Holding_Register', 'R': '1', 'W': '1', 'address': 1,
                     'minval': '0', 'maxval': '1', "dr": 1, "dw": 1}]

    # 1.2 带配置的构造函数
    def config(self, usb, slave_num, baudrate=BAUD_RATE):
        self.usb_port = usb
        self.slave_num = slave_num
        return True

    # 2 init
    def init(self):
        self.connect()
        # self.set_netmode_on()
        # self.set_mode_speed()
        # #self.set_speed(300)
        # self.set_en_on()
        return True

    # 2.1 connect

    def connect(self):
        self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N',\
                                       baudrate=self.BAUD_RATE, timeout=self.TIME_OUT)
        isconnected = self.client.connect()
        print('电机是否连接上=', isconnected)
        return True

    # 设置网络模式
    def set_netmode_on(self,my_slave_num):

        rr = self.client.write_register(0x0024, 0x0000, unit=my_slave_num).encode()#unit是从站地址self.slave_num
        print("设置网络模式",time.time(),"set_netmode_on",rr)
        return True

    # 设置速度模式
    def set_mode_speed(self,my_slave_num):
        rr = self.client.write_register(0x0025, 0x0001, unit=my_slave_num).encode()#self.slave_num)
        print("设置速度模式",time.time(),"set_mode_speed",rr)
        return True

    # 设置速度 单位:转/秒,正值正转负值反转
    def set_speed(self,my_slave_num,param):
        if param<0:
            param_speed=0xFFFF+param
        else:
            param_speed=param
        print("设置速度=",param_speed)
        rr = self.client.write_register(0x00AE, param_speed, unit=my_slave_num).encode()#self.slave_num)
        print(time.time(),"set_speed",rr)
        return True

    # 走
    def set_en_on(self,my_slave_num):
        rr = self.client.write_register(0x0028, 0x0001, unit=my_slave_num).encode()#self.slave_num)
        print("走",time.time(),"set_en_on",rr)
        return True

    # 停
    def set_en_off(self,my_slave_num):
        rr = self.client.write_register(0x0028, 0x0000, unit=my_slave_num).encode()#self.slave_num)
        print("停",time.time(),"set_en_off",rr)
        return True

    # 获取速度
    def get_speed(self,my_slave_num):
        rr = self.client.read_holding_registers(0x00AF, 0x0001, unit=my_slave_num).encode()#self.slave_num)
        print("获取速度",time.time(),"get_speed",rr)
        return True
    #开启en和速度模式
    def set_en_mode_on(self,my_slave_num):
        self.set_en_on(my_slave_num)
        self.set_netmode_on(my_slave_num)
        self.set_mode_speed(my_slave_num)
        if my_slave_num==11:
            self.EN_MODE_ON_LEFT = True
        elif my_slave_num==12:
            self.EN_MODE_ON_RIGHT = True

    def set_left_rpm(self,rpm,my_slave_num=11):
        if self.EN_MODE_ON_LEFT==False:
            self.set_en_mode_on(my_slave_num)
        self.set_speed(my_slave_num,int(rpm))
        return

    def set_right_rpm(self,rpm,my_slave_num=12):
        if self.EN_MODE_ON_RIGHT==False:
            self.set_en_mode_on(my_slave_num)
        self.set_speed(my_slave_num,int(rpm))
        return

    def set_speed_mps(self,nose_target_speed1, nose_target_speed2):
        self.last_left_mps = nose_target_speed1
        self.last_right_mps = nose_target_speed2
        print("左轮速度设置为:",self.last_left_mps,";右轮速度设置为:",self.last_right_mps)
        #将mps转换为rpm后
        self.set_speed_rpm(nose_target_speed1,nose_target_speed2)


    def set_speed_rpm(self,rpm1, rpm2):
        if rpm1==0 and rpm1 == rpm2:
            self.stop()
        else:
            self.set_left_rpm(rpm1)
            self.set_right_rpm(rpm2)

    def stop(self):
        # self.set_speed_rpm(0,0)
        self.set_speed(11, 0)
        self.set_speed(12, 0)
        self.EN_MODE_ON_LEFT=False
        self.EN_MODE_ON_RIGHT=False
        self.last_left_mps = 0
        self.last_right_mps = 0
        print("stop")
        return
	#遥控器控制时调用以下方法
    def forword(self):
        self.set_speed_rpm(300,300)
    def backword(self):
        self.set_speed_rpm(-300, -300)
    def left(self):
        self.set_speed_rpm(-500, 500)
    def right(self):
        self.set_speed_rpm(500,-500)



def toHex(num):
    """
    :type num: int
    :rtype: str
    """
    chaDic = {10: 'a', 11: 'b', 12: 'c', 13: 'd', 14: 'e', 15: 'f'}
    hexStr = ""

    if num < 0:
        num = num + 2 ** 32
    while num >= 16:
        digit = num % 16
        hexStr = chaDic.get(digit, str(digit)) + hexStr
        num //= 16
    hexStr = chaDic.get(num, str(num)) + hexStr
    return hexStr

def test():
    #0B0600AE0010E94D
    #0B0600AE0000E881
    motor = MotecDcMotor()
    motor.config("COM3", 11)
    motor.init()
    motor.set_speed_mps(10,10)
    time.sleep(5)
    motor.stop()
    #while True:
        # for i in range(1,2):
        #     motor.set_speed(i*50)
        #     motor.get_speed()
        #     time.sleep(1)
        #for i in range(1,50):
        #    t1=time.time()
        #    motor.set_left_rpm(1000)
        #    t2 = time.time()
        #    print("左电机写一次速度的时间△t=",(t2-t1)*1000,"毫秒")
        #    motor.get_speed(11)
        #    t3 = time.time()
        #    print("左电机读一次速度的时间△t=", (t3 - t2) * 1000, "毫秒")
        #    motor.set_right_rpm(1000)
        #    t4 = time.time()
        #    print("右电机写一次速度的时间△t=", (t4 - t3) * 1000, "毫秒")
        #    motor.get_speed(12)
        #    t5 = time.time()
        #    print("右电机读一次速度的时间△t=", (t5 - t4) * 1000, "毫秒")
        #    time.sleep(0.1)
        # for i in range(1,5):
        #     for i in range(20, -20, -39):
        #         motor.set_speed(i * 50)
        #         time.sleep(0.1)
        #         motor.get_speed()

       # motor.set_en_off()
        #time.sleep(1)

    return True

if (__name__ == "__main__"):
    test()