# -*- coding:utf-8 -*-
from socketserver import BaseRequestHandler, TCPServer
import _thread
from threading import Thread
import socket
import queue
from socketserver import BaseRequestHandler, TCPServer
import iot_motor_motec_dc as motor
import time
class TcpCommander():
    serversocket = None
    autoMode = True
    feet = None
    target_clients = ("192.168.1.4",20000,)
    # target_clients = ("127.0.0.1",20000,)
    main_state = 0
    voltage = 0
    is_charging = False
    last_rfid=""
    this_rfid=""
    q_len=0
    x = 0
    y = 0
    w = 0
    # ser = None
    # target_clients = ["127.0.0.1"]
    q = queue.Queue(maxsize=10)
    def __init__(self):
        super(TcpCommander, self).__init__()
        return

    def connect(self,b):
        self.serversocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.serversocket.bind(self.target_clients)
        self.serversocket.listen(5)
        self.start_listen()
        # serv = TCPServer(('', 20000), TcpCommander.start_listen())
        return

    def start_listen(self):
        print('The server is ready to receive')
        try:
            _thread.start_new_thread(self.listen,(1,))
        except:
            print("开启线程失败")

        return

    def send(self,msg):
        # self.serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # self.serversocket.bind(self.target_clients)
        # self.serversocket.send(msg.encode("utf-8"))
        return

    def listen(self,a):
        while 1:
            connectionSocket, addr = self.serversocket.accept()
            sentence = connectionSocket.recv(1024*4)
            if sentence != b'':
                recvstr = sentence.decode("utf-8")
                if recvstr == "ykqq":
                    print("向前")
                    self.autoMode=False
                    self.q.empty()
                    self.feet.forword()
                elif recvstr =="ykqh":
                    print("向后")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.backword()
                elif recvstr =="ykqz":
                    print("向左")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.left()
                elif recvstr =="ykqy":
                    print("向右")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.right()
                elif recvstr =="ykqt":
                    print("停")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.stop()
                elif recvstr =="ykqdsq":
                    print("升")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.lift_up()
                    time.sleep(7)
                elif recvstr =="ykqdsj":
                    print("降")
                    self.autoMode = False
                    self.q.empty()
                    self.feet.lift_down()
                    time.sleep(7)
                elif recvstr == "qingqiuzhuangtaishuju":
                    # 下两行返回状态
                    print("请求状态数据")
                    state_packeg={"main_state":str(self.main_state),"voltage":str(self.voltage),
					"is_charging":str(self.is_charging),"x":str(self.x),"y":str(self.y),
					"w":str(self.w),"last_rfid":str(self.last_rfid),"this_rfid":str(self.this_rfid)
                    ,"q_len": str(self.q_len)}
                    ret_msg = (str(state_packeg).encode("utf-8"))
                    print("返回的状态数据",ret_msg)
                    connectionSocket.send(ret_msg)
                else:
                    self.autoMode = True
                    self.q.put(recvstr, block=True, timeout=None)
                    print("消息队列长度：", self.q.qsize())
                    print("receive : ", recvstr)
        return

if __name__ == '__main__':
    tcp = TcpCommander()
    tcp.connect(2)
    while True:
        pass