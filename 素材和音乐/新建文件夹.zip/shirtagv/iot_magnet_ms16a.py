# -*- coding:utf-8 -*-
# !/res/Pycharm/iot/iot_magnet_ms16a.py
# 巡磁传感器读写方法

# pip install pymodbus

from pymodbus.client.sync import ModbusSerialClient as ModbusClient
import time
#import iot
# import iot.iot_params

class Magnet():
    def __init__(self):
        return


    # 读取到的实时巡磁数据
    realtime_magnet = ''

    usb_port="COM3"
    slave_id="0x03"
    BAUD_RATE = 115200
    time_out=0.5
    channel_id=1
    bit_count=16
    isconnected=False
    client=None
    funct="read_holding_registers"

    dr=[]
    dw=[]
    channel_list = [{'id': '1', 'equip': '机器人', '位置': '-', 'title': '前巡磁',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'ttyUSB0',
                     'slave_num': 3, 'channel_code': 'J1', 'ch_address': '1',
                     'type': 'holing_register', 'R': '1', 'W': '1', 'address': 1,
                     'minval': '0', 'maxval': '1', "dr": "1", "dw": "1"},
                    {'id': '2', 'equip': '机器人', '位置': '-', 'title': '后巡磁',
                     'code': '-', 'num': '1', 'connect': 'Modbus', 'remark': '-',
                     'device_id': '1', 'protocol': 'modbus', 'USB': 'COM9',
                     'slave_num': 4, 'channel_code': 'J2', 'ch_address': '1',
                     'type': 'holing_register', 'R': '1', 'W': '1', 'address': 1,
                     'minval': '0', 'maxval': '1', "dr": "1", "dw": "1"}]
    def __init__(self):
        print("巡磁 初始化")

    def init(self):
        # Modbus连接巡磁传感器并读取传感器数值,返回以车头向前方向看从左到右16bit字符串
        # TODO 开线程获取
        self.client = ModbusClient(method="rtu", port=self.usb_port, stopbits=1, bytesize=8, parity='N', baudrate=self.BAUD_RATE,
                              strict=False,timeout=self.time_out)
        self.isconnected = self.client.connect()
        print('巡磁是否连接上=', self.isconnected)
        return True

    def read_all(self):
        for ch in self.channel_list:
            #try:
                self.read_one(ch)
           # except:
               # print('读取单个巡磁发生异常')
        return True

    def read_one(self,ch):
            try:
                t1=time.time()
                print("读一个寻磁开始时间=",t1)
                print("读取的slave_num=",ch['slave_num'], ', time1=', time.time())
                raw_bytes = self.client.read_holding_registers(1, 1, unit=ch['slave_num'])#.encode() #unit是从站地址 # b'\x02\x00\x00'
                print('读取到字节码=', raw_bytes.encode(), ', time2=', time.time())
                y = ''
                for x in raw_bytes.encode():
                    y += '{:08b}'.format(x)  # 8位2进制
                self.realtime_magnet = y[8:].strip()
                ch['dr']=y[8:].strip()
                print('读取到的巡磁数据=', self.realtime_magnet)
                t2=time.time()
                print("读一个寻磁结束时间=", t2)
                print("一个寻磁时间差△t=",(t2-t1)*1000,"毫秒")
                # print('读取到的巡磁数据=', y,"ch['dr']=",ch['dr'])
            except Exception as ex:
                print('读取巡磁数据发生异常 ', ex)



    def get_int_value(self, int_str):
        return int(int_str, 2)

        # 获取巡磁序号和巡磁点数量

    def get_magnet_index_count(self, magnet_int):
        v = 0
        count = 0
        for i in range(1, 17, 1):
            if ((magnet_int >> (i - 1)) % 2) == 1:
                v += i
                count += 1
        if count == 0:
            return v, count
        return v / count, count

def test():
    mag = Magnet()
    mag.init()
    while True:
        mag.read_all()
        a = mag.get_int_value(mag.realtime_magnet)
        b = mag.get_magnet_index_count(a)
        print(b)

    return

if __name__ == "__main__":
    test()
