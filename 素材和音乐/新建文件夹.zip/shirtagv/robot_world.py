#! /moobot/res/slenderagv/robot_world.py

# 主要是处理不能与机器人通过通讯方式沟通的世界的状态
# 本项目暂时未使用, 仅为空的框架.


import threading
import logging
import time
import robot_main

class RobotWorld(threading.Thread):

    def __init__(self):
        super(RobotWorld, self).__init__()
        return
    robot=None

    def run(self):

        return

    # Part 1: 避障
    # Part 2: Guessing, 猜测这个世界有什么问题
    # Part 3: Sensoring , 探测这个世界存在的障碍