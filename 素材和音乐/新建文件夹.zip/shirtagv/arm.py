# -*- coding:utf-8 -*-
import time

from iot_modbus_rtu_xyd1210 import ModbusRtuXyd1210

class arm():
    rtu = None
    def init(self):
        self.rtu = ModbusRtuXyd1210()
        self.rtu.config('COM3', 22)
        return

    def reach_out(self):
        print("伸出手臂")
        ch8 = self.rtu.read_X8()
        if(ch8 == 1):
            print("手臂已在最外方，无法再伸")
            return True
        print("开始伸出")
        self.rtu.write_Y4(1)
        self.rtu.write_Y5(0)
        while True:
            ch8 = self.rtu.read_X8()
            if(ch8 == 1):
                break
        self.rtu.write_Y4(0)
        time.sleep(1)
        self.rtu.write_Y5(0)
        print("顶起结束")
        return  True

    def shrink_back(self):
        print("缩回手臂")
        ch9 = self.rtu.read_X9()
        if (ch9 == 1):
            print("已处于缩回状态，无法再缩")
            return True
        print("开始缩回")
        self.rtu.write_Y4(0)
        self.rtu.write_Y5(1)
        while True:
            ch9 = self.rtu.read_X9()
            if (ch9 == 1):
                break
        self.rtu.write_Y4(0)
        self.rtu.write_Y5(0)
        print("缩回结束")
        return  True

if __name__ == '__main__':
    arm = arm()
    arm.init()
    arm.rtu.connect()
    arm.reach_out()