from flask import Flask, url_for, render_template, redirect, jsonify
from flask import request
from socket import socket,AF_INET,SOCK_STREAM
import queue
from robot_inside import RobotInside
web_tcp = Flask(__name__)
# 服务端的ip地址
# server_ip = '127.0.0.1'
server_ip = '192.168.1.4'
# 服务端socket绑定的端口号
server_port = 20000
@web_tcp.route('/')
def debug():
    return render_template("zone2nine.html")
@web_tcp.route('/channel.html')
def channel():
    return render_template("channel.html")
@web_tcp.route('/zone2nine.html')
def zone2nine():
    return render_template("zone2nine.html")
@web_tcp.route('/ruku.html')
def ruku():
    return render_template("ruku.html")
@web_tcp.route('/controler.html')
def controler():
    return render_template("controler.html")
#@web_tcp.route('/')
#def debug():
    #启动页面
#    return render_template("debug.html")

def init_tcp():
    return

@web_tcp.route('/send', methods=['POST'])
def send():
    post_data = request.get_json(silent=True)
    print(post_data)
    str1 = post_data['str']
    print(str1)
    sendStr = str(str1).encode("utf-8")
    print(sendStr)
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(sendStr)
    client.close()
    data_wrapper = {'result_code': 0}
    return jsonify(data_wrapper)

#入库1
@web_tcp.route("/in1", methods=['POST'])
def in1():
    # 获取到post的json数据
    print("进入入库1")
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraIn = "7550"
    print(paraIn)
    #tcp发送数据
    sendStr = paraIn.encode()
    global client
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(sendStr)
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#入库2
@web_tcp.route("/in2", methods=['POST'])
def in2():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraIn = "0-" + post_data['paraIn']
    print(paraIn)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(paraIn.encode())
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#出库1
@web_tcp.route("/out1", methods=['POST'])
def out1():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = post_data['paraOut']+"-0"
    print(paraOut)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(paraOut.encode())
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#出库2
@web_tcp.route("/out2", methods=['POST'])
def out2():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = "556690"
    print(paraOut)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(paraOut.encode())
    client.close()

    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)

#移库
@web_tcp.route("/move", methods=['POST'])
def move():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraMove = post_data['paraMove']
    print(paraMove)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(paraMove.encode())
    client.close()
    #返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#去充电
@web_tcp.route("/go_charge", methods=['POST'])
def go_charge():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = "522225655680"
    print(paraOut)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(paraOut.encode())
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#充电返回
@web_tcp.route("/charge_back", methods=['POST'])
def charge_back():
    # 获取到post的json数据
    print(request.get_data(as_text=True))
    post_data = request.get_json(silent=True)
    paraOut = "56554522225660"
    print(paraOut)
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(paraOut.encode())
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#获取状态
@web_tcp.route("/get_state", methods=['POST'])
def get_state():
    # tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'qingqiuzhuangtaishuju')
    print("已发送")
    return_date=str(client.recv(1024), encoding="utf-8")
    print("return_date=",return_date)
    #print("type=",type(return_date))
    #data = json.loads(return_date)
    #print(type(data))
    #print(data)
    client.close()
    #print(type(return_date))
    #data = json.loads(return_date)
    #print(type(data))
    return jsonify(return_date)
#前
@web_tcp.route("/forword", methods=['POST'])
def forword():
    #tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'ykqq')
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#后
@web_tcp.route("/backword", methods=['POST'])
def backword():
    #tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'ykqh')
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#左
@web_tcp.route("/left", methods=['POST'])
def left():
    #tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'ykqz')
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#右
@web_tcp.route("/right", methods=['POST'])
def right():
    #tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'ykqy')
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#停
@web_tcp.route("/urgent_stop", methods=['POST'])
def urgent_stop():
    #tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'ykqt')
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#顶升起
@web_tcp.route("/jacking_up", methods=['POST'])
def jacking_up():
    #tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'ykqdsq')
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
#顶升降
@web_tcp.route("/jacking_down", methods=['POST'])
def jacking_down():
    #tcp发送数据
    client = socket(AF_INET, SOCK_STREAM)
    client.connect((server_ip, server_port))
    client.send(b'ykqdsj')
    client.close()
    # 返回数据,如果成功result_code 为 0 result_msg 为success
    data_wrapper = {'result_code': 0, 'result_msg': "success"}
    return jsonify(data_wrapper)
class runweb():
    def start(self):
        # web_tcp.run(host='127.0.0.1' ,port=5000)
        web_tcp.run(host='192.168.1.4' ,port=5000)

if __name__ == '__main__':
    init_tcp()
    run = runweb()
    run.start()