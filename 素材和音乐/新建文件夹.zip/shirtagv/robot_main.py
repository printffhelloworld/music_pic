#! /moobot/res/slenderagv/robot_main.py

# 主要是机器人的主运行逻辑.
# 核心架构为异步多线程
# python 并不能很好的利用多核的优势, 所以多线程对于pytho来说是伪命题.
import threading
import logging
import time


class RobotMain(threading.Thread):

    # 给inside服务
    channel_list=[]
    dr=[]
    dw=[]

    # 给team服务
    task_queue=["24687590","2314"]
    current_task=None

    #当前指令
    cmd_this=""
    cmd_this_start_time=None
    cmd_this_end_time=None
    idle_start_time=None
    idle_end_time=None

    #主状态
    main_state= 0
    MAIN_STATE_INIT = 100
    MAIN_STATE_IDLE = 200
    MAIN_STATE_BUSY = 300
    MAIN_STATE_BUSY_RUNNING = 310
    MAIN_STATE_BUSY_FINISH = 320
    MAIN_STATE_BUSY_BLOCKED = 330
    MAIN_STATE_WAIT = 400
    MAIN_STATE_ERROR = 500
    MAIN_STATE_ERR_DONE = 510
    MAIN_STATE_ERR_UNDONE = 520
    MAIN_STATE_ERR_UNKNOW = 530



    def __init__(self,name):
        super(RobotMain, self).__init__()
        self.task_queue = ["24687590", "2314"]
        a='''
        # TODO 创建硬件部件(脚、腰、背等)
        waist = Waist(3)
        feet = Feet()
        backbone = BackBone()
        arm = Arm()
        body = Body()
        brain = Brain()'''

        b='''
        nose1=Magnet("/dev/ttyUSB0",1)
        nose1.init()
        nose2 = Magnet("/dev/ttyUSB0", 1)
        nose2.init()
        nose=(nose1,nose2)

        ear=Radar("/dev/ttyUSB0", 2)
        ear.init()

        mouth=Rfid()
        mouth.init()

        feet1=iot_motor_pwm()
        feet1.init()
        feet2=iot_motor_pwm()
        feet2.init()
        feet=(feet1, feet2)
        '''
        return

    def init(self):
        print("INIT")
        return

    def run(self):
        self.main_state=self.MAIN_STATE_INIT
        self.init()
        self.main_state = self.MAIN_STATE_IDLE
        print("IDLE")
        while True:
            print(self.task_queue[1])
            if(self.task_queue.count()==0):
                print("task_queue blank")
                time.sleep(0.5)
                continue
            else:
                self.main_state = self.MAIN_STATE_BUSY
                print("BUSY")
                current_task=self.task_queue[0]
                self.run_task(current_task)
                self.task_queue.remove(0)
                time.sleep(0.5)
                self.main_state = self.MAIN_STATE_IDLE
                print("IDLE")
        return


    def run_task(self,task):
        print("BUSY: RUN TASK",task )
        try:
            cmd_list= self.get_command_list(task)
            if(cmd_list==None):
                return True
            elif (len(cmd_list)==0):
                return True
            else:
                for cmd in cmd_list:
                    self.run_cmd(cmd)
                return True
        except Exception as ex:
            logging.error(ex.__traceback__)
            return False
    #根据task生成commandlist
    def get_command_list(self,task):
        cmd_str="246132"
        # task_cmdstr_json_dictionary
        #cmd_str=读取数据库, 获得task对应的cmd_str
        #TODO: 目前是假数据
        cmd_list=["2","4","6","1","3","2"]
        #将cmd_str分解为command数组
        print("BUSY: RUN TASK", task)
        return cmd_list

    def run_cmd(self, cmd):
        if(cmd==None):
            return True
        elif(cmd==""):
            return True
        elif(self.mode==1):
            return self.hard_move(cmd)
        elif(self.mode==15):
            return self.safe_go(cmd)
        else:
            #raise Unknown Command Exception
            return False

    #Part 3: 主要运动指令
    # 最常用的是safe_go()  # 24687950  不许调用iot的part，只能修改value_to_write，不允许直接调用iot part

    def hard_move(self,cmd):
        if(cmd==None):
            return True
        else:
            cmd = cmd.trim()
            if (cmd==""):
                return True
            elif(cmd=="2"):
                #TODO: 杨志成
                return True
            elif(cmd=="4"):
                #TODO
                return True
            elif(cmd=="6"):
                #TODO
                return True
            elif(cmd=="8"):
                #TODO: 杨志成
                return True
            elif (cmd == "5"):
                # TODO: 杨志成
                return True
            elif (cmd == "0"):
                # TODO: 杨志成
                return True
            elif (cmd == "7"):
                # TODO: 杨志成
                return True
            elif (cmd == "9"):
                # TODO: 杨志成
                return True
            else:
                logging.error("未知指令")
                return False
    def safe_go(self,cmd):
        if (cmd == None):
            return True
        else:
            cmd = cmd.trim()
            if (cmd == ""):
                return True
            elif (cmd == "2"):
                # TODO: 杨志成
                return True
            elif (cmd == "4"):
                # TODO
                return True
            elif (cmd == "6"):
                # TODO
                return True
            elif (cmd == "8"):
                # TODO: 杨志成
                return True
            elif (cmd == "5"):
                # TODO: 杨志成
                return True
            elif (cmd == "0"):
                # TODO: 杨志成
                return True
            elif (cmd == "7"):
                # TODO: 杨志成
                return True
            elif (cmd == "9"):
                # TODO: 杨志成
                return True
            else:
                logging.error("未知指令")
                return False

    def soft_move(self, cmd):
        return

    def safe_move(self, cmd):
        return

    def hard_follow(self, cmd):
        return

    def soft_follow(self, cmd):
        return

    def safe_follow(self, cmd):
        return

    def hard_go(self, cmd):
        return

    def soft_go(self, cmd):
        return


    #Part 1: 与IOT进行交互







    # Part 4: 主要状态维护
    # 1) 一直由RobotTeam来接收来自Commander的命令
    # 2) 机器人为idle时, 执行下一个指令
    # 3) 执行指令时, 机器人为Busy, 前后, 可以有子状态Busy.Booked, Busy.Clear清理动作 .
    # 4)


    # Part 5 任务队列
    task_queue= [] #任务队列

    def add_task(self,task):
        return
    def remove_task(self,task):
        return
    def clear_all_task(self):
        task_queue=[]
        main_state=self.MAIN_STATE_IDLE
        return

    # Part 6: 外部指令控制

    # 都设置1和0
    cmd_config_softgo = 1  # 软启动开关
    cmd_config_safego = 1  # 超声避障开关,只变Vy
    cmd_config_follow = 1  # 巡磁开关,只变Vw
    cmd_config_stopatpoint = 1  # rfid点是否停开关

    #设置模式
    def set_mode(self, mode=15):
        if(mode>=0 and mode<16):
            cmd_config_softgo=mode%2
            cmd_config_safego = mode//2%2
            cmd_config_follow = mode//4%2
            cmd_config_stopatpoint = mode//8%2
            return True
        else:
            return False


            # Vy_target 软起动开,应该加; 超声开,应该减,如何改变
            # 写到part_feet的before_write()中

    def cmd_move(self, cmd, speed, follow=False, avoid=False, point=False):
        return


b = '''
    以下为垃圾代码 2019-06-20, 五天后可删

    CH_MOTOR1_SPEED=16
    CH_MOTOR2_SPEED = 16


    #Part 2: MOC 的插补算法

    target_speed=3

    #相对vy
    def feet_move_v(self, vy, vw):

    def motor_move_v(self):

        MAX_VL = 0.3  # m/s
        MAX_VR = 0.3  # m/s
        MAX_VY = 0.3  # m/s
        MAX_VW = 0.1  # rad/s

        def mov_reverse(vy, vw):
            vl = (vy + vw) / 2
            vr = (vy - vw) / 2
            return (vl, vr)

        def interpolate([read_v1, read_v2]

            , [target_v1, target_v2], [limit_v1_acc, limit_v2_acc]):

        # TODO: Robin
        return self.move(v1, v2)

    def move_v(vy, vw):
        # vy = -1.00, +1.00
        # vw = -1, +1

        (target_v1, target_v2) = moc_reverse(vy, vw)
        ref_v1, ref_v2 )= interpolate([read_v1, read_v2], [target_v1, target_v2], [limit_v1_acc, limit_v2_acc])

        motor1.move_v(vl)
        motor2.move_v(v2)
        return

    def move_vt(vy, vw, t):
        return

    def move_s(sy, vy, vw):
        return

    def along_v(vy):
        return

    def along_vt(vy, t):
        return

    def along_s(sy):
        return

    def along_sv(sy, sv):
        return

    def reach_forward():
        return reach_v(+1.0)

    def reach_backward():
        return reach_v(-1.0)

    def reach_v(vy):
        return

    def run_task(str):
        if (str == "2"):
            run_task_2();
        # TODO
        return

    def run_task_2():
        return reach_forward()

    def run_task_8():
        return reach_backward()
    '''

def main():
    rm = RobotMain("task_t1")
    rm.start()  # runnint task t1
    return

if(__name__=="__main__"):
    main()



