#! /moobot/res/slenderagv/robot_team.py

# 主要是多台机器人之间的协同和通讯.

# 杨智富负责
# 2n+1个线程,看有多少队友，（manager线程）启用所有listener，当某个listener断了如何处理,把所以命令放一个task queue中
#task queue放robot main中
import  serial
import _thread
import threading
import robot_main

class RobotTeam(threading.Thread):

    robot=None

    def __init__(self):
        super(RobotTeam, self).__init__()
        # 新建线程，在线程中听
        lora_commander = LoraCommander()
        _thread.start_new_thread(lora_commander.start_listen())
        return
    # 机器人的列表
    commander_list=[{"id":1,"type":"lora", },]

    # commander可能有多个


    # def add_commander(self, commander):
    #
    #     return
    #
    # def remove_commander(self, commander):
    #     # 清空自己下发的
    #     # 清空所有的任务
    #
    #     return
    #
    #
    # robot_list=[]
    # def add_robot(self, robot):
    #     return
    #
    # def remove_robot(self, robot):
    #
    #     return
    #
    #
    # #所有机器人执行同样的动作
    # def same_action(self, cmd):
    #     return
    #
    # #不同机器人同时执行不同指令
    # def parrall_action(self, cmd_list):
    #
    #     return
    #
    # #不同机器人按顺序执行不同指令
    # def queue_action (self, cmd_list_list):
    #
    #     return
if __name__ == '__main__':
    robotTeam = RobotTeam()
    robotTeam.__init__()



