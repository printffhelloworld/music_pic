# -*- coding:utf-8 -*-
# !/res/moobot/slender/app.py
# author: 杨志成
# email:yangzc2009cc@163.com
# 超薄车
# import robot
# import web_lora
from robot import Robot
from flask import Flask, url_for, render_template, redirect, jsonify
from flask import request
from web import runweb
import _thread


robot1 = None
web1 = None

web1 = runweb()

def init():
    #树莓派上一共要跑两个软件:
    #1, 一个是机器人的控制程序
    _thread.start_new_thread(run,(1,))
    global robot1
    global web1
    robot1 = Robot()
    robot1.run()
    web1 = runweb()
    web1.start()

def run(a):
    web1.start()

def dispose():
    try:
        print("app dispose()")
        robot1.dispose()
        web1.dispose()
    except Exception as ex:
        return
    return True

if __name__=="__main__":
    init()
    dispose()
    exit(0)
